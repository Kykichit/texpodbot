# Release Checklist

## Before PR

```bash
ruff check .
ruff format --check .
mypy src texpod_bot
pytest
python -m app.main config-check --strict --json
python -m app.main runbooks validate
docker compose --env-file .env.compose-check.example config
docker compose --env-file .env.demo.example -f docker-compose.demo.yml config
docker compose -f docs/examples/docker-compose.chatwoot.yml config
docker build -t taskbot:release-check .
```

Do not run live Telegram or Chatwoot tests unless explicitly approved.

## Before Demo

- `.env.demo` exists and contains only demo/test credentials.
- `python -m app.main config-check --strict --json` passes.
- `python scripts/chatwoot_local.py doctor` passes when Chatwoot is used.
- Chatwoot webhook URL is
  `http://host.docker.internal:18080/chatwoot/webhook` for Docker Desktop.
- Chatwoot events include `message_created`,
  `conversation_status_changed`, and `conversation_updated`.
- Exactly one Telegram polling process is running.
- A new ticket can be created.
- Customer follow-up messages do not produce confirmation spam.
- Operator replies from Chatwoot reach Telegram without the old support prefix.

## Before Production

- TLS is configured and tested.
- Chatwoot webhooks are signed.
- `CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=false`.
- Secrets are in server env, GitHub Secrets, or a secret manager.
- PostgreSQL backup and restore are tested.
- Monitoring and alerting are enabled.
- Rollback image tag and database rollback notes are documented.
- Migrations are reviewed and backed up.
- Duplicate Telegram polling prevention is operationally documented.

## All-in-One VPS Gate

- `docker compose --env-file .env.vps.compose-check.example -f docker-compose.vps.yml config` passes.
- Caddy config is mounted and validates.
- Chatwoot `db:chatwoot_prepare` completed.
- Taskbot `db-upgrade` completed.
- Telegram webhook is set with `TELEGRAM_WEBHOOK_SECRET`.
- Chatwoot webhook is signed and points to `https://<bot-domain>/chatwoot/webhook`.
- Chatwoot events include `message_created`, `conversation_status_changed`, and `conversation_updated`.
- `CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=false`.
- Both `taskbot` and `chatwoot` database backups are tested.
- Smoke test from [vps-all-in-one-chatwoot.md](vps-all-in-one-chatwoot.md) passes.

## Release Notes Template

```markdown
## Summary

## Changed Components

## Tests

## Migration Notes

## Rollback Plan

## Risks
```

## Rollback Reminder

Application rollback is not enough when a release includes database migrations.
State whether migrations are backward-compatible and whether restore from backup
is required.
