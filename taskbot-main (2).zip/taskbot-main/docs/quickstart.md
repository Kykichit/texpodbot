# Quickstart

This is the shortest path to a local demo. It does not require live Telegram or
Chatwoot unless you explicitly add test credentials.

## Requirements

- Python 3.12.
- Docker Desktop or Docker Engine with Compose v2.
- Git.
- Optional on Windows: GNU Make. Direct `docker compose` commands are shown
  below, so Make is not required.

## Windows PowerShell

```powershell
git clone https://github.com/Kykichit/taskbot.git
cd taskbot
Copy-Item .env.demo.example .env.demo
python -m pip install -e ".[dev]"
docker compose --env-file .env.demo -f docker-compose.demo.yml run --rm --no-deps --build demo-app python -m app.main config-check --strict --json
docker compose --env-file .env.demo -f docker-compose.demo.yml up -d demo-postgres demo-redis
docker compose --env-file .env.demo -f docker-compose.demo.yml run --rm --build demo-app python -m app.main db-upgrade
docker compose --env-file .env.demo -f docker-compose.demo.yml up --build -d demo-app
```

## Windows CMD

```bat
git clone https://github.com/Kykichit/taskbot.git
cd taskbot
copy .env.demo.example .env.demo
python -m pip install -e ".[dev]"
docker compose --env-file .env.demo -f docker-compose.demo.yml run --rm --no-deps --build demo-app python -m app.main config-check --strict --json
docker compose --env-file .env.demo -f docker-compose.demo.yml up -d demo-postgres demo-redis
docker compose --env-file .env.demo -f docker-compose.demo.yml run --rm --build demo-app python -m app.main db-upgrade
docker compose --env-file .env.demo -f docker-compose.demo.yml up --build -d demo-app
```

## Linux/macOS

```bash
git clone https://github.com/Kykichit/taskbot.git
cd taskbot
cp .env.demo.example .env.demo
python -m pip install -e ".[dev]"
docker compose --env-file .env.demo -f docker-compose.demo.yml run --rm --no-deps --build demo-app python -m app.main config-check --strict --json
docker compose --env-file .env.demo -f docker-compose.demo.yml up -d demo-postgres demo-redis
docker compose --env-file .env.demo -f docker-compose.demo.yml run --rm --build demo-app python -m app.main db-upgrade
docker compose --env-file .env.demo -f docker-compose.demo.yml up --build -d demo-app
```

## Health Checks

```bash
curl http://127.0.0.1:18080/health
curl http://127.0.0.1:18080/ready
```

If `curl` is not available on Windows:

```powershell
Invoke-WebRequest -UseBasicParsing http://127.0.0.1:18080/health
Invoke-WebRequest -UseBasicParsing http://127.0.0.1:18080/ready
```

`/health` checks that the process is alive. `/ready` checks runtime
dependencies such as PostgreSQL and Redis.

## Run Polling Separately

The background `demo-app` is useful for HTTP endpoints and Chatwoot webhooks.
For live Telegram polling, use exactly one foreground polling process:

```bash
python scripts/chatwoot_local.py stop-taskbot-polling
docker compose --env-file .env.demo -f docker-compose.demo.yml run --rm demo-app python -m app.main run
```

Only use a test bot token and test chats. Do not run live Telegram tests unless
that is explicitly approved for the task.

## Make Shortcuts

```bash
make demo-start
make demo-health
make demo-logs
make demo-stop
```

## Stop

```bash
docker compose --env-file .env.demo -f docker-compose.demo.yml down
```

To remove only demo containers and demo volumes:

```bash
DEMO_ALLOW_RESET=1 make demo-reset
```

On Windows without Make, run the reset only when demo data is disposable:

```powershell
docker compose --env-file .env.demo -f docker-compose.demo.yml down -v --remove-orphans
```

## Add Local Chatwoot

After the base demo works, follow [Local Chatwoot setup](chatwoot-local-setup.md).
Use `http://host.docker.internal:18080/chatwoot/webhook` as the Chatwoot webhook
URL when taskbot runs through Docker Desktop.
