# Prototype Live Test

This checklist is for an explicitly approved live Telegram prototype run. Use a
test bot and test chats only.

## Start PostgreSQL and Redis

```powershell
docker compose up -d postgres redis
```

Check containers:

```powershell
docker compose ps
```

## Apply Migrations

```powershell
python -m app.main db-upgrade
```

The command should finish with `Database migrations applied successfully.` It
must not print database credentials or Telegram tokens.

## Run Telegram Polling

Use `.env.local.example` as the base for local host mode:

```powershell
Copy-Item .env.local.example .env
```

Fill only test values in `.env`:

```dotenv
TELEGRAM_BOT_TOKEN=replace-with-test-bot-token
TELEGRAM_SUPPORT_GROUP_ID=replace-with-test-support-group-id
TELEGRAM_PROXY_URL=http://127.0.0.1:10809
```

`TELEGRAM_PROXY_URL` is optional when Python can auto-detect the user/system
proxy. Verify auto-detection with:

```powershell
python -c "import urllib.request; print(urllib.request.getproxies())"
```

Start polling:

```powershell
python -m app.main run
```

In Telegram, send `/start`, describe the issue, answer the clarification, and
send the branch/location. The bot should return a `SUP-...` public id.

## Check Ticket In PostgreSQL

Open a disposable local psql session:

```powershell
docker compose exec postgres psql -U support -d support
```

Inspect the latest ticket:

```sql
select public_id, issue_type, status, priority, telegram_chat_id, created_at
from tickets
order by created_at desc
limit 5;
```

Inspect stored messages:

```sql
select sender_type, left(text, 500) as text_preview, created_at
from ticket_messages
order by created_at desc
limit 5;
```

## Check Support Group

The configured test support group should receive one summary when the ticket is
created. Confirm that it includes:

- public id;
- human-readable issue type;
- original problem text;
- clarification answer;
- location;
- Telegram user id and chat id;
- display name;
- classification confidence.

Follow-up client messages after ticket creation should be appended to the same
ticket and should not create a duplicate ticket.

## Stop Local Infrastructure

```powershell
docker compose down
```
