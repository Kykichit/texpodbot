# DevOps Runbook

The active operations guide is [operations.md](operations.md).

Keep this file as a stable link for older references. Use it for daily checks,
logs, health probes, Telegram polling/webhook checks, Chatwoot delivery checks,
migrations, safe Compose validation, and incident triage.
