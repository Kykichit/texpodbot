# Support Bot Architecture

## Current Audit

What is solid:

- `src/domain` stays platform-neutral for generic bot dialog logic.
- Telegram and MAX adapters are split under `src/bot/telegram` and `src/bot/max`.
- Product support logic is isolated in `texpod_bot`.
- PostgreSQL models, repositories, unit of work, Alembic migrations, Docker, Compose, and CI are present.
- Runbooks are deterministic YAML graphs validated by CLI.
- Webhook secrets are validated for Telegram and Chatwoot.
- `config-check` masks sensitive values.
- Chatwoot and support group integrations are behind adapter/service boundaries.

Partial:

- Ticket lifecycle existed but did not include the full target state model or response/resolution timestamps.
- Analytics existed as a daily report, but not as reusable filtered metrics.
- Support group UX had reply routing and close, but lacked status/stats commands.
- Structured logging exists, but request correlation and redaction are not yet consistent across all handlers.
- MAX adapter maps generic requests, but product support flow is still Telegram-first.
- Runbook progress is stored in session JSON and events, but detailed step analytics are not emitted everywhere yet.

Missing or weak:

- Dedicated `analytics_events` table or event envelope with channel/customer/operator dimensions.
- Prometheus endpoint and OpenTelemetry export.
- SLA policy model and SLA breach worker.
- Durable queue for retries and delivery backlogs.
- Full operator permissions model beyond active Telegram operators in DB.
- Complete customer UX for `/status`, reopen, CSAT, and attachment lifecycle.
- Production-grade dashboard JSON and alert routing.

Main technical risks:

- Some Russian strings in Python files are mojibake and need a careful UTF-8 cleanup pass.
- Existing flows use both prototype intake and runbook handlers; this should be consolidated.
- Some services write raw payload JSON directly; typed event payloads should be expanded.
- Chatwoot delivery has timeouts but no idempotency keys or retry queue.

Main UX risks:

- Customer has no consistent status screen or CSAT flow yet.
- Operator card is useful but still text-heavy and lacks quick actions for priority/data requests.
- Error messages are uneven and partly mojibake.
- Reply-to-ticket protection exists through routing but needs clearer operator feedback.

Main DevOps/SRE risks:

- `/ready` checks DB/Redis but not migrations, runbook validity, or outbound adapter health.
- No Prometheus/OpenTelemetry endpoint yet.
- No retry/backlog metrics for failed Telegram/Chatwoot sends.
- Docker image is non-root, but Compose still uses demo DB password and has no resource limits.

Likely files for future work:

- `texpod_bot/domain/enums.py`
- `texpod_bot/domain/events.py`
- `texpod_bot/domain/schemas.py`
- `texpod_bot/infrastructure/database/models.py`
- `texpod_bot/infrastructure/repositories.py`
- `texpod_bot/services/tickets.py`
- `texpod_bot/services/metrics.py`
- `texpod_bot/services/analytics.py`
- `texpod_bot/services/telegram_support.py`
- `texpod_bot/services/support_group_bridge.py`
- `src/bot/telegram/intake_handlers.py`
- `src/app/web.py`
- `src/app/logging.py`
- `migrations/versions/*`
- `tests/unit/texpod_bot/*`

## Target Flow

```mermaid
flowchart TD
    A["Customer opens /start"] --> B["Choose issue category"]
    B --> C["Deterministic runbook"]
    C --> D{"Resolved?"}
    D -->|yes| E["Resolved/closed + CSAT"]
    D -->|no| F["Collect diagnostics and media"]
    F --> G["Create SUP-XXXX"]
    G --> H["Support group or Chatwoot card"]
    H --> I["Operator replies or requests data"]
    I --> J{"Customer confirms fix?"}
    J -->|yes| K["Resolved then closed"]
    J -->|no| L["Waiting support / reopened"]
```

## Ticket Lifecycle

```mermaid
stateDiagram-v2
    [*] --> new
    new --> collecting_data
    new --> open
    collecting_data --> open
    open --> waiting_support
    open --> waiting_customer
    waiting_support --> assigned
    assigned --> waiting_customer
    waiting_customer --> waiting_support
    assigned --> dev_needed
    dev_needed --> waiting_support
    waiting_support --> resolved
    assigned --> resolved
    resolved --> closed
    resolved --> reopened
    reopened --> waiting_support
    new --> cancelled
    collecting_data --> cancelled
    open --> cancelled
    waiting_support --> cancelled
    waiting_customer --> cancelled
```

Each transition should emit `ticket_events` with `from_status`, `to_status`, actor, reason, and timestamp. Ticket rows keep summary timestamps for efficient metrics: `created_at`, `updated_at`, `first_response_at`, `resolved_at`, `closed_at`, `reopened_at`.

## Analytics Pipeline

```mermaid
flowchart LR
    A["Domain service"] --> B["Typed event payload"]
    B --> C["ticket_events"]
    C --> D["MetricsService filters"]
    D --> E["/stats, reports, SQL views"]
    D --> F["Prometheus exporter"]
    D --> G["Grafana dashboards"]
```
