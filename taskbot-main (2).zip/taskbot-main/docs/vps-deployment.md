# VPS Deployment

This guide is a practical baseline, not a fully automated production platform.
Run a real VPS smoke test before calling a deployment production-ready.

## Minimum Server

- 1-2 CPU.
- 1-2 GB RAM for taskbot only.
- More RAM if Chatwoot runs on the same VPS.
- Docker Engine and Docker Compose v2.
- A domain name for HTTPS webhooks.

## Recommended Shape

- taskbot app container;
- PostgreSQL as the source of truth for tickets, messages, and events;
- Redis for runtime/cache/state;
- reverse proxy: Caddy, Nginx, or Traefik;
- optional Chatwoot on the same VPS, or preferably a separate VPS when traffic
  grows.

Keep PostgreSQL and Redis on a private Docker network. Expose only the reverse
proxy, SSH, and any explicitly required admin ports.

## First-Time Bootstrap

After Docker Engine and Docker Compose v2 are installed, run the non-destructive
bootstrap preflight from a release bundle or repository checkout:

```bash
sudo TASKBOT_DEPLOY_USER=<deploy-user> TASKBOT_APP_DIR=/opt/taskbot bash scripts/vps_bootstrap.sh
```

The script checks Docker/Compose availability, creates `/opt/taskbot/releases`,
`/opt/taskbot/shared`, and `/opt/taskbot/shared/backups`, copies missing env
files from `.env.vps.example` and `.env.chatwoot.production.example` into
`/opt/taskbot/shared`, checks DNS for `BOT_DOMAIN` and `CHATWOOT_DOMAIN` when
provided, checks whether local ports `80` and `443` are already in use, prints
firewall guidance, and prints the next commands. It does not install packages or
modify firewall rules. It also changes ownership of `/opt/taskbot` to
`TASKBOT_DEPLOY_USER`, keeps generated env files at `0600`, and keeps the
backups directory private.

Fill the generated files before deploy:

```bash
sudoedit /opt/taskbot/shared/.env.vps
sudoedit /opt/taskbot/shared/.env.chatwoot.production
```

The VPS stack uses a stable Docker Compose project name,
`COMPOSE_PROJECT_NAME=taskbot`, so service/container names remain stable across
release directories.

## Deployment Options

Choose one:

- Taskbot-only VPS: use this guide when Chatwoot runs elsewhere.
- All-in-one VPS with Chatwoot: use
  [vps-all-in-one-chatwoot.md](vps-all-in-one-chatwoot.md) when taskbot,
  Chatwoot, Caddy, PostgreSQL pgvector, and Redis all run on one VPS.

## Production Env

Start from `.env.production.example` and store real values only on the server or
in a secret manager.

Required production posture:

```dotenv
APP_ENV=production
CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=false
CHATWOOT_ENABLED=true
```

Taskbot derives `DATABASE_URL` from `DB_HOST`, `DB_NAME`, `DB_USER`, and
`DB_PASSWORD`, and derives `REDIS_URL` from `REDIS_HOST`, `REDIS_PORT`, and
`REDIS_DB`. Set full URLs only when using a managed service that requires a
custom connection string.

Use real public HTTPS URLs. Do not use `localhost` for URLs consumed from
containers. Chatwoot webhooks must be signed in production; a missing secret
should fail closed.

## Telegram Strategy

Choose one:

- polling: one process only, simpler for pilots;
- webhook: route Telegram webhook traffic through the reverse proxy to taskbot.

Do not run polling and webhook delivery for the same bot token at the same time.

## TLS

Terminate TLS at Caddy, Nginx, or Traefik. Route:

- `/health` and `/ready` for probes;
- Telegram webhook path if webhook mode is used;
- `/chatwoot/webhook` for Chatwoot delivery.

Use HTTPS webhook URLs in Telegram and Chatwoot.

## Deploy

```bash
python scripts/doctor.py env .env.production --production
docker compose --env-file .env.production config
docker compose --env-file .env.production pull
docker compose --env-file .env.production up -d postgres redis
docker compose --env-file .env.production run --rm app python -m app.main db-upgrade
docker compose --env-file .env.production up -d app
```

If you build locally on the VPS:

```bash
docker build -t taskbot:<version> .
```

Tag images with an immutable release identifier. Avoid deploying untagged
`latest` without a rollback plan.

## Health And Logs

```bash
curl -fsS https://<domain>/health
curl -fsS https://<domain>/ready
docker compose --env-file .env.production logs -f app
docker compose --env-file .env.production ps
```

`/ready` should pass after migrations and after PostgreSQL/Redis are reachable.

## Backups

PostgreSQL is the source of truth. Back up before every production migration.

```bash
cd /opt/taskbot/current
bash scripts/backup.sh all
bash scripts/backup.sh status
```

Backups are compressed PostgreSQL custom-format dumps stored under
`/opt/taskbot/shared/backups`. Set `BACKUP_RETENTION_DAYS` to prune older local
backups after a successful backup:

```bash
BACKUP_RETENTION_DAYS=30 bash scripts/backup.sh all
```

Store backups outside the VPS as well. The deploy helper runs a predeploy backup
before image pulls and migrations. It skips the backup with a warning only when
there is no existing `taskbot` Compose Postgres container yet. Once a deployment
exists, backup failure blocks deploy.

## Restore Check

Check backups by restoring into disposable PostgreSQL databases:

```bash
bash scripts/restore_check.sh all
bash scripts/restore_check.sh /opt/taskbot/shared/backups/taskbot-20260430T120000Z.dump.gz
```

`restore_check.sh` creates a temporary database, restores the dump, and drops
the temporary database. It does not restore into production databases. A real
restore should be run only against an intentionally selected target database
using a tested backup.

## Update Version

```bash
cd /opt/taskbot/current
bash scripts/setup.sh deploy
curl -fsS https://<domain>/ready
```

## Rollback

CI deploys immutable bundles to `/opt/taskbot/releases/<sha>` and updates
`/opt/taskbot/current` to the active release. Runtime secrets are not bundled;
keep them in `/opt/taskbot/shared/.env.vps` and
`/opt/taskbot/shared/.env.chatwoot.production`.

```bash
cd /opt/taskbot/current
bash scripts/setup.sh current
bash scripts/setup.sh releases
bash scripts/setup.sh rollback
bash scripts/setup.sh status
```

`rollback` switches the `current` symlink to the previous installed release and
runs `docker compose up -d` from that release. It deliberately does not restore
PostgreSQL or run reverse migrations. Restore PostgreSQL only when the migration
or data change requires it and a tested backup is available.

Rollback is safest when release notes explicitly say whether migrations are
backward-compatible.

## Firewall

Open:

- `22/tcp` for SSH, preferably restricted by source IP;
- `80/tcp` and `443/tcp` for TLS issuance and HTTPS traffic.

Keep PostgreSQL, Redis, and internal Chatwoot ports private unless there is a
specific operational reason.

## Security Checklist

- Real secrets are in server env, GitHub Secrets, or a secret manager.
- No `.env` files are committed.
- Chatwoot webhooks are signed in production.
- `CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=false`.
- Reverse proxy enforces TLS.
- Database user has least practical privileges.
- PostgreSQL and Redis are not public.
- Logs do not print tokens, webhook secrets, or full connection strings.

## Troubleshooting

- Invalid Telegram webhook secret: confirm the `secret_token` passed to
  Telegram matches `TELEGRAM_WEBHOOK_SECRET`.
- Chatwoot webhook `401` or `403`: confirm `CHATWOOT_WEBHOOK_SECRET` and keep
  `CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=false` outside local/demo.
- Database misconfiguration: prefer `DB_HOST=postgres` inside Compose, not
  `localhost`; run `python scripts/doctor.py env .env.production --production`.
- Port conflicts: only the reverse proxy should publish public `80`/`443`;
  PostgreSQL, Redis, taskbot, and Chatwoot should stay internal.

## Reliability Gaps To Close

- delivery retry queue and idempotency keys;
- alerting on webhook and Telegram send failures;
- backup/restore automation;
- SLA breach automation;
- CI/CD deployment workflow with explicit rollback.
