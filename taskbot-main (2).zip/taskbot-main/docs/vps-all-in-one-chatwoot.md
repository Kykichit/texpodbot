# All-in-One VPS: taskbot + Chatwoot

This guide runs taskbot and Chatwoot on one VPS with Caddy HTTPS, one shared
pgvector PostgreSQL container, and one shared Redis container.

Use this mode for demos, pilots, and small teams. It is not an enterprise HA
deployment: one VPS means one failure domain.

```text
Caddy HTTPS
  -> bot.<domain>      -> taskbot app
  -> chatwoot.<domain> -> Chatwoot Rails
PostgreSQL pgvector
  -> taskbot database
  -> chatwoot database
Redis
  -> taskbot DB 0
  -> Chatwoot DB 1
```

## Minimum VPS

- Minimum pilot: 2 vCPU, 4 GB RAM, 30 GB disk.
- Better pilot: 4 vCPU, 8 GB RAM, 50+ GB disk.

Chatwoot is heavier than taskbot because it runs Rails and Sidekiq. If the VPS
starts swapping or OOM-killing containers, move Chatwoot or PostgreSQL to a
larger host.

## DNS

Create two `A` records:

```text
<bot-domain> -> <vps-public-ip>
<chatwoot-domain> -> <vps-public-ip>
```

Caddy uses these domains for Let's Encrypt certificates.
Caddy obtains and renews certificates automatically when DNS points to the VPS,
ports `80` and `443` are reachable, `BOT_DOMAIN`, `CHATWOOT_DOMAIN`, and
`ACME_EMAIL` are set, and the Caddy container is running.

## Firewall

Open only:

- `22/tcp` for SSH;
- `80/tcp` for Let's Encrypt HTTP challenge;
- `443/tcp` for HTTPS.

Do not expose PostgreSQL `5432`, Redis `6379`, taskbot `8080`, or Chatwoot
`3000` to the public internet.

## Files

- `docker-compose.vps.yml`
- `deploy/caddy/Caddyfile`
- `deploy/postgres/init/001-create-databases.sh`
- `.env.vps`
- `.env.chatwoot.production`

## Setup

```bash
cp .env.vps.example .env.vps
cp .env.chatwoot.production.example .env.chatwoot.production
```

Fill the blank values in both files. Do not commit them.
The taskbot env uses `DB_*` and `REDIS_*` values; the Compose file derives
internal URLs for taskbot and Chatwoot so database credentials are not
duplicated in connection strings.

Generate Chatwoot `SECRET_KEY_BASE` on a secure machine:

```bash
openssl rand -hex 64
```

Optional helper:

```bash
python scripts/doctor.py vps
python scripts/vps_bootstrap.py doctor
python scripts/vps_bootstrap.py compose-config
python scripts/vps_bootstrap.py print-commands
```

The helper checks files and production posture without printing secret values.

For a first-time server, use the shell bootstrap preflight from the release
bundle or repository checkout:

```bash
sudo TASKBOT_DEPLOY_USER=<deploy-user> TASKBOT_APP_DIR=/opt/taskbot bash scripts/vps_bootstrap.sh
```

It verifies Docker and Compose v2, creates `/opt/taskbot/releases`,
`/opt/taskbot/shared`, and `/opt/taskbot/shared/backups`, copies missing env
files into `/opt/taskbot/shared`, checks DNS when `BOT_DOMAIN` and
`CHATWOOT_DOMAIN` are already filled, checks whether local ports `80` and `443`
are free, prints firewall guidance, and shows the next deploy commands. It does
not install packages. The bootstrap step changes ownership of `/opt/taskbot` to
`TASKBOT_DEPLOY_USER`, keeps env files at `0600`, and keeps the backups
directory private.

The repeatable setup script wraps the same checks plus image pulls, migrations,
and startup:

```bash
bash scripts/setup.sh doctor
bash scripts/setup.sh pull
bash scripts/setup.sh migrate
bash scripts/setup.sh up
```

Use `bash scripts/setup.sh pull`, `bash scripts/setup.sh migrate`, and
`bash scripts/setup.sh up` when you need to run the phases separately. Use
`bash scripts/setup.sh deploy` for the combined flow.

All VPS commands use a stable Docker Compose project name:
`COMPOSE_PROJECT_NAME=taskbot`. Override it only when deliberately running a
separate isolated stack.

## Start PostgreSQL And Redis

Validate Compose first:

```bash
docker compose --env-file .env.vps -f docker-compose.vps.yml config
```

```bash
docker compose --env-file .env.vps -f docker-compose.vps.yml up -d postgres redis
```

Before starting services, pull the configured images:

```bash
bash scripts/setup.sh pull
```

Production deploys should use the verified `TASKBOT_IMAGE` from CI. For a manual
local VPS build, run `bash scripts/setup.sh build-local` explicitly.

The PostgreSQL init script runs only when `allinone_postgres_data` is empty. It
creates separate users/databases for taskbot and Chatwoot and enables the
`vector` extension in the Chatwoot database.

If the volume already exists, the init script will not run again. Create missing
databases manually or restore from backup instead of deleting production data.

## Prepare Chatwoot

```bash
docker compose --env-file .env.vps -f docker-compose.vps.yml run --rm chatwoot-rails bundle exec rails db:chatwoot_prepare
```

## Migrate Taskbot

```bash
docker compose --env-file .env.vps -f docker-compose.vps.yml run --rm app python -m app.main db-upgrade
```

The setup script equivalent for both Chatwoot and taskbot migrations is:

```bash
bash scripts/setup.sh migrate
```

## Start All Services

```bash
docker compose --env-file .env.vps -f docker-compose.vps.yml up -d
docker compose --env-file .env.vps -f docker-compose.vps.yml ps
```

The setup script equivalent is:

```bash
bash scripts/setup.sh up
```

## Health

```bash
curl -fsS https://<bot-domain>/health
curl -fsS https://<bot-domain>/ready
curl -fsS https://<chatwoot-domain>
```

## Configure Chatwoot

1. Open `https://<chatwoot-domain>`.
2. Create the first account.
3. Create an API inbox.
4. Copy account ID, inbox ID, and API token into `.env.vps`.
5. Restart taskbot:

```bash
docker compose --env-file .env.vps -f docker-compose.vps.yml up -d --force-recreate app
```

Set Chatwoot webhook URL:

```text
https://<bot-domain>/chatwoot/webhook
```

Enable events:

- `message_created`;
- `conversation_status_changed`;
- `conversation_updated`.

Use a signed webhook secret in production. Keep:

```dotenv
CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=false
```

## Configure Telegram Webhook

Set webhook:

```bash
curl -fsS "https://api.telegram.org/bot<telegram-bot-token>/setWebhook" \
  -F "url=https://<bot-domain>/telegram/webhook" \
  -F "secret_token=<telegram-webhook-secret>"
```

Check webhook:

```bash
curl -fsS "https://api.telegram.org/bot<telegram-bot-token>/getWebhookInfo"
```

Do not run polling for the same bot token while webhook mode is active.

## Smoke Test

1. Send `/start` in Telegram.
2. Create a support ticket.
3. Confirm a Chatwoot conversation appears.
4. Reply in Chatwoot as an operator.
5. Confirm Telegram receives only the operator text, without a support prefix.
6. Send 2-3 customer follow-up messages.
7. Confirm no noisy confirmation spam.

SQL checks:

```bash
docker compose --env-file .env.vps -f docker-compose.vps.yml exec postgres psql -U taskbot -d taskbot
```

```sql
select public_id, status, created_at
from tickets
order by created_at desc
limit 5;
```

```sql
select event_type, payload_json, created_at
from ticket_events
order by created_at desc
limit 20;
```

```sql
select external_system, external_conversation_id, external_url
from ticket_external_refs
order by created_at desc
limit 10;
```

## Logs

```bash
docker compose --env-file .env.vps -f docker-compose.vps.yml logs -f app
docker compose --env-file .env.vps -f docker-compose.vps.yml logs -f chatwoot-rails chatwoot-worker
docker compose --env-file .env.vps -f docker-compose.vps.yml logs -f caddy
docker compose --env-file .env.vps -f docker-compose.vps.yml logs -f postgres redis
```

## Backups

One PostgreSQL container contains both databases. Automated VPS backups are
stored under `/opt/taskbot/shared/backups` as compressed PostgreSQL custom-format
dumps.

```bash
cd /opt/taskbot/current
bash scripts/backup.sh taskbot
bash scripts/backup.sh chatwoot
bash scripts/backup.sh all
bash scripts/backup.sh status
```

Retention is controlled by `BACKUP_RETENTION_DAYS`:

```bash
BACKUP_RETENTION_DAYS=30 bash scripts/backup.sh all
```

`bash scripts/setup.sh deploy` takes a predeploy backup of both databases before
pulling images or running migrations. If no existing `taskbot` Compose Postgres
container exists, the backup is skipped with a clear warning for first deploy.
When an existing Postgres container exists, backup failure blocks deploy.

Copy backups off the VPS.

## Restore Check

Verify backup usability before you need it in an incident:

```bash
cd /opt/taskbot/current
bash scripts/restore_check.sh all
bash scripts/restore_check.sh taskbot
bash scripts/restore_check.sh chatwoot
```

`restore_check.sh` restores into disposable PostgreSQL databases and drops them
afterwards. It does not restore over production databases.

## Update

1. Back up both databases.
2. Pull the verified app image.
3. Run taskbot migrations.
4. Run Chatwoot prepare if the Chatwoot image changed.
5. Restart services.

```bash
cd /opt/taskbot/current
bash scripts/setup.sh deploy
```

## Rollback

Versioned CI deployments are unpacked under `/opt/taskbot/releases/<sha>`.
Secrets stay outside release bundles in `/opt/taskbot/shared/.env.vps` and
`/opt/taskbot/shared/.env.chatwoot.production`; `/opt/taskbot/current` points to
the active release.

```bash
cd /opt/taskbot/current
bash scripts/setup.sh current
bash scripts/setup.sh releases
bash scripts/setup.sh rollback
bash scripts/setup.sh status
```

`rollback` switches `/opt/taskbot/current` to the previous release and runs
`docker compose up -d` from that release. It does not run migrations and does
not restore PostgreSQL automatically. Restore databases only when the release
notes say it is required and a tested backup is available.

## Troubleshooting

Caddy certificate not issued:

- Check DNS records.
- Check ports `80` and `443`.
- Check `docker compose --env-file .env.vps -f docker-compose.vps.yml logs -f caddy`.

`/ready` returns `503`:

- Check PostgreSQL and Redis health.
- Confirm taskbot uses `DB_HOST=postgres`, not `localhost`, inside Compose.
- Run migrations.

Chatwoot returns `502`:

- Check `chatwoot-rails` logs.
- Check `SECRET_KEY_BASE`, database env, and Redis URL.
- Run `bundle exec rails db:chatwoot_prepare`.

Chatwoot assets not loading:

- Confirm `FRONTEND_URL=https://<chatwoot-domain>`.
- Confirm Caddy routes the Chatwoot domain to `chatwoot-rails:3000`.

Chatwoot prepare fails on `vector` extension:

- Confirm PostgreSQL image is `pgvector/pgvector:pg16`.
- Confirm the init script ran on an empty volume.

Telegram webhook `403`:

- Confirm `TELEGRAM_WEBHOOK_SECRET` matches the Telegram webhook secret token.
- Confirm no polling process is running.

Chatwoot webhook `401` or `403`:

- `401`: missing signed secret.
- `403`: invalid secret.
- Confirm the Chatwoot webhook secret matches `.env.vps`.

Operator reply not reaching Telegram:

- Check `ticket_events` for `chatwoot_operator_reply_sent`.
- Check app logs for Telegram send errors.
- Confirm the ticket has Telegram customer metadata.

VPS out of memory:

- Stop nonessential services.
- Add swap only as a temporary mitigation.
- Move to a larger VPS.

Disk full:

- Check Docker logs and volumes.
- Move backups off the VPS.
- Increase disk before running migrations.
