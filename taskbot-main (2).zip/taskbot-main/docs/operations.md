# Operations

Use this guide for daily checks, logs, delivery debugging, migrations, and
incident triage.

## Daily Checks

```bash
curl -fsS http://127.0.0.1:18080/health
curl -fsS http://127.0.0.1:18080/ready
docker compose ps
docker compose logs --tail=200 app
```

For demo:

```bash
make demo-health
make demo-logs
```

For all-in-one VPS:

```bash
docker compose --env-file .env.vps -f docker-compose.vps.yml ps
bash scripts/setup.sh ps
curl -fsS https://<bot-domain>/health
curl -fsS https://<bot-domain>/ready
```

## Logs

```bash
docker compose logs -f app
docker compose logs -f postgres redis
docker compose --env-file .env.demo -f docker-compose.demo.yml logs -f demo-app
docker compose --env-file .env.vps -f docker-compose.vps.yml logs -f app
docker compose --env-file .env.vps -f docker-compose.vps.yml logs -f chatwoot-rails chatwoot-worker
docker compose --env-file .env.vps -f docker-compose.vps.yml logs -f caddy
bash scripts/setup.sh logs
```

Do not paste tokens, webhook secrets, database URLs, or customer-sensitive
message text into shared logs.

## Health And Readiness

- `/health`: process is alive.
- `/ready`: app dependencies are reachable.

If `/health` passes and `/ready` fails, check PostgreSQL, Redis, and migrations.

## Metrics

`/metrics` is exposed by the aiohttp app for Prometheus scrapes. On VPS, Caddy
keeps it private by default; do not expose it publicly without authentication or
network restrictions.

Internal check from the VPS:

```bash
cd /opt/taskbot/current
docker compose --env-file /opt/taskbot/shared/.env.vps -f docker-compose.vps.yml exec app \
  python - <<'PY'
import urllib.request
print(urllib.request.urlopen("http://127.0.0.1:8080/metrics", timeout=2).read().decode())
PY
```

Key series:

- `taskbot_http_requests_total{route,method,status}`;
- `taskbot_http_request_duration_seconds{route,method}`;
- `taskbot_webhook_updates_total{channel,result}`;
- `taskbot_webhook_latency_seconds{channel}`;
- `taskbot_readiness_failures_total{dependency}`;
- `taskbot_build_info{version,commit}`.

## Telegram Polling Or Webhook

Polling:

```bash
python scripts/chatwoot_local.py stop-taskbot-polling
docker compose --env-file .env.demo -f docker-compose.demo.yml run --rm demo-app python -m app.main run
```

Webhook mode:

```bash
python -m app.main serve-webhook
```

Only one polling process may use a Telegram bot token. Duplicate polling usually
surfaces as `TelegramConflictError`.

## Chatwoot Delivery

Local webhook URL for Docker Desktop:

```text
http://host.docker.internal:18080/chatwoot/webhook
```

Check the safe helper output:

```bash
python scripts/chatwoot_local.py webhook-info
python scripts/chatwoot_local.py doctor
```

Expected webhook failures:

- `401`: missing webhook secret where a signature or secret is required;
- `403`: invalid webhook secret;
- `422`: Chatwoot API payload or account/inbox/contact mismatch.

Unsigned local webhooks are allowed only when `APP_ENV` is `demo` or `local`,
`CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=true`, and the request comes from
localhost or private Docker/LAN ranges.

## SQL Snippets

Run against the taskbot PostgreSQL database. Adjust service and credentials for
your environment.

Latest tickets:

```sql
select id, public_id, status, category, created_at, updated_at
from tickets
order by created_at desc
limit 20;
```

Latest ticket events:

```sql
select ticket_id, event_type, payload_json, created_at
from ticket_events
order by created_at desc
limit 20;
```

Latest messages:

```sql
select ticket_id, sender_type, source, left(text, 120) as text_preview, created_at
from ticket_messages
order by created_at desc
limit 20;
```

External references:

```sql
select ticket_id, external_system, external_conversation_id, external_url, metadata_json, created_at
from ticket_external_refs
order by created_at desc
limit 20;
```

Avoid dumping full message bodies unless needed for an approved support
investigation.

## Migrations

```bash
python -m app.main config-check --strict --json
python -m app.main db-upgrade
python -m app.main runbooks validate
```

In production, take a PostgreSQL backup before migrations.

For the all-in-one VPS helper:

```bash
bash scripts/setup.sh doctor
bash scripts/setup.sh backup
bash scripts/setup.sh migrate
```

All-in-one VPS uses one PostgreSQL container with two databases:

- `taskbot` for taskbot tickets/messages/events;
- `chatwoot` for Chatwoot Rails data.

It uses one Redis container with separate DBs:

- `redis://redis:6379/0` for taskbot;
- `redis://redis:6379/1` for Chatwoot.

The VPS stack uses `COMPOSE_PROJECT_NAME=taskbot` by default in helper scripts.
This keeps container and volume names stable even though releases live in
different `/opt/taskbot/releases/<sha>` directories.

## VPS Backups And Restore Checks

All-in-one VPS backups are local PostgreSQL custom-format dumps compressed under
`/opt/taskbot/shared/backups`. They never include `.env` files, and the backup
scripts do not print database passwords.

```bash
cd /opt/taskbot/current
bash scripts/backup.sh taskbot
bash scripts/backup.sh chatwoot
bash scripts/backup.sh all
bash scripts/backup.sh status
```

Set `BACKUP_RETENTION_DAYS` to prune older dump files after a successful backup:

```bash
BACKUP_RETENTION_DAYS=30 bash scripts/backup.sh all
```

`bash scripts/setup.sh deploy` runs `bash scripts/backup.sh all` before pulling
images or running migrations. On first deploy, when no existing `taskbot`
Compose Postgres container exists, it skips the predeploy backup with a warning.
After the first deployment exists, backup failure blocks deploy.

Run restore checks into disposable PostgreSQL databases:

```bash
bash scripts/restore_check.sh all
bash scripts/restore_check.sh taskbot
bash scripts/restore_check.sh chatwoot
bash scripts/restore_check.sh /opt/taskbot/shared/backups/taskbot-20260430T120000Z.dump.gz
```

`restore_check.sh` creates a temporary database, restores the dump with
`pg_restore`, and drops the temporary database afterwards. It does not restore
or modify production databases. Copy backups off the VPS after each production
deployment.

## Safe Compose Config

Use dummy env values when you need to share or inspect Compose output:

```bash
docker compose --env-file .env.compose-check.example config
make compose-check
```

Do not run `docker compose config` with a real `.env` if the output will be
shared.

## Incident Checklist

1. Check `/health` and `/ready`.
2. Check app logs for delivery errors and ticket IDs.
3. Confirm exactly one Telegram polling process is active.
4. Confirm Chatwoot webhook URL and enabled events.
5. Check recent `ticket_events`, `ticket_messages`, and `ticket_external_refs`.
6. Check PostgreSQL and Redis containers.
7. If a new release just shipped, verify migration status and consider rollback.
8. Record the cause and any missing alert/runbook coverage.

## Observability Status

Current baseline is logs plus `/health`, `/ready`, and process-local
Prometheus metrics at `/metrics`. Broader tracing and alert routing are planned.

Recommended metrics:

- `ticket_created_total`;
- `taskbot_webhook_updates_total{channel,result}`;
- `taskbot_webhook_latency_seconds{channel}`;
- `taskbot_readiness_failures_total{dependency}`;
- `telegram_send_errors_total`;
- `first_response_seconds`;
- `resolution_seconds`;
- `open_tickets`;
- `sla_breached_total`.
