# Metrics

## Database Schema

Primary event store:

- `ticket_events(ticket_id, event_type, payload_json, created_at)`
- `ticket_messages(ticket_id, sender_type, sender_id, attachment_url, created_at)`
- `tickets(status, priority, issue_type, source, created_at, first_response_at, resolved_at, closed_at, reopened_at)`

New indexes:

- `ix_tickets_status_created_at`
- `ix_tickets_source_created_at`
- `ix_tickets_issue_type_created_at`
- `ix_ticket_events_type_created_at`

Future optional table:

```sql
create table analytics_events (
    id uuid primary key,
    event_name text not null,
    ticket_id uuid,
    customer_id uuid,
    channel text,
    actor_type text,
    actor_id text,
    payload_json jsonb not null,
    occurred_at timestamptz not null
);
```

Use `analytics_events` when metrics need events not tied to a ticket, such as app startup, config-check, migration status, and queue backlog snapshots.

## Support Metrics

| Metric | Source |
| --- | --- |
| total tickets | `tickets` |
| tickets by status/category/priority/channel | `tickets` |
| new/open/closed/reopened per day | `tickets`, `ticket_events` |
| escalation rate | `ticket_events.escalated / tickets` |
| runbook self-resolution rate | resolved tickets without escalation/support messages |
| average first response time | `tickets.first_response_at` or first support message |
| average resolution time | `resolved_at/closed_at - created_at` |
| SLA breach count | future `sla_breached` events |
| reopen rate | `reopened` events / tickets |
| cancelled/abandoned flow count | cancelled tickets + `runbook_abandoned` events |
| top devices/app versions | `devices` joined to `tickets` |
| tickets with attachments | `ticket_messages.attachment_url is not null` |
| operator workload | support messages grouped by `sender_id` |
| CSAT | future `feedback_score` event |

## Runbook Metrics

| Metric | Source |
| --- | --- |
| starts | `runbook_started` |
| completions | resolved without operator + escalated |
| resolved without operator | resolved/closed tickets without escalation/support messages |
| escalated | `escalated` |
| drop-off by step | `runbook_abandoned.payload_json.step_key` |
| most selected options | `runbook_option_selected` or `runbook_step_completed` |
| duration | first runbook event to terminal runbook event |
| version effectiveness | include `runbook_version` in typed payloads |

## Prometheus Endpoint

The aiohttp app exposes Prometheus text format at `/metrics` on the app
container. In the VPS Caddy config this route is private by default and returns
`404` publicly; scrape it from the Docker network or add an explicitly
authenticated reverse-proxy route.

Current process-local metrics:

- `taskbot_http_requests_total{route,method,status}`
- `taskbot_http_request_duration_seconds{route,method}`
- `taskbot_webhook_updates_total{channel,result}`
- `taskbot_webhook_latency_seconds{channel}`
- `taskbot_readiness_failures_total{dependency}`
- `taskbot_build_info{version,commit}`

`channel` is `telegram` or `chatwoot`. `result` is `success` for HTTP status
codes below `400` and `error` for rejected or failed webhooks.

Example internal scrape:

```bash
docker compose --env-file /opt/taskbot/shared/.env.vps -f docker-compose.vps.yml exec app \
  python - <<'PY'
import urllib.request
print(urllib.request.urlopen("http://127.0.0.1:8080/metrics", timeout=2).read().decode())
PY
```

Future metrics to add:

- `taskbot_unhandled_exceptions_total{component}`
- `taskbot_external_api_failures_total{system}`
- `taskbot_delivery_failures_total{channel}`
- `taskbot_retry_attempts_total{system}`
- `taskbot_queue_backlog{queue}`
- `taskbot_config_check_status`
- `taskbot_migration_revision_info{revision}`

## Dashboard Panels

- Ticket volume by day.
- Open tickets by status and priority.
- Escalation rate and self-resolution rate.
- First response and resolution time percentiles.
- Top issue categories, devices, app versions, and customers.
- Runbook funnel by step.
- Chatwoot/Telegram delivery failures.
- Webhook latency and error rate.
- DB/Redis readiness and migration revision.

## Operator `/stats` Format

The support group command returns a compact Russian report:

- period;
- total/new/open/closed/reopened tickets;
- counts by status, category, and priority;
- escalation rate;
- runbook self-resolution rate;
- average first response and resolution time;
- attachment count;
- operator replies and workload.

If there is no data, the bot returns a short empty state instead of an empty table.

## Alerts

- `/ready` failing for 2 minutes or `taskbot_readiness_failures_total` increasing.
- Webhook error rate above 2% for 5 minutes.
- Chatwoot or Telegram delivery failures above threshold.
- P1 ticket without first response for SLA window.
- Queue backlog growing for 10 minutes.
- Migration revision mismatch after deploy.
- Config-check strict failure in CI or staging.
