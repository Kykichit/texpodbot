# Operator Runbook

## Support Group Commands

- `/status SUP-XXXX` shows ticket status, priority, category, channel, timestamps, and operator reply count.
- `/close SUP-XXXX reason` closes a ticket and notifies the customer.
- Reply to the ticket card to send a message to the customer.
- `/stats today` shows same-day support metrics.
- `/stats week` shows metrics for the last seven days including today.

```mermaid
flowchart TD
    A["Operator command"] --> B{"/status, /close, /stats"}
    B --> C["Load ticket or metrics from DB"]
    C --> D["Format concise operator response"]
    D --> E["Send response to support group"]
```

## Reply Rules

- Always reply to the original ticket card or the ticket thread.
- Do not paste secrets, tokens, internal URLs, or credentials into customer replies.
- Keep customer replies short and action-oriented.
- If more data is needed, ask for one clear item at a time: photo, video, device ID, app version, branch/location, or exact error time.
- Use `/close` only after the customer confirms resolution or the case is intentionally cancelled.

## Ticket Card Checklist

Before answering, check:

- `SUP-XXXX` number.
- Category and priority.
- Customer/channel.
- Device ID and app version if present.
- Runbook history and collected diagnostics.
- Existing Chatwoot or support group replies.

## Common Errors

- `Ticket not found`: check the public ID and that the bot has DB access.
- Reply not routed: reply to the ticket card or use `/status SUP-XXXX`.
- Access denied: your Telegram user must exist as an active support operator.

## Copy Rules

- Keep replies customer-safe.
- Use `SUP-XXXX` in every ticket-specific answer.
- Do not send internal IDs, secrets, stack traces, or raw JSON to customers.
- See [ux-copy-style.md](ux-copy-style.md) for message style rules.
