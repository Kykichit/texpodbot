# Definition Of Done

## Feature Definition Of Done

A feature is done when:

- [ ] There is a clear issue/task or user request.
- [ ] The requested support-bot behavior is implemented.
- [ ] Runbook behavior is deterministic by default.
- [ ] AI/LLM behavior, if present, is optional and guarded by configuration.
- [ ] Business logic is implemented in `src/domain`.
- [ ] Product-specific support bot logic is implemented in `texpod_bot` or the agreed support-bot package path.
- [ ] Telegram-specific mapping is in `src/bot/telegram`.
- [ ] MAX-specific mapping is in `src/bot/max`.
- [ ] MAX behavior was not assumed to match Telegram.
- [ ] Domain does not import Telegram/MAX SDKs, `aiogram`, `httpx`, database drivers, Redis clients, or external ticketing clients.
- [ ] Ticket, conversation, and runbook state changes are persisted or explicitly documented as in-memory MVP behavior.
- [ ] Configuration changes go through `src/app/config.py`.
- [ ] `.env.example` is updated if new variables are added.
- [ ] No real secrets are added.
- [ ] Unit tests cover domain behavior.
- [ ] Unit tests cover runbook transitions and escalation decisions where relevant.
- [ ] Adapter tests cover Telegram/MAX mapping where relevant.
- [ ] External APIs are mocked in normal tests.
- [ ] Live tests are opt-in only.
- [ ] README or docs are updated if usage changes.
- [ ] Required checks pass:

```bash
ruff check .
ruff format --check .
mypy src
pytest
```

- [ ] Deploy/runtime changes also pass:

```bash
docker compose config
docker build .
```

## Release Definition Of Done

A release is done when:

- [ ] All feature DoD items are complete.
- [ ] CI is green.
- [ ] Docker image builds successfully:

```bash
docker build .
```

- [ ] Runtime config validates:

```bash
python -m app.main config-check
```

- [ ] Healthcheck is available and documented.
- [ ] Required environment variables are documented.
- [ ] No release artifact contains `.env` or real secrets.
- [ ] Deployment mode is documented:
  - [ ] polling for development;
  - [ ] webhook-ready for production;
  - [ ] separate Telegram/MAX services supported.
- [ ] Rollback plan is documented.
- [ ] Migration plan is documented if storage changes.
- [ ] PostgreSQL/Redis changes include migration, rollback, and data-safety notes.
- [ ] Optional live smoke tests are documented and explicitly enabled only in safe environments.
