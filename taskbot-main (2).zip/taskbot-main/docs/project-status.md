# Project Status

## What Is Implemented

- Async Python 3.12 application entrypoints.
- Telegram customer channel.
- Deterministic runbook flow.
- Ticket, message, event, and external reference persistence in PostgreSQL.
- Redis runtime/cache/state dependency.
- Support group handoff flow.
- Chatwoot support desk integration.
- Chatwoot contact upsert and 422 diagnostics.
- Signed/custom/unsigned-local Chatwoot webhook handling.
- Quiet Telegram customer UX after Chatwoot handoff.
- Demo launcher with isolated PostgreSQL/Redis ports.
- Local self-host Chatwoot helper.
- Config checks, runbook validation, linting, typing, and tests.

## Works In Demo

- Local demo stack with `.env.demo`.
- `/health` and `/ready` on demo app.
- Database migrations through `python -m app.main db-upgrade`.
- Local self-host Chatwoot wiring with Docker Desktop.
- Chatwoot operator replies back to Telegram in the live flow.
- Customer follow-up messages can be forwarded without confirmation spam.

Demo/local is almost ready and should be treated as ready after a fresh smoke
test.

## Ready For Pilot

A pilot is realistic when these are configured:

- test or pilot Telegram bot token and support group;
- Chatwoot account, inbox, API token, and signed webhook secret;
- PostgreSQL backup process;
- basic monitoring and log access;
- one documented polling or webhook strategy;
- an operator runbook for Chatwoot and support group fallback.

## Not Yet Production-Ready

Do not call the system fully production-ready until these exist:

- full monitoring and alerting;
- backup/restore automation;
- delivery retry queue and idempotency;
- SLA breach automation;
- production deployment guide verified on a real VPS;
- secrets stored through a secret manager or equivalent server secret process;
- stable CI/CD deploy flow with rollback.

## Known Risks

- Delivery failures need stronger retry/idempotency behavior.
- Duplicate Telegram polling can break live intake.
- Chatwoot local and production behavior differ around networking and webhook
  signatures.
- Backup/restore is documented but not automated.
- Observability is logs and health checks first; metrics are not fully wired.
- MAX channel parity is not the same as Telegram.

## Recommended Next PRs

1. Production Compose plus Caddy/Nginx example.
2. Prometheus metrics endpoint.
3. Retry/idempotency queue for external delivery.
4. Backup/restore scripts and restore test docs.
5. SLA breach events and alerts.
6. CI/CD deployment workflow.

## Priority Roadmap

- P0: verified VPS smoke test with signed Chatwoot webhooks.
- P0: backup/restore automation.
- P1: delivery retry and idempotency.
- P1: metrics and alerting.
- P1: production deployment automation.
- P2: SLA automation.
- P2: MAX parity improvements.

## Readiness Scores

- Demo readiness: 8/10.
- Pilot readiness: 6/10.
- Production readiness: 4/10.
