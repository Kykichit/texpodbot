# Chatwoot Integration Plan

## Goal

Use Chatwoot as the primary operator support desk while keeping PostgreSQL ticket core as
the source of truth. Telegram and later MAX are customer channels, not operator desks.

## MVP Flow

1. Customer sends a Telegram support message.
2. The bot creates a PostgreSQL ticket and stores the customer message.
3. Backend creates or updates a Chatwoot contact.
4. Backend creates a Chatwoot conversation and posts a ticket summary.
5. Customer follow-up messages are stored in PostgreSQL and sent to the mapped Chatwoot
   conversation.
6. Operator replies in Chatwoot.
7. Chatwoot webhook reaches the backend.
8. Backend validates `CHATWOOT_WEBHOOK_SECRET`, stores the operator message, and sends it to
   the original customer channel.
9. When Chatwoot marks the conversation resolved, the backend closes or resolves the
   PostgreSQL ticket and records a ticket event.

## Source Of Truth

PostgreSQL remains authoritative for:

- ticket status, public ID, priority, source channel, and lifecycle timestamps;
- customer messages and operator messages;
- external mapping between tickets and Chatwoot contact/conversation IDs;
- integration failure events.

Chatwoot is authoritative only for operator UI state and agent replies.

## Configuration

Required to enable outbound Chatwoot calls:

- `CHATWOOT_BASE_URL`
- `CHATWOOT_API_TOKEN`
- `CHATWOOT_ACCOUNT_ID`
- `CHATWOOT_INBOX_ID`

Required before webhook ingestion is enabled:

- `CHATWOOT_WEBHOOK_SECRET`

`config-check` must report only presence flags and must never print token or webhook secret
values.

## Implementation Stages

### Stage 1: Foundation

- Add Chatwoot settings and safe config checks.
- Add a platform-neutral support desk adapter interface.
- Add an HTTP Chatwoot client behind the interface.
- Add unit tests with mocked HTTP transport.

### Stage 2: Ticket Creation Bridge

Implemented in `Create Chatwoot conversation for new tickets`.

To enable it:

- set `CHATWOOT_ENABLED=true`;
- set `CHATWOOT_BASE_URL`;
- set `CHATWOOT_API_TOKEN`;
- set `CHATWOOT_ACCOUNT_ID`;
- set `CHATWOOT_INBOX_ID`.

On Telegram ticket creation the backend:

- creates the PostgreSQL ticket first;
- creates or updates a Chatwoot contact;
- creates a Chatwoot conversation;
- posts the human-readable ticket summary to that conversation;
- stores the mapping in `ticket_external_refs` with `external_system=chatwoot`;
- records `chatwoot_thread_created` in `ticket_events`.

If Chatwoot is unavailable or returns an error, ticket creation still succeeds for the
customer. The failure is stored as `chatwoot_thread_create_failed` in `ticket_events`.
Webhook ingestion and operator reply routing are the next stages and are not part of this
stage.

### Stage 3: Customer Follow-Up Bridge

Implemented in `Forward Telegram customer followups to Chatwoot`.

After a Telegram ticket is created and mapped to a Chatwoot conversation:

- every customer follow-up is still persisted in `ticket_messages` first;
- if `ticket_external_refs` contains a `chatwoot` conversation mapping, the backend sends the
  follow-up to that Chatwoot conversation as an incoming customer message;
- successful sends create `chatwoot_customer_message_sent`;
- Chatwoot delivery failures create `chatwoot_customer_message_send_failed`;
- the customer still receives the normal "message added" response even if Chatwoot is unavailable.

If there is no Chatwoot external ref, the follow-up remains safely stored in PostgreSQL and the
flow does not fail. Close-from-Chatwoot remains the next lifecycle stage.

### Stage 4: Webhook Ingestion

Implemented in `Route Chatwoot operator replies to Telegram`.

The backend exposes:

- `POST /chatwoot/webhook`
- header `X-Chatwoot-Webhook-Secret: <CHATWOOT_WEBHOOK_SECRET>`

The handler accepts `message_created` events, ignores private notes, ignores incoming/customer
messages to prevent loops, and routes only outgoing operator messages. It finds the ticket via
`ticket_external_refs.external_system=chatwoot` and `external_conversation_id`, sends the reply to
`tickets.telegram_chat_id`, stores a support `TicketMessage`, and records
`chatwoot_operator_reply_sent`.

If Telegram delivery fails, the backend records `chatwoot_operator_reply_send_failed` and returns a
non-stack-trace error response. Close/resolved events are intentionally left for Stage 5.

### Stage 5: Close From Chatwoot

Implemented in `Close tickets from Chatwoot resolved events`.

When Chatwoot sends a conversation status webhook with `resolved` or `closed` status, the backend:

- validates `X-Chatwoot-Webhook-Secret`;
- extracts the Chatwoot conversation ID from tolerant payload shapes;
- finds the PostgreSQL ticket through `ticket_external_refs`;
- marks the ticket `closed`;
- sets `closed_at`;
- records `chatwoot_conversation_resolved`;
- sends the Telegram customer notification: `✅ Обращение SUP-XXXX закрыто. Спасибо!`.

If the Telegram notification fails, the ticket remains closed and the backend records
`chatwoot_ticket_close_notify_failed`. Missing external mappings and already closed tickets are
handled without exceptions or duplicate customer notifications.

MAX delivery will use the later customer channel abstraction; this stage keeps Telegram as the
only customer notification channel.

### Stage 6: Channel Abstraction

- Add `CustomerChannelAdapter`.
- Implement Telegram first, then MAX.
- Keep Chatwoot webhook code independent from Telegram and MAX SDK objects.

## Testing Rules

- Unit tests must mock HTTP calls and must not call real Chatwoot.
- Webhook tests should use signed fake payloads.
- Telegram live polling is not required for this integration.
- CI must not require real Chatwoot credentials.
