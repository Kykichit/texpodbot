# Local Self-Host Chatwoot Setup

This guide wires a disposable local Chatwoot desk to the taskbot demo stack.
Do not put production tokens, customer data, or production backups into this
setup.

Default local path on Windows:

```text
C:\chatwoot-local
```

Taskbot demo app listens on `http://127.0.0.1:18080`. Chatwoot UI listens on
`http://localhost:3000`.

## Why `pgvector/pgvector`

The example Compose file uses `pgvector/pgvector:pg16` because current Chatwoot
migrations require the PostgreSQL `vector` extension. Plain
`postgres:16-alpine` can fail with `extension "vector" is not available`.

## Create And Start Chatwoot

```powershell
New-Item -ItemType Directory -Force C:\chatwoot-local
Copy-Item docs\examples\docker-compose.chatwoot.yml C:\chatwoot-local\docker-compose.chatwoot.yml
python scripts/chatwoot_local.py doctor
python scripts/chatwoot_local.py prepare
python scripts/chatwoot_local.py up
python scripts/chatwoot_local.py open
```

Linux/macOS can use another directory by setting `CHATWOOT_LOCAL_DIR` in
`.env.demo`.

Useful helper commands:

```bash
python scripts/chatwoot_local.py doctor
python scripts/chatwoot_local.py ps
python scripts/chatwoot_local.py logs
python scripts/chatwoot_local.py webhook-info
python scripts/chatwoot_local.py stop-taskbot-polling
python scripts/chatwoot_local.py stop
```

## Configure `.env.demo`

```powershell
Copy-Item .env.demo.example .env.demo
```

Use Docker Desktop host gateway values when taskbot runs in Docker:

```dotenv
CHATWOOT_ENABLED=true
CHATWOOT_BASE_URL=http://host.docker.internal:3000
CHATWOOT_WEBHOOK_URL=http://host.docker.internal:18080/chatwoot/webhook
CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=true
```

Fill these after creating the Chatwoot inbox and webhook:

```dotenv
CHATWOOT_ACCOUNT_ID=<account-id>
CHATWOOT_INBOX_ID=<inbox-id>
CHATWOOT_API_TOKEN=<api-token>
CHATWOOT_WEBHOOK_SECRET=<webhook-secret>
```

Do not commit `.env.demo`. Do not print or paste API tokens or webhook secrets.

## Create API Inbox / Source

In Chatwoot:

1. Create or open an account.
2. Create an API/Bot inbox for taskbot.
3. Copy the account ID from the account URL or API response.
4. Copy the inbox ID from the inbox settings or API response.
5. Create an API access token from the profile/access token screen.
6. Create a webhook secret in the webhook settings.

Use this webhook URL:

```text
http://host.docker.internal:18080/chatwoot/webhook
```

Enable these events:

- `message_created`;
- `conversation_status_changed`;
- `conversation_updated`.

`host.docker.internal` is required because Chatwoot runs in Docker and must call
the taskbot HTTP server exposed on the host/demo app port. `localhost` inside a
container points to that container, not to the host taskbot process.

## Unsigned Local Webhooks

`CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=true` is a local/demo escape hatch for
API inboxes that do not send the custom secret header during local testing.

It only works when:

- `APP_ENV` is `demo` or `local`;
- `CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=true`;
- the request comes from localhost or explicit private ranges
  `127.0.0.1`, `::1`, `172.16.0.0/12`, `10.0.0.0/8`, or `192.168.0.0/16`.

Production and staging without a valid secret must stay rejected. Invalid
secrets return `403`.

## Validate Taskbot

```bash
docker compose --env-file .env.demo -f docker-compose.demo.yml up -d demo-postgres demo-redis
docker compose --env-file .env.demo -f docker-compose.demo.yml run --rm --build demo-app python -m app.main db-upgrade
docker compose --env-file .env.demo -f docker-compose.demo.yml up --build -d demo-app
curl http://127.0.0.1:18080/ready
python scripts/chatwoot_local.py webhook-info
```

For live Telegram polling, stop duplicate polling containers and run one
foreground process:

```bash
python scripts/chatwoot_local.py stop-taskbot-polling
docker compose --env-file .env.demo -f docker-compose.demo.yml run --rm demo-app python -m app.main run
```

## Debug 401, 403, 422

`401` missing secret:

- Chatwoot did not send a secret or signature.
- In production/staging, configure `CHATWOOT_WEBHOOK_SECRET` and signed
  delivery.
- In local/demo only, optionally set
  `CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=true`.

`403` invalid secret:

- Chatwoot sent a secret, but it does not match taskbot config.
- Recreate or copy the secret carefully without printing it.

`422` Chatwoot API error:

- Check `CHATWOOT_ACCOUNT_ID` and `CHATWOOT_INBOX_ID`.
- Check that the contact can be upserted in the selected account.
- Check taskbot ticket events for Chatwoot diagnostic payloads.

Local Chatwoot SQL checks:

```bat
cd /d C:\chatwoot-local
docker compose -f docker-compose.chatwoot.yml exec chatwoot-postgres psql -U chatwoot -d chatwoot -c "select id, name from accounts;"
docker compose -f docker-compose.chatwoot.yml exec chatwoot-postgres psql -U chatwoot -d chatwoot -c "select id, name, account_id, channel_type from inboxes;"
docker compose -f docker-compose.chatwoot.yml exec chatwoot-postgres psql -U chatwoot -d chatwoot -c "select id, name, identifier, account_id, created_at from contacts order by created_at desc limit 20;"
```

Taskbot event check:

```bat
docker compose --env-file .env.demo -f docker-compose.demo.yml exec demo-postgres psql -U support_demo -d support_demo -c "select event_type, payload_json, created_at from ticket_events order by created_at desc limit 20;"
```

## Troubleshooting

Chatwoot "Could not send" / "Не удалось отправить":

- Confirm taskbot demo app is running and `/ready` passes.
- Confirm webhook URL is `http://host.docker.internal:18080/chatwoot/webhook`.
- Confirm enabled events include `message_created`.
- Check app logs for `401`, `403`, or `422`.

`localhost` does not work from Chatwoot:

- Use `host.docker.internal` on Docker Desktop.
- On Linux, add a host gateway mapping if your Docker version does not provide
  it automatically.

`TelegramConflictError`:

- More than one process is polling with the same bot token.
- Stop old polling containers:

```bash
python scripts/chatwoot_local.py stop-taskbot-polling
```

Windows CMD fallback:

```bat
for /f %i in ('docker ps -q --filter "name=taskbot-demo-demo-app-run"') do docker stop %i
```

Chatwoot does not open on `localhost:3000`:

- Run `python scripts/chatwoot_local.py ps`.
- Run `python scripts/chatwoot_local.py logs`.
- Check whether port `3000` is already used.

`make` is not installed:

- Use `python scripts/chatwoot_local.py ...` commands directly.

## Reset

Reset deletes local Chatwoot PostgreSQL and Redis volumes. Use it only for
disposable local data:

```bash
python scripts/chatwoot_local.py reset --confirm
```
