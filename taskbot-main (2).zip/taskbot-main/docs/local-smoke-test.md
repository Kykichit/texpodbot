# Local Smoke Test

This checklist verifies the backend and DevOps loop without live Telegram API
calls. Keep real tokens empty unless a live test is explicitly approved.

## Host Mode

Python runs on the Windows host. PostgreSQL and Redis run in Docker containers.
Use `.env.local.example`, where `DATABASE_URL` and `REDIS_URL` point to
`localhost`.

| Step | Command | Expected result | Troubleshooting notes |
| --- | --- | --- | --- |
| 1. Open project root | `cd "C:\Users\00106\OneDrive\Документы\New project"` | Shell is in the repository root. | Use the real checkout path if the project was moved. |
| 2. Create venv | `python -m venv .venv` | `.venv` directory is created. | If Python is missing, install Python 3.12+ and reopen PowerShell. |
| 3. Activate venv | `.venv\Scripts\Activate.ps1` | Prompt shows the active virtual environment. | If blocked, run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` and retry. |
| 4. Install dependencies | `pip install -e ".[dev]"` | Project and dev tools install successfully. | If install fails, upgrade `pip` and check network/proxy settings. |
| 5. Create `.env` | `Copy-Item .env.local.example .env` | `.env` exists with localhost DB/Redis URLs. | Do not paste real Telegram tokens for this smoke test. |
| 6. Start infra | `make infra-up` or `docker compose up -d postgres redis` | PostgreSQL and Redis containers start. | If Docker daemon is unavailable, start Docker Desktop and rerun `docker info`. |
| 7. Check containers | `docker compose ps` | `postgres` and `redis` are running or healthy. | If missing, inspect `docker compose logs postgres redis`. |
| 8. Check config | `python -m app.main config-check --strict` | Config is valid without printing secrets. | If it fails, verify `.env` was copied from `.env.local.example`. |
| 9. Validate runbooks | `python -m app.main runbooks validate` | `Runbooks valid: 3 loaded from runbooks`. | If it fails, inspect the YAML file and graph reference named in the error. |
| 10. List runbooks | `python -m app.main runbooks list` | Shows `KIOSK_OFFLINE`, `SYNC_FAILED`, and `APP_FREEZE`. | Missing files usually mean the command is not running from the repo root. |
| 11. Apply migrations | `python -m app.main db-upgrade` | Alembic applies migrations and exits 0. | If it fails, check `DATABASE_URL`, Postgres readiness, and existing migration state. |
| 12. Start app | `python -m app.main serve-webhook` | HTTP server listens on `127.0.0.1:8080`. | If port 8080 is busy, change `WEB_PORT` in `.env`. |
| 13. Check health | `curl http://127.0.0.1:8080/health` | Returns healthy response. | If connection fails, ensure the app process is still running. |
| 14. Check readiness | `curl http://127.0.0.1:8080/ready` | Returns ready response after DB/Redis are reachable. | `/ready` may return 503 before DB/Redis are healthy or migrations are applied. |
| 15. Webhook missing secret | `curl -i -X POST http://127.0.0.1:8080/telegram/webhook -H "Content-Type: application/json" -d "{}"` | Returns `401`. | This should not call Telegram. |
| 16. Webhook wrong secret | `curl -i -X POST http://127.0.0.1:8080/telegram/webhook -H "Content-Type: application/json" -H "X-Telegram-Bot-Api-Secret-Token: wrong" -d "{}"` | Returns `403`. | Confirm `TELEGRAM_WEBHOOK_SECRET=local-dev-secret` in `.env`. |
| 17. Webhook invalid JSON | `curl -i -X POST http://127.0.0.1:8080/telegram/webhook -H "Content-Type: application/json" -H "X-Telegram-Bot-Api-Secret-Token: local-dev-secret" -d "not-json"` | Returns `400`. | PowerShell may alias `curl`; use `curl.exe` if needed. |
| 18. Webhook minimal JSON | `curl -i -X POST http://127.0.0.1:8080/telegram/webhook -H "Content-Type: application/json" -H "X-Telegram-Bot-Api-Secret-Token: local-dev-secret" -d "{}"` | Returns a safe app response without live Telegram calls. | If it returns validation error, confirm the response is controlled and does not expose secrets. |
| 19. Stop app | `Ctrl+C` | App process stops cleanly. | If stuck, close the PowerShell process. |
| 20. Stop infra | `make infra-down` or `docker compose down` | Containers stop. | Use `docker compose ps` to confirm. |

## Full Compose Mode

The app, PostgreSQL, and Redis all run inside Docker Compose. Use `.env.example`,
where `DATABASE_URL` uses `postgres` and `REDIS_URL` uses `redis`.

| Step | Command | Expected result | Troubleshooting notes |
| --- | --- | --- | --- |
| 1. Create `.env` | `Copy-Item .env.example .env` | `.env` exists with Compose service hostnames. | Do not paste real Telegram tokens for this smoke test. |
| 2. Start stack | `docker compose up --build` | `app`, `postgres`, and `redis` start. | If Docker daemon is unavailable, start Docker Desktop and rerun `docker info`. |
| 3. Apply migrations | `docker compose run --rm app python -m app.main db-upgrade` | Alembic applies migrations from inside the Compose network. | If it fails, check that `DATABASE_URL` uses `postgres`, not `localhost`. |
| 4. Check health | `curl http://127.0.0.1:8080/health` | Returns healthy response. | If connection fails, verify `app` published port `8080`. |
| 5. Check readiness | `curl http://127.0.0.1:8080/ready` | Returns ready response after DB/Redis are reachable. | `/ready` may return 503 before migrations or service healthchecks complete. |
| 6. Check app logs | `docker compose logs app` | App logs do not contain secrets. | If app exits, inspect config-check output and container command. |
| 7. Check Postgres logs | `docker compose logs postgres` | Postgres starts and accepts connections. | If port 5432 is busy, change the published host port. |
| 8. Check Redis logs | `docker compose logs redis` | Redis starts and responds to ping healthcheck. | If port 6379 is busy, change the published host port. |
| 9. Stop stack | `docker compose down` | Containers stop. | Add `-v` only when intentionally deleting local DB data. |

## Troubleshooting

- Docker daemon unavailable: start Docker Desktop, wait until it is running, then
  run `docker info`.
- WSL/Debian integration disabled: enable WSL integration in Docker Desktop,
  run `wsl --shutdown`, and restart Docker Desktop.
- Port `5432` busy: stop local PostgreSQL or change the Compose published port
  to `5433:5432`.
- Port `6379` busy: stop local Redis or change the Compose published port to
  `6380:6379`.
- Port `8080` busy: stop the process using it or set another `WEB_PORT`.
- Host mode uses `postgres` instead of `localhost`: replace the DB host with
  `localhost` in `.env`.
- Compose mode uses `localhost` instead of `postgres`: replace the DB host with
  `postgres` in `.env`.
- `/ready` returns `503` before migrations: run `python -m app.main db-upgrade`
  in host mode, or `docker compose run --rm app python -m app.main db-upgrade`
  in Compose mode.
- `db-upgrade` fails: check `DATABASE_URL`, Postgres readiness, and Alembic
  migration history. The project dependencies include the sync PostgreSQL driver
  Alembic needs for migration execution.
- Telegram polling cannot connect to `api.telegram.org:443`: verify the
  VPN/proxy is running, set `TELEGRAM_PROXY_URL=http://127.0.0.1:10809` when
  needed, and compare `netsh winhttp show proxy` with
  `python -c "import urllib.request; print(urllib.request.getproxies())"`.
- `runbooks validate` fails: fix the YAML schema, duplicate `code`, missing
  `start` step, or unknown `next` reference named in the error.
- OneDrive permission/cache warnings: use temporary cache dirs for tools or move
  the checkout to a non-OneDrive path such as `C:\Projects\taskbot`.
- PowerShell execution policy blocks venv activation: run
  `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`.
