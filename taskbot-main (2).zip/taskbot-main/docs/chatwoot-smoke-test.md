# Chatwoot Smoke Test

This checklist verifies the live Chatwoot support flow with a real Telegram test
bot, a real Chatwoot instance, local PostgreSQL/Redis, and a public webhook URL.
Run it only in a local or staging environment with test customers and test chats.
Never paste real secrets into committed files, tickets, logs, or screenshots.

## A. Prerequisites

- Docker is running.
- PostgreSQL and Redis are available through Docker Compose.
- Telegram bot token for a test bot.
- Chatwoot instance reachable from your machine.
- Chatwoot account ID.
- Chatwoot inbox ID.
- Chatwoot API token.
- Chatwoot webhook secret.
- Public webhook URL or a local tunnel such as ngrok or cloudflared.

## B. `.env` Example

Keep real values only in your local untracked `.env`.

```dotenv
CHATWOOT_ENABLED=true
CHATWOOT_BASE_URL=
CHATWOOT_ACCOUNT_ID=
CHATWOOT_INBOX_ID=
CHATWOOT_API_TOKEN=
CHATWOOT_WEBHOOK_SECRET=

TELEGRAM_BOT_TOKEN=
DATABASE_URL=postgresql+asyncpg://support:support@localhost:5432/support
REDIS_URL=redis://localhost:6379/0
```

For host-mode webhook testing, also set:

```dotenv
WEB_HOST=127.0.0.1
WEB_PORT=8080
TELEGRAM_PROXY_URL=
```

## C. Local Startup

Start local infrastructure and apply migrations:

```bash
docker compose up -d postgres redis
python -m app.main db-upgrade
python -m app.main config-check --strict
```

Start Telegram polling in one terminal:

```bash
python -m app.main run
```

Expected result:

- the bot starts without printing tokens or secrets;
- PostgreSQL and Redis remain healthy;
- no live Chatwoot call happens until a Telegram ticket is created.

## D. Webhook Startup

Start the webhook server in a second terminal:

```bash
python -m app.main serve-webhook
```

Expose it with a tunnel if Chatwoot cannot reach your local machine:

```bash
ngrok http 8080
```

or:

```bash
cloudflared tunnel --url http://127.0.0.1:8080
```

Configure the Chatwoot webhook URL:

```text
https://<public-tunnel-host>/chatwoot/webhook
```

Configure the webhook header:

```text
X-Chatwoot-Webhook-Secret: <CHATWOOT_WEBHOOK_SECRET>
```

## E. Telegram Intake Test

In a private chat with the test Telegram bot:

1. Send `/start`.
2. Send `Не работает сканер`.
3. Answer the clarification question.
4. Send the branch/location.

Expected result:

- Telegram returns a `SUP-...` public ticket ID.
- PostgreSQL contains a new ticket.
- Chatwoot contains a new contact and conversation.
- `ticket_external_refs` contains a `chatwoot` mapping with
  `external_conversation_id`.

## F. Chatwoot Operator Reply Test

In Chatwoot, reply in the mapped conversation as an operator.

Expected result:

- Telegram client receives the operator message.
- `ticket_messages` has a row with `sender_type=support`.
- `ticket_events` has `chatwoot_operator_reply_sent`.

## G. Customer Follow-Up Test

In Telegram, send another customer message after the ticket is created.

Expected result:

- the message appears in the mapped Chatwoot conversation;
- `ticket_messages` has a new row with `sender_type=client`;
- `ticket_events` has `chatwoot_customer_message_sent`;
- Telegram confirms that the message was added to the ticket.

## H. Close Test

In Chatwoot, resolve or close the conversation.

Expected result:

- PostgreSQL ticket has `status=closed`;
- `closed_at` is not null;
- Telegram client receives `✅ Обращение SUP-XXXX закрыто. Спасибо!`;
- `ticket_events` has `chatwoot_conversation_resolved`.

If Telegram notification fails, the ticket should still be closed and
`ticket_events` should contain `chatwoot_ticket_close_notify_failed`.

## I. SQL Verification Commands

Open a PostgreSQL shell:

```bash
docker compose exec postgres psql -U support -d support
```

Run:

```sql
select public_id, status, closed_at from tickets order by created_at desc limit 5;
select sender_type, text, created_at from ticket_messages order by created_at desc limit 20;
select event_type, payload_json, created_at from ticket_events order by created_at desc limit 20;
select external_system, external_conversation_id, external_url from ticket_external_refs order by created_at desc limit 10;
```

Do not paste customer-sensitive message text into public issues or chat logs.

## J. Troubleshooting

### Chatwoot Conversation Not Created

- Confirm `CHATWOOT_ENABLED=true`.
- Run `python -m app.main config-check --strict`.
- Check `CHATWOOT_BASE_URL`, `CHATWOOT_ACCOUNT_ID`, and `CHATWOOT_INBOX_ID`.
- Confirm the API token has permission to create contacts, conversations, and
  messages.
- Inspect `ticket_events` for `chatwoot_thread_create_failed`.

### Webhook Returns 401 Or 403

- `401` means the `X-Chatwoot-Webhook-Secret` header is missing.
- `403` means the header value does not match `CHATWOOT_WEBHOOK_SECRET`.
- Do not print the secret while debugging; compare variable names and presence
  only.

### Webhook Not Received

- Confirm `python -m app.main serve-webhook` is running.
- Confirm the tunnel forwards to `http://127.0.0.1:8080`.
- Confirm Chatwoot uses `/chatwoot/webhook`, not `/telegram/webhook`.
- Check tunnel request logs for HTTP status and payload arrival.
- Make sure local firewalls or VPN rules do not block the tunnel.

### Telegram Notification Failed

- Confirm `TELEGRAM_BOT_TOKEN` belongs to the test bot.
- If direct Telegram access is blocked, set `TELEGRAM_PROXY_URL`.
- Check `ticket_events` for `chatwoot_operator_reply_send_failed` or
  `chatwoot_ticket_close_notify_failed`.
- Confirm the ticket has the expected `telegram_chat_id`.

### Ticket Not Closed

- Confirm Chatwoot sent `resolved` or `closed` status.
- Check that `ticket_external_refs.external_conversation_id` matches the
  Chatwoot conversation ID in the webhook payload.
- Inspect `ticket_events` for `chatwoot_conversation_resolved`.
- Already closed tickets are ignored to avoid duplicate customer notifications.

### Proxy Issues

- Explicitly set `TELEGRAM_PROXY_URL=http://127.0.0.1:<proxy-port>` when
  automatic proxy discovery is insufficient.
- Compare system proxy settings with:

```bash
python -c "import urllib.request; print(urllib.request.getproxies())"
```

### ngrok, cloudflared, And Local Tunnel Notes

- Use HTTPS tunnel URLs for Chatwoot webhooks.
- Restarting a free tunnel may change the public URL; update Chatwoot webhook
  settings after each restart.
- Keep tunnel logs open during the smoke test.
- Do not put API tokens or webhook secrets in tunnel command arguments.

## Cleanup

Stop local services after the smoke test:

```bash
docker compose down
```

Use `docker compose down -v` only when intentionally deleting local test data.
