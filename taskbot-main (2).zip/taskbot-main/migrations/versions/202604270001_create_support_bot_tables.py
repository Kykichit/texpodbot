"""create support bot tables

Revision ID: 202604270001
Revises:
Create Date: 2026-04-27 00:01:00
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "202604270001"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "clients",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("contact_name", sa.String(length=255), nullable=True),
        sa.Column("phone", sa.String(length=64), nullable=True),
        sa.Column("telegram_user_id", sa.String(length=64), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("telegram_user_id"),
    )
    op.create_table(
        "runbooks",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("code", sa.String(length=128), nullable=False),
        sa.Column("title", sa.String(length=255), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("active", sa.Boolean(), nullable=False),
        sa.Column("version", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("code", "version", name="uq_runbooks_code_version"),
    )
    op.create_index(op.f("ix_runbooks_code"), "runbooks", ["code"], unique=False)
    op.create_table(
        "support_operators",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("telegram_user_id", sa.String(length=64), nullable=False),
        sa.Column("display_name", sa.String(length=255), nullable=False),
        sa.Column("active", sa.Boolean(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("telegram_user_id"),
    )
    op.create_table(
        "devices",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("client_id", sa.String(length=36), nullable=False),
        sa.Column("device_id", sa.String(length=128), nullable=False),
        sa.Column("name", sa.String(length=255), nullable=True),
        sa.Column("app_version", sa.String(length=64), nullable=True),
        sa.Column("android_version", sa.String(length=64), nullable=True),
        sa.Column("last_seen_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_sync_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["client_id"], ["clients.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("client_id", "device_id", name="uq_devices_client_device"),
    )
    op.create_index(op.f("ix_devices_client_id"), "devices", ["client_id"], unique=False)
    op.create_table(
        "runbook_steps",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("runbook_id", sa.String(length=36), nullable=False),
        sa.Column("step_key", sa.String(length=128), nullable=False),
        sa.Column("text", sa.Text(), nullable=False),
        sa.Column("options_json", sa.JSON(), nullable=False),
        sa.Column("next_rules_json", sa.JSON(), nullable=False),
        sa.Column("action", sa.String(length=128), nullable=True),
        sa.ForeignKeyConstraint(["runbook_id"], ["runbooks.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("runbook_id", "step_key", name="uq_runbook_steps_key"),
    )
    op.create_index(
        op.f("ix_runbook_steps_runbook_id"),
        "runbook_steps",
        ["runbook_id"],
        unique=False,
    )
    op.create_table(
        "tickets",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("public_id", sa.String(length=64), nullable=False),
        sa.Column("client_id", sa.String(length=36), nullable=False),
        sa.Column("device_id", sa.String(length=36), nullable=True),
        sa.Column("telegram_chat_id", sa.String(length=64), nullable=False),
        sa.Column("issue_type", sa.String(length=64), nullable=False),
        sa.Column("status", sa.String(length=32), nullable=False),
        sa.Column("priority", sa.String(length=32), nullable=False),
        sa.Column("assigned_to", sa.String(length=36), nullable=True),
        sa.Column("source", sa.String(length=32), nullable=False),
        sa.Column("closed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["assigned_to"], ["support_operators.id"]),
        sa.ForeignKeyConstraint(["client_id"], ["clients.id"]),
        sa.ForeignKeyConstraint(["device_id"], ["devices.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("public_id"),
    )
    op.create_index(op.f("ix_tickets_assigned_to"), "tickets", ["assigned_to"], unique=False)
    op.create_index(op.f("ix_tickets_client_id"), "tickets", ["client_id"], unique=False)
    op.create_index(op.f("ix_tickets_device_id"), "tickets", ["device_id"], unique=False)
    op.create_index(
        op.f("ix_tickets_telegram_chat_id"),
        "tickets",
        ["telegram_chat_id"],
        unique=False,
    )
    op.create_table(
        "ticket_events",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("ticket_id", sa.String(length=36), nullable=False),
        sa.Column("event_type", sa.String(length=64), nullable=False),
        sa.Column("payload_json", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["ticket_id"], ["tickets.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        op.f("ix_ticket_events_ticket_id"),
        "ticket_events",
        ["ticket_id"],
        unique=False,
    )
    op.create_table(
        "ticket_messages",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("ticket_id", sa.String(length=36), nullable=False),
        sa.Column("sender_type", sa.String(length=32), nullable=False),
        sa.Column("sender_id", sa.String(length=128), nullable=True),
        sa.Column("text", sa.Text(), nullable=True),
        sa.Column("attachment_url", sa.String(length=2048), nullable=True),
        sa.Column("telegram_message_id", sa.String(length=64), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["ticket_id"], ["tickets.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        op.f("ix_ticket_messages_ticket_id"),
        "ticket_messages",
        ["ticket_id"],
        unique=False,
    )
    op.create_table(
        "support_sessions",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("telegram_user_id", sa.String(length=64), nullable=False),
        sa.Column("telegram_chat_id", sa.String(length=64), nullable=False),
        sa.Column("client_id", sa.String(length=36), nullable=True),
        sa.Column("ticket_id", sa.String(length=36), nullable=True),
        sa.Column("runbook_code", sa.String(length=128), nullable=True),
        sa.Column("current_step_key", sa.String(length=128), nullable=True),
        sa.Column("state", sa.String(length=64), nullable=False),
        sa.Column("history_json", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["client_id"], ["clients.id"]),
        sa.ForeignKeyConstraint(["ticket_id"], ["tickets.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "telegram_user_id",
            "telegram_chat_id",
            name="uq_support_sessions_chat",
        ),
    )
    op.create_index(
        op.f("ix_support_sessions_client_id"),
        "support_sessions",
        ["client_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_support_sessions_telegram_chat_id"),
        "support_sessions",
        ["telegram_chat_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_support_sessions_telegram_user_id"),
        "support_sessions",
        ["telegram_user_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_support_sessions_ticket_id"),
        "support_sessions",
        ["ticket_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(op.f("ix_support_sessions_ticket_id"), table_name="support_sessions")
    op.drop_index(op.f("ix_support_sessions_telegram_user_id"), table_name="support_sessions")
    op.drop_index(op.f("ix_support_sessions_telegram_chat_id"), table_name="support_sessions")
    op.drop_index(op.f("ix_support_sessions_client_id"), table_name="support_sessions")
    op.drop_table("support_sessions")
    op.drop_index(op.f("ix_ticket_messages_ticket_id"), table_name="ticket_messages")
    op.drop_table("ticket_messages")
    op.drop_index(op.f("ix_ticket_events_ticket_id"), table_name="ticket_events")
    op.drop_table("ticket_events")
    op.drop_index(op.f("ix_tickets_telegram_chat_id"), table_name="tickets")
    op.drop_index(op.f("ix_tickets_device_id"), table_name="tickets")
    op.drop_index(op.f("ix_tickets_client_id"), table_name="tickets")
    op.drop_index(op.f("ix_tickets_assigned_to"), table_name="tickets")
    op.drop_table("tickets")
    op.drop_index(op.f("ix_runbook_steps_runbook_id"), table_name="runbook_steps")
    op.drop_table("runbook_steps")
    op.drop_index(op.f("ix_devices_client_id"), table_name="devices")
    op.drop_table("devices")
    op.drop_table("support_operators")
    op.drop_index(op.f("ix_runbooks_code"), table_name="runbooks")
    op.drop_table("runbooks")
    op.drop_table("clients")
