"""expand ticket lifecycle metrics

Revision ID: 202604290001
Revises: 202604280001
Create Date: 2026-04-29 00:01:00
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "202604290001"
down_revision: str | None = "202604280001"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column(
        "tickets", sa.Column("first_response_at", sa.DateTime(timezone=True), nullable=True)
    )
    op.add_column("tickets", sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True))
    op.add_column("tickets", sa.Column("reopened_at", sa.DateTime(timezone=True), nullable=True))
    op.create_index(
        "ix_tickets_status_created_at", "tickets", ["status", "created_at"], unique=False
    )
    op.create_index(
        "ix_tickets_source_created_at", "tickets", ["source", "created_at"], unique=False
    )
    op.create_index(
        "ix_tickets_issue_type_created_at",
        "tickets",
        ["issue_type", "created_at"],
        unique=False,
    )
    op.create_index(
        "ix_ticket_events_type_created_at",
        "ticket_events",
        ["event_type", "created_at"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index("ix_ticket_events_type_created_at", table_name="ticket_events")
    op.drop_index("ix_tickets_issue_type_created_at", table_name="tickets")
    op.drop_index("ix_tickets_source_created_at", table_name="tickets")
    op.drop_index("ix_tickets_status_created_at", table_name="tickets")
    op.drop_column("tickets", "reopened_at")
    op.drop_column("tickets", "resolved_at")
    op.drop_column("tickets", "first_response_at")
