"""create ticket external refs

Revision ID: 202604280001
Revises: 202604270002
Create Date: 2026-04-28 00:01:00
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "202604280001"
down_revision: str | None = "202604270002"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "ticket_external_refs",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("ticket_id", sa.String(length=36), nullable=False),
        sa.Column("external_system", sa.String(length=64), nullable=False),
        sa.Column("external_contact_id", sa.String(length=128), nullable=True),
        sa.Column("external_conversation_id", sa.String(length=128), nullable=True),
        sa.Column("external_url", sa.String(length=2048), nullable=True),
        sa.Column("metadata_json", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["ticket_id"], ["tickets.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "ticket_id",
            "external_system",
            name="uq_ticket_external_refs_system",
        ),
    )
    op.create_index(
        op.f("ix_ticket_external_refs_external_conversation_id"),
        "ticket_external_refs",
        ["external_conversation_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_ticket_external_refs_external_system"),
        "ticket_external_refs",
        ["external_system"],
        unique=False,
    )
    op.create_index(
        op.f("ix_ticket_external_refs_ticket_id"),
        "ticket_external_refs",
        ["ticket_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(op.f("ix_ticket_external_refs_ticket_id"), table_name="ticket_external_refs")
    op.drop_index(
        op.f("ix_ticket_external_refs_external_system"),
        table_name="ticket_external_refs",
    )
    op.drop_index(
        op.f("ix_ticket_external_refs_external_conversation_id"),
        table_name="ticket_external_refs",
    )
    op.drop_table("ticket_external_refs")
