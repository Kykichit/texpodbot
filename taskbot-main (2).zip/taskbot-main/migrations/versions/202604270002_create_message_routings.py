"""create message routings

Revision ID: 202604270002
Revises: 202604270001
Create Date: 2026-04-27 00:02:00
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op

revision: str = "202604270002"
down_revision: str | None = "202604270001"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.create_table(
        "message_routings",
        sa.Column("id", sa.String(length=36), nullable=False),
        sa.Column("ticket_id", sa.String(length=36), nullable=False),
        sa.Column("client_chat_id", sa.String(length=64), nullable=False),
        sa.Column("support_group_message_id", sa.String(length=64), nullable=False),
        sa.Column("support_thread_id", sa.String(length=64), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.ForeignKeyConstraint(["ticket_id"], ["tickets.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "support_group_message_id",
            "support_thread_id",
            name="uq_message_routings_support_context",
        ),
        sa.UniqueConstraint("ticket_id", name="uq_message_routings_ticket_id"),
    )
    op.create_index(
        op.f("ix_message_routings_client_chat_id"),
        "message_routings",
        ["client_chat_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_message_routings_support_group_message_id"),
        "message_routings",
        ["support_group_message_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_message_routings_support_thread_id"),
        "message_routings",
        ["support_thread_id"],
        unique=False,
    )
    op.create_index(
        op.f("ix_message_routings_ticket_id"),
        "message_routings",
        ["ticket_id"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(op.f("ix_message_routings_ticket_id"), table_name="message_routings")
    op.drop_index(op.f("ix_message_routings_support_thread_id"), table_name="message_routings")
    op.drop_index(
        op.f("ix_message_routings_support_group_message_id"),
        table_name="message_routings",
    )
    op.drop_index(op.f("ix_message_routings_client_chat_id"), table_name="message_routings")
    op.drop_table("message_routings")
