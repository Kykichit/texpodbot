import httpx
import pytest

from bot.max.adapter import MaxBotApiClient


@pytest.mark.asyncio
async def test_max_adapter_uses_authorization_header_and_message_params(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    seen_request: httpx.Request | None = None

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal seen_request
        seen_request = request
        return httpx.Response(200, json={"message": {"body": {"mid": "message-1"}}})

    transport = httpx.MockTransport(handler)
    async_client = httpx.AsyncClient

    def client_factory(*args: object, **kwargs: object) -> httpx.AsyncClient:
        kwargs["transport"] = transport
        return async_client(*args, **kwargs)

    monkeypatch.setattr(httpx, "AsyncClient", client_factory)
    client = MaxBotApiClient(base_url="https://platform-api.max.ru", token="token")

    result = await client.send_message(chat_id="100", text="hello")

    assert result["message"]["body"]["mid"] == "message-1"
    assert seen_request is not None
    assert seen_request.headers["Authorization"] == "token"
    assert seen_request.url.path == "/messages"
    assert seen_request.url.params["chat_id"] == "100"
