import pytest

from app.config import BotMode, Settings, mask_secret


def valid_settings(**overrides: object) -> Settings:
    values: dict[str, object] = {
        "bot_mode": BotMode.TELEGRAM,
        "database_url": "postgresql+asyncpg://user:password@localhost:5432/support",
        "redis_url": "redis://localhost:6379/0",
        "telegram_bot_token": "1234567890:telegram-secret-token",
        "telegram_webhook_secret": "webhook-secret-value",
        "telegram_webhook_url": "https://support.example.test/webhook/telegram",
        "telegram_support_group_id": "-1001234567890",
    }
    values.update(overrides)
    return Settings(**values)


def test_config_validation_passes_for_required_support_bot_settings() -> None:
    settings = valid_settings()

    settings.validate_runtime()


def test_config_validation_requires_missing_required_variable() -> None:
    settings = valid_settings(database_url=None)

    with pytest.raises(RuntimeError, match="DATABASE_URL or DB_HOST"):
        settings.validate_runtime()


def test_database_url_is_derived_from_structured_db_settings() -> None:
    settings = valid_settings(
        database_url=None,
        db_host="postgres",
        db_port=5432,
        db_name="support",
        db_user="support-user",
        db_password="p@ss word",
    )

    assert settings.database_url == (
        "postgresql+asyncpg://support-user:p%40ss%20word@postgres:5432/support"
    )


def test_redis_url_is_derived_from_structured_redis_settings() -> None:
    settings = valid_settings(
        redis_url=None,
        redis_host="redis",
        redis_port=6379,
        redis_db=2,
        redis_password="redis secret",
    )

    assert settings.redis_url == "redis://:redis%20secret@redis:6379/2"


def test_runtime_validation_requires_max_token_for_both_mode() -> None:
    settings = valid_settings(bot_mode=BotMode.BOTH)

    with pytest.raises(RuntimeError, match="MAX_BOT_TOKEN"):
        settings.validate_runtime()


def test_config_summary_masks_secrets() -> None:
    settings = valid_settings(
        sentry_dsn="https://secret@sentry.example/1",
        chatwoot_enabled=True,
        chatwoot_base_url="https://chatwoot.example.test",
        chatwoot_api_token="chatwoot-secret-token",
        chatwoot_account_id=1,
        chatwoot_inbox_id=2,
        chatwoot_webhook_secret="chatwoot-webhook-secret",
    )

    summary = settings.config_summary()

    assert summary["telegram_bot_token"] != settings.telegram_bot_token
    assert summary["telegram_webhook_secret"] != settings.telegram_webhook_secret
    assert summary["database_url"] != settings.database_url
    assert "telegram-secret-token" not in str(summary)
    assert "chatwoot-secret-token" not in str(summary)
    assert "chatwoot-webhook-secret" not in str(summary)
    assert "password" not in str(summary)
    assert summary["optional_integrations"]["sentry"] == "enabled"
    assert summary["optional_integrations"]["github"] == "disabled"
    assert summary["optional_integrations"]["chatwoot"] == "enabled"


def test_strict_validation_requires_chatwoot_settings_when_enabled() -> None:
    settings = valid_settings(chatwoot_enabled=True, chatwoot_base_url=None)

    with pytest.raises(RuntimeError, match="CHATWOOT_BASE_URL"):
        settings.validate_runtime()


def test_mask_secret_handles_empty_and_short_values() -> None:
    assert mask_secret(None) == "missing"
    assert mask_secret("short") == "***"
