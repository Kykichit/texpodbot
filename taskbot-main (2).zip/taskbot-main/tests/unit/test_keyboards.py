from bot.max.keyboards import build_inline_keyboard as build_max_inline_keyboard
from bot.telegram.keyboards import build_inline_keyboard as build_telegram_inline_keyboard
from domain.models import BotButton


def test_max_keyboard_shape() -> None:
    keyboard = build_max_inline_keyboard((BotButton(text="Help", action="help"),))

    assert keyboard == {
        "type": "inline_keyboard",
        "payload": {
            "buttons": [[{"type": "callback", "text": "Help", "payload": "help"}]],
        },
    }


def test_telegram_keyboard_shape() -> None:
    keyboard = build_telegram_inline_keyboard((BotButton(text="Help", action="help"),))

    assert keyboard is not None
    assert keyboard.inline_keyboard[0][0].text == "Help"
    assert keyboard.inline_keyboard[0][0].callback_data == "help"
