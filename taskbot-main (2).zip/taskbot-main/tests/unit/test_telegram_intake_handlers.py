from bot.telegram.intake_handlers import TelegramChatRole, classify_telegram_chat


def test_private_chat_uses_intake_flow() -> None:
    assert (
        classify_telegram_chat(
            chat_type="private",
            chat_id="100",
            support_group_id="-100",
        )
        == TelegramChatRole.PRIVATE
    )


def test_configured_support_group_uses_support_bridge() -> None:
    assert (
        classify_telegram_chat(
            chat_type="supergroup",
            chat_id="-100",
            support_group_id="-100",
        )
        == TelegramChatRole.SUPPORT_GROUP
    )


def test_other_group_is_not_intake_flow() -> None:
    assert (
        classify_telegram_chat(
            chat_type="group",
            chat_id="-200",
            support_group_id="-100",
        )
        == TelegramChatRole.OTHER_GROUP
    )
