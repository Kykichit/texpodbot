import os

import pytest

from bot.telegram.proxy import mask_proxy_url, resolve_telegram_proxy_url


@pytest.fixture(autouse=True)
def clear_proxy_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for key in ("TELEGRAM_PROXY_URL", "HTTPS_PROXY", "HTTP_PROXY", "ALL_PROXY"):
        monkeypatch.delenv(key, raising=False)


def test_explicit_proxy_has_highest_priority(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("TELEGRAM_PROXY_URL", "http://telegram-env-proxy:8080")
    monkeypatch.setenv("HTTPS_PROXY", "http://env-proxy:8080")
    monkeypatch.setattr("urllib.request.getproxies", lambda: {"https": "http://system-proxy:8080"})

    assert resolve_telegram_proxy_url("http://explicit-proxy:8080") == "http://explicit-proxy:8080"


def test_telegram_proxy_url_env_precedes_generic_proxy_env(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("TELEGRAM_PROXY_URL", "http://telegram-env-proxy:8080")
    monkeypatch.setenv("HTTPS_PROXY", "http://https-proxy:8080")
    monkeypatch.setattr("urllib.request.getproxies", lambda: {})

    assert resolve_telegram_proxy_url() == "http://telegram-env-proxy:8080"


def test_https_proxy_fallback_works(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HTTPS_PROXY", "http://https-proxy:8080")
    monkeypatch.setattr("urllib.request.getproxies", lambda: {})

    assert resolve_telegram_proxy_url() == "http://https-proxy:8080"


def test_http_proxy_fallback_works(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HTTP_PROXY", "http://http-proxy:8080")
    monkeypatch.setattr("urllib.request.getproxies", lambda: {})

    assert resolve_telegram_proxy_url() == "http://http-proxy:8080"


def test_all_proxy_fallback_works(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("ALL_PROXY", "http://all-proxy:8080")
    monkeypatch.setattr("urllib.request.getproxies", lambda: {})

    assert resolve_telegram_proxy_url() == "http://all-proxy:8080"


def test_system_proxy_fallback_via_urllib_getproxies(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("urllib.request.getproxies", lambda: {"https": "http://system-proxy:8080"})

    assert resolve_telegram_proxy_url() == "http://system-proxy:8080"


def test_system_getproxies_picks_https_before_http(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "urllib.request.getproxies",
        lambda: {
            "http": "http://system-http-proxy:8080",
            "https": "http://system-https-proxy:8080",
        },
    )

    assert resolve_telegram_proxy_url() == "http://system-https-proxy:8080"


def test_empty_proxy_values_are_ignored(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("HTTPS_PROXY", " ")
    monkeypatch.setenv("HTTP_PROXY", "")
    monkeypatch.setenv("ALL_PROXY", "http://all-proxy:8080")
    monkeypatch.setattr("urllib.request.getproxies", lambda: {"https": "http://system-proxy:8080"})

    assert resolve_telegram_proxy_url(" ") == "http://all-proxy:8080"


def test_mask_proxy_url_hides_password() -> None:
    assert mask_proxy_url(None) == "missing"
    assert mask_proxy_url("http://127.0.0.1:10809") == "http://127.0.0.1:10809"
    assert mask_proxy_url("http://user:pass@host:8080") == "http://user:***@host:8080"


def test_resolver_does_not_mutate_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("urllib.request.getproxies", lambda: {})

    resolve_telegram_proxy_url()

    assert "TELEGRAM_PROXY_URL" not in os.environ
