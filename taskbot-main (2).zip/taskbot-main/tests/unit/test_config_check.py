import json

from app.config import BotMode, Settings
from app.config_check import build_config_check_result
from app.main import build_parser, config_check

SAMPLE_DATABASE_URL = "postgresql+asyncpg://support:example@localhost:5432/support"
SAMPLE_REDIS_URL = "redis://:example@localhost:6379/0"
SAMPLE_TELEGRAM_VALUE = "1234567890:telegram-value-example"
SAMPLE_WEBHOOK_VALUE = "webhook-value-example"
SAMPLE_WEBHOOK_URL = "https://support.example.test/telegram/webhook"
SAMPLE_GITHUB_VALUE = "github-value-example"
SAMPLE_CHATWOOT_URL = "https://chatwoot.example.test"
SAMPLE_CHATWOOT_API_VALUE = "chatwoot-api-value-example"
SAMPLE_CHATWOOT_WEBHOOK_VALUE = "chatwoot-webhook-value-example"


def partial_settings(**overrides: object) -> Settings:
    values: dict[str, object] = {
        "bot_mode": BotMode.TELEGRAM,
        "database_url": None,
        "redis_url": None,
        "telegram_bot_token": None,
        "telegram_webhook_secret": None,
        "telegram_webhook_url": None,
        "telegram_support_group_id": None,
    }
    values.update(overrides)
    return Settings(**values)


def configured_settings(**overrides: object) -> Settings:
    values: dict[str, object] = {
        "bot_mode": BotMode.TELEGRAM,
        "database_url": SAMPLE_DATABASE_URL,
        "redis_url": SAMPLE_REDIS_URL,
        "telegram_bot_token": SAMPLE_TELEGRAM_VALUE,
        "telegram_webhook_secret": SAMPLE_WEBHOOK_VALUE,
        "telegram_webhook_url": SAMPLE_WEBHOOK_URL,
        "telegram_support_group_id": "-1001234567890",
    }
    values.update(overrides)
    return Settings(**values)


def test_normal_config_check_succeeds_with_partial_local_config() -> None:
    result = build_config_check_result(partial_settings())

    assert result.exit_code == 0
    assert "Configuration check: ok" in result.output
    assert "DATABASE_URL configured: no" in result.output


def test_strict_mode_fails_when_database_url_missing() -> None:
    result = build_config_check_result(configured_settings(database_url=None), strict=True)

    assert result.exit_code == 1
    assert "DATABASE_URL or DB_HOST" in result.output


def test_strict_mode_fails_when_telegram_token_missing_for_telegram_mode() -> None:
    result = build_config_check_result(configured_settings(telegram_bot_token=None), strict=True)

    assert result.exit_code == 1
    assert "TELEGRAM_BOT_TOKEN" in result.output


def test_strict_mode_requires_max_token_only_for_max_modes() -> None:
    telegram_result = build_config_check_result(configured_settings(), strict=True)
    max_result = build_config_check_result(
        configured_settings(bot_mode=BotMode.MAX, max_bot_token=None),
        strict=True,
    )
    both_result = build_config_check_result(
        configured_settings(bot_mode=BotMode.BOTH, max_bot_token=None),
        strict=True,
    )

    assert telegram_result.exit_code == 0
    assert "MAX_BOT_TOKEN" not in telegram_result.output
    assert max_result.exit_code == 1
    assert "MAX_BOT_TOKEN" in max_result.output
    assert both_result.exit_code == 1
    assert "MAX_BOT_TOKEN" in both_result.output


def test_json_output_is_valid_json_and_masks_secrets() -> None:
    result = build_config_check_result(
        configured_settings(
            telegram_proxy_url="http://user:proxy-password@proxy.example.test:8080",
            sentry_dsn="https://sentry.example.test/1",
            github_token=SAMPLE_GITHUB_VALUE,
            github_repo="Kykichit/taskbot",
            chatwoot_enabled=True,
            chatwoot_base_url=SAMPLE_CHATWOOT_URL,
            chatwoot_api_token=SAMPLE_CHATWOOT_API_VALUE,
            chatwoot_account_id=1,
            chatwoot_inbox_id=2,
            chatwoot_webhook_secret=SAMPLE_CHATWOOT_WEBHOOK_VALUE,
        ),
        json_output=True,
    )

    payload = json.loads(result.output)
    assert result.exit_code == 0
    assert payload["database_url_configured"] is True
    assert payload["telegram_proxy_configured"] is True
    assert payload["github"] == "enabled"
    assert payload["chatwoot"] == "enabled"
    assert payload["chatwoot_enabled"] is True
    assert payload["chatwoot_api_token_configured"] is True
    assert payload["chatwoot_webhook_secret_configured"] is True
    assert SAMPLE_DATABASE_URL not in result.output
    assert SAMPLE_REDIS_URL not in result.output
    assert SAMPLE_TELEGRAM_VALUE not in result.output
    assert SAMPLE_WEBHOOK_VALUE not in result.output
    assert SAMPLE_WEBHOOK_URL not in result.output
    assert SAMPLE_GITHUB_VALUE not in result.output
    assert SAMPLE_CHATWOOT_API_VALUE not in result.output
    assert SAMPLE_CHATWOOT_WEBHOOK_VALUE not in result.output
    assert "proxy-password" not in result.output


def test_human_output_has_no_secret_values() -> None:
    result = build_config_check_result(
        configured_settings(
            telegram_proxy_url="http://user:proxy-password@proxy.example.test:8080",
            chatwoot_enabled=True,
            chatwoot_base_url=SAMPLE_CHATWOOT_URL,
            chatwoot_api_token=SAMPLE_CHATWOOT_API_VALUE,
            chatwoot_account_id=1,
            chatwoot_inbox_id=2,
            chatwoot_webhook_secret=SAMPLE_CHATWOOT_WEBHOOK_VALUE,
        )
    )

    assert SAMPLE_DATABASE_URL not in result.output
    assert SAMPLE_REDIS_URL not in result.output
    assert SAMPLE_TELEGRAM_VALUE not in result.output
    assert SAMPLE_WEBHOOK_VALUE not in result.output
    assert SAMPLE_WEBHOOK_URL not in result.output
    assert SAMPLE_CHATWOOT_API_VALUE not in result.output
    assert SAMPLE_CHATWOOT_WEBHOOK_VALUE not in result.output
    assert "proxy-password" not in result.output
    assert "TELEGRAM_PROXY configured: yes" in result.output
    assert "Chatwoot integration: enabled" in result.output
    assert "CHATWOOT_ENABLED: yes" in result.output


def test_telegram_support_group_id_is_masked() -> None:
    result = build_config_check_result(configured_settings())

    assert "-1001234567890" not in result.output
    assert "***7890" in result.output


def test_config_check_returns_non_zero_for_strict_failure(capsys) -> None:  # type: ignore[no-untyped-def]
    exit_code = config_check(partial_settings(), strict=True)

    captured = capsys.readouterr()
    assert exit_code == 1
    assert "Missing required variables" in captured.out


def test_help_shows_config_check_options(capsys) -> None:  # type: ignore[no-untyped-def]
    parser = build_parser()

    try:
        parser.parse_args(["config-check", "--help"])
    except SystemExit as exc:
        assert exc.code == 0

    captured = capsys.readouterr()
    assert "--strict" in captured.out
    assert "--json" in captured.out
