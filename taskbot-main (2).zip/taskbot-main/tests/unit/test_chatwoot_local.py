from pathlib import Path

import pytest
from scripts.chatwoot_local import (
    DEFAULT_CHATWOOT_WEBHOOK_URL,
    build_compose_cmd,
    check_inbox_account_consistency,
    check_url,
    command_webhook_info,
    default_chatwoot_dir,
    read_env_keys_status,
    redact,
    require_confirm,
    resolve_chatwoot_dir,
    validate_compose_file,
)


class FakeResponse:
    status = 200

    def __enter__(self) -> "FakeResponse":
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def getcode(self) -> int:
        return self.status


class FakeComposePath:
    def __init__(self, text: str, *, exists: bool = True) -> None:
        self.text = text
        self._exists = exists

    def exists(self) -> bool:
        return self._exists

    def read_text(self, *, encoding: str) -> str:
        assert encoding == "utf-8"
        return self.text

    def __str__(self) -> str:
        return "docker-compose.chatwoot.yml"


class FakeEnvPath:
    def __init__(self, text: str) -> None:
        self.text = text

    def exists(self) -> bool:
        return True

    def read_text(self, *, encoding: str) -> str:
        assert encoding == "utf-8"
        return self.text


class FakeCompletedProcess:
    def __init__(self, *, returncode: int, stdout: str = "", stderr: str = "") -> None:
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr


def test_default_chatwoot_dir_is_windows_local_path() -> None:
    assert str(default_chatwoot_dir()) == r"C:\chatwoot-local"


def test_resolve_chatwoot_dir_supports_windows_path() -> None:
    path = resolve_chatwoot_dir({"CHATWOOT_LOCAL_DIR": r"C:\chatwoot-local"})

    assert str(path) == r"C:\chatwoot-local"


def test_build_compose_cmd_uses_argument_list_without_shell_string() -> None:
    command = build_compose_cmd(
        Path(r"C:\chatwoot-local"),
        "docker-compose.chatwoot.yml",
        ["ps"],
    )

    assert command == [
        "docker",
        "compose",
        "-f",
        str(Path(r"C:\chatwoot-local") / "docker-compose.chatwoot.yml"),
        "ps",
    ]
    assert all(isinstance(part, str) for part in command)


def test_reset_requires_explicit_confirmation() -> None:
    with pytest.raises(RuntimeError, match="--confirm"):
        require_confirm(False)

    require_confirm(True)


def test_redact_hides_secrets() -> None:
    assert redact("CHATWOOT_WEBHOOK_SECRET", "secret-value") == "configured"
    assert redact("CHATWOOT_API_TOKEN", "token-value") == "configured"
    assert redact("CHATWOOT_BASE_URL", "http://host.docker.internal:3000") == (
        "http://host.docker.internal:3000"
    )
    assert redact("CHATWOOT_WEBHOOK_SECRET", "") == "missing"


def test_validate_compose_file_requires_pgvector_image() -> None:
    result = validate_compose_file(
        FakeComposePath("services:\n  postgres:\n    image: postgres:16-alpine\n")  # type: ignore[arg-type]
    )

    assert result.ok is False
    assert "pgvector/pgvector:pg16" in result.message


def test_validate_compose_file_accepts_pgvector_image() -> None:
    result = validate_compose_file(
        FakeComposePath("services:\n  postgres:\n    image: pgvector/pgvector:pg16\n")  # type: ignore[arg-type]
    )

    assert result.ok is True


def test_read_env_keys_status_returns_yes_no_only() -> None:
    status = read_env_keys_status(
        FakeEnvPath(  # type: ignore[arg-type]
            "CHATWOOT_ENABLED=true\nCHATWOOT_API_TOKEN=secret-token\nCHATWOOT_ACCOUNT_ID=\n"
        ),
        ["CHATWOOT_ENABLED", "CHATWOOT_API_TOKEN", "CHATWOOT_ACCOUNT_ID"],
    )

    assert status == {
        "CHATWOOT_ENABLED": "yes",
        "CHATWOOT_API_TOKEN": "yes",
        "CHATWOOT_ACCOUNT_ID": "no",
    }
    assert "secret-token" not in status.values()


def test_check_url_uses_injected_opener() -> None:
    result = check_url("http://localhost:3000", opener=lambda *args, **kwargs: FakeResponse())

    assert result.ok is True
    assert result.status_code == 200


def test_webhook_info_does_not_print_secret(capsys: pytest.CaptureFixture[str]) -> None:
    exit_code = command_webhook_info()

    captured = capsys.readouterr()
    assert exit_code == 0
    assert DEFAULT_CHATWOOT_WEBHOOK_URL in captured.out
    assert "<secret from Chatwoot UI>" in captured.out
    assert "secret-value" not in captured.out


def test_check_inbox_account_consistency_detects_match() -> None:
    commands: list[list[str]] = []

    def runner(command: list[str], **_kwargs: object) -> FakeCompletedProcess:
        commands.append(command)
        return FakeCompletedProcess(returncode=0, stdout="1,3,Channel::Api\n")

    check = check_inbox_account_consistency(
        {
            "CHATWOOT_LOCAL_DIR": r"C:\chatwoot-local",
            "CHATWOOT_LOCAL_COMPOSE_FILE": "docker-compose.chatwoot.yml",
            "CHATWOOT_ACCOUNT_ID": "3",
            "CHATWOOT_INBOX_ID": "1",
        },
        runner=runner,  # type: ignore[arg-type]
    )

    assert check.level == "OK"
    assert "api_access_token" not in " ".join(commands[0]).lower()


def test_check_inbox_account_consistency_detects_mismatch() -> None:
    def runner(_command: list[str], **_kwargs: object) -> FakeCompletedProcess:
        return FakeCompletedProcess(returncode=0, stdout="1,99,Channel::Api\n")

    check = check_inbox_account_consistency(
        {"CHATWOOT_ACCOUNT_ID": "3", "CHATWOOT_INBOX_ID": "1"},
        runner=runner,  # type: ignore[arg-type]
    )

    assert check.level == "FAIL"
    assert "expected 3" in check.detail


def test_docs_describe_telegram_conflict_troubleshooting() -> None:
    docs = Path("docs/chatwoot-local-setup.md").read_text(encoding="utf-8")

    assert "TelegramConflictError" in docs
    assert "stop-taskbot-polling" in docs
