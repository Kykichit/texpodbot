import pytest

from domain.models import BotRequest, InteractionType, Platform
from domain.use_cases import BotDialogUseCase


@pytest.mark.asyncio
async def test_start_returns_menu_buttons() -> None:
    use_case = BotDialogUseCase()

    response = await use_case.handle(
        BotRequest(
            platform=Platform.TELEGRAM,
            user_id="1",
            chat_id="10",
            interaction_type=InteractionType.COMMAND,
            text="/start",
        )
    )

    assert "единый бот-шаблон" in response.text
    assert [button.action for button in response.buttons] == ["main_menu", "help"]


@pytest.mark.asyncio
async def test_text_is_platform_neutral() -> None:
    use_case = BotDialogUseCase()

    response = await use_case.handle(
        BotRequest(
            platform=Platform.MAX,
            user_id="1",
            chat_id="10",
            interaction_type=InteractionType.TEXT,
            text="hello",
        )
    )

    assert response.text == "Получил сообщение: hello"


@pytest.mark.asyncio
async def test_callback_help_returns_help_text() -> None:
    use_case = BotDialogUseCase()

    response = await use_case.handle(
        BotRequest(
            platform=Platform.TELEGRAM,
            user_id="1",
            chat_id="10",
            interaction_type=InteractionType.CALLBACK,
            action="help",
        )
    )

    assert "Доступные команды" in response.text
