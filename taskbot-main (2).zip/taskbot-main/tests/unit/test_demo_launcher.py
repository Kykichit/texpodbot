from pathlib import Path

from app.config import AppEnv, Settings

ROOT = Path(__file__).resolve().parents[2]


def test_demo_environment_is_supported() -> None:
    settings = Settings(
        app_env="demo",
        database_url="postgresql+asyncpg://support_demo:support_demo@localhost:15432/support_demo",
        redis_url="redis://localhost:16379/0",
        telegram_bot_token="0000000000:demo_token_not_real",
    )

    assert settings.app_env == AppEnv.DEMO


def test_demo_env_example_uses_only_dummy_values() -> None:
    env_text = (ROOT / ".env.demo.example").read_text(encoding="utf-8")

    assert "APP_ENV=demo" in env_text
    assert "LIVE_TESTS_ENABLED=false" in env_text
    assert "CHATWOOT_ENABLED=false" in env_text
    assert "demo_token_not_real" in env_text
    assert "DB_USER=support_demo" in env_text
    assert "DB_PASSWORD=support_demo" in env_text
    assert "xox" not in env_text.lower()
    assert "sk-" not in env_text.lower()
    assert "TELEGRAM_BOT_TOKEN=0000000000:demo_token_not_real" in env_text
    assert "MAX_BOT_TOKEN=" in env_text


def test_demo_compose_uses_isolated_services_ports_and_volumes() -> None:
    compose_text = (ROOT / "docker-compose.demo.yml").read_text(encoding="utf-8")

    assert "demo-app:" in compose_text
    assert "demo-postgres:" in compose_text
    assert "demo-redis:" in compose_text
    assert "${POSTGRES_PORT:-15432}:5432" in compose_text
    assert "${REDIS_PORT:-16379}:6379" in compose_text
    assert "18080:8080" in compose_text
    assert "taskbot_demo_postgres_data:" in compose_text
    assert "taskbot_demo_redis_data:" in compose_text


def test_makefile_exposes_demo_targets_and_reset_guard() -> None:
    makefile_text = (ROOT / "Makefile").read_text(encoding="utf-8")

    for target in (
        "demo-copy-env:",
        "demo-doctor:",
        "demo-infra-up:",
        "demo-migrate:",
        "demo-run:",
        "demo-start:",
        "demo-stop:",
        "demo-reset:",
        "demo-seed:",
        "demo-logs:",
        "demo-ps:",
        "demo-health:",
    ):
        assert target in makefile_text

    assert "DEMO_ALLOW_RESET" in makefile_text
    assert "down -v --remove-orphans" in makefile_text
