from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[2]


def load_vps_compose() -> dict:
    return yaml.safe_load((ROOT / "docker-compose.vps.yml").read_text(encoding="utf-8"))


def test_vps_compose_contains_required_services() -> None:
    compose = load_vps_compose()

    assert set(compose["services"]) >= {
        "caddy",
        "app",
        "postgres",
        "redis",
        "chatwoot-rails",
        "chatwoot-worker",
    }


def test_vps_compose_uses_pgvector_postgres() -> None:
    compose = load_vps_compose()

    assert compose["services"]["postgres"]["image"] == "pgvector/pgvector:pg16"


def test_vps_compose_keeps_internal_services_private() -> None:
    compose = load_vps_compose()
    services = compose["services"]

    assert "ports" not in services["app"]
    assert services["app"]["expose"] == ["8080"]
    assert "ports" not in services["postgres"]
    assert "ports" not in services["redis"]
    assert "ports" not in services["chatwoot-rails"]
    assert services["chatwoot-rails"]["expose"] == ["3000"]


def test_vps_compose_only_caddy_publishes_http_ports() -> None:
    compose = load_vps_compose()
    services = compose["services"]

    assert services["caddy"]["ports"] == ["80:80", "443:443"]
    published = [name for name, service in services.items() if "ports" in service]
    assert published == ["caddy"]


def test_vps_compose_defines_healthchecks_for_long_running_services() -> None:
    compose = load_vps_compose()

    for service_name in (
        "caddy",
        "app",
        "postgres",
        "redis",
        "chatwoot-rails",
        "chatwoot-worker",
    ):
        assert "healthcheck" in compose["services"][service_name]


def test_vps_env_examples_are_placeholder_only_and_fail_closed() -> None:
    taskbot_env = (ROOT / ".env.vps.example").read_text(encoding="utf-8")
    chatwoot_env = (ROOT / ".env.chatwoot.production.example").read_text(encoding="utf-8")
    compose_check_env = (ROOT / ".env.vps.compose-check.example").read_text(encoding="utf-8")
    chatwoot_compose_check_env = (ROOT / ".env.chatwoot.compose-check.example").read_text(
        encoding="utf-8"
    )

    assert "CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=false" in taskbot_env
    assert "APP_ENV=production" in taskbot_env
    assert "DB_HOST=postgres" in taskbot_env
    assert "REDIS_HOST=redis" in taskbot_env
    assert "REDIS_URL=redis://redis:6379/1" in chatwoot_env
    assert "CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=false" in compose_check_env
    assert "dummy-" in compose_check_env
    assert "DATABASE_URL=postgresql://chatwoot:dummy-chatwoot-password@postgres:5432/chatwoot" in (
        chatwoot_compose_check_env
    )

    forbidden_real_values = ("1234567890:", "xoxb-", "ghp_", "sk-")
    assert not any(value in taskbot_env for value in forbidden_real_values)
    assert not any(value in chatwoot_env for value in forbidden_real_values)
    assert not any(value in chatwoot_compose_check_env for value in forbidden_real_values)


def test_vps_docs_include_chatwoot_webhook_requirements() -> None:
    docs = (ROOT / "docs" / "vps-all-in-one-chatwoot.md").read_text(encoding="utf-8")

    assert "https://<bot-domain>/chatwoot/webhook" in docs
    assert "message_created" in docs
    assert "conversation_status_changed" in docs
    assert "conversation_updated" in docs
    assert "CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=false" in docs


def test_vps_setup_script_documents_repeatable_deploy_flow() -> None:
    script = (ROOT / "scripts" / "setup.sh").read_text(encoding="utf-8")

    assert "docker compose --env-file" in script
    assert "CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS" in script
    assert "db:chatwoot_prepare" in script
    assert "python -m app.main db-upgrade" in script
