from pathlib import Path
from shutil import rmtree
from uuid import uuid4

from scripts.doctor import validate_taskbot_env, validate_vps_env

ROOT = Path(__file__).resolve().parents[2]


def make_workspace_tmp() -> Path:
    path = ROOT / ".pytest-tmp-doctor" / uuid4().hex
    path.mkdir(parents=True)
    return path


def write_env(path: Path, values: dict[str, str]) -> Path:
    path.write_text(
        "\n".join(f"{key}={value}" for key, value in values.items()),
        encoding="utf-8",
    )
    return path


def test_doctor_accepts_structured_production_vps_env() -> None:
    tmp_path = make_workspace_tmp()
    try:
        taskbot_env = write_env(
            tmp_path / ".env.vps",
            {
                "APP_ENV": "production",
                "BOT_MODE": "telegram",
                "BOT_DOMAIN": "bot.example.com",
                "CHATWOOT_DOMAIN": "chatwoot.example.com",
                "ACME_EMAIL": "ops@example.com",
                "POSTGRES_SUPER_PASSWORD": "super-secret",
                "TASKBOT_DB_PASSWORD": "taskbot-secret",
                "CHATWOOT_DB_PASSWORD": "chatwoot-secret",
                "TELEGRAM_BOT_TOKEN": "1234567890:token",
                "TELEGRAM_WEBHOOK_SECRET": "telegram-webhook-secret",
                "CHATWOOT_API_TOKEN": "chatwoot-api-token",
                "CHATWOOT_ACCOUNT_ID": "1",
                "CHATWOOT_INBOX_ID": "2",
                "CHATWOOT_WEBHOOK_SECRET": "chatwoot-webhook-secret",
                "CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS": "false",
            },
        )
        chatwoot_env = write_env(
            tmp_path / ".env.chatwoot.production",
            {"SECRET_KEY_BASE": "a" * 64},
        )

        assert validate_vps_env(taskbot_env, chatwoot_env) == []
    finally:
        rmtree(tmp_path, ignore_errors=True)


def test_doctor_rejects_placeholders_and_unsigned_production_webhooks() -> None:
    tmp_path = make_workspace_tmp()
    try:
        taskbot_env = write_env(
            tmp_path / ".env.vps",
            {
                "APP_ENV": "production",
                "BOT_MODE": "telegram",
                "BOT_DOMAIN": "localhost",
                "CHATWOOT_DOMAIN": "chatwoot.example.test",
                "ACME_EMAIL": "admin@example.test",
                "POSTGRES_SUPER_PASSWORD": "dummy-postgres-password",
                "TASKBOT_DB_PASSWORD": "",
                "CHATWOOT_DB_PASSWORD": "dummy-chatwoot-password",
                "TELEGRAM_BOT_TOKEN": "0000000000:demo_token_not_real",
                "TELEGRAM_WEBHOOK_SECRET": "",
                "CHATWOOT_API_TOKEN": "dummy-chatwoot-token",
                "CHATWOOT_ACCOUNT_ID": "1",
                "CHATWOOT_INBOX_ID": "2",
                "CHATWOOT_WEBHOOK_SECRET": "dummy-chatwoot-secret",
                "CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS": "true",
            },
        )
        chatwoot_env = write_env(tmp_path / ".env.chatwoot.production", {"SECRET_KEY_BASE": ""})

        issues = validate_vps_env(taskbot_env, chatwoot_env)

        assert {issue.key for issue in issues} >= {
            "BOT_DOMAIN",
            "CHATWOOT_DOMAIN",
            "ACME_EMAIL",
            "TASKBOT_DB_PASSWORD",
            "CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS",
            "SECRET_KEY_BASE",
        }
    finally:
        rmtree(tmp_path, ignore_errors=True)


def test_doctor_accepts_database_url_or_structured_db_settings() -> None:
    tmp_path = make_workspace_tmp()
    try:
        env_path = write_env(
            tmp_path / ".env.production",
            {
                "APP_ENV": "production",
                "BOT_MODE": "telegram",
                "DATABASE_URL": "postgresql+asyncpg://user:secret@postgres:5432/support",
                "REDIS_URL": "redis://redis:6379/0",
                "TELEGRAM_BOT_TOKEN": "1234567890:token",
                "TELEGRAM_WEBHOOK_SECRET": "telegram-webhook-secret",
                "TELEGRAM_WEBHOOK_URL": "https://bot.example.com/telegram/webhook",
                "CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS": "false",
            },
        )

        assert validate_taskbot_env(env_path, production=True) == []
    finally:
        rmtree(tmp_path, ignore_errors=True)
