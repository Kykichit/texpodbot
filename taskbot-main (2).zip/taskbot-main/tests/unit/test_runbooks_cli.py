from pathlib import Path

import yaml
from texpod_bot.domain.runbooks import RunbookValidationError

from app.main import build_parser
from app.runbooks_cli import list_runbooks, validate_runbooks


def test_valid_runbooks_pass() -> None:
    result = validate_runbooks(Path("runbooks"))

    assert result.exit_code == 0
    assert "Runbooks valid: 3" in result.output


def test_invalid_yaml_fails(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    def fail_load(_path: Path) -> object:
        raise yaml.YAMLError("invalid yaml")

    monkeypatch.setattr("app.runbooks_cli._load_runbooks", fail_load)

    result = validate_runbooks(Path("runbooks"))

    assert result.exit_code == 1
    assert "Runbook YAML error" in result.output


def test_missing_start_step_fails(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    def fail_load(_path: Path) -> object:
        raise RunbookValidationError("runbook must define a start step")

    monkeypatch.setattr("app.runbooks_cli._load_runbooks", fail_load)

    result = validate_runbooks(Path("runbooks"))

    assert result.exit_code == 1
    assert "start step" in result.output


def test_unknown_next_step_fails(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    def fail_load(_path: Path) -> object:
        raise RunbookValidationError("references unknown step 'missing'")

    monkeypatch.setattr("app.runbooks_cli._load_runbooks", fail_load)

    result = validate_runbooks(Path("runbooks"))

    assert result.exit_code == 1
    assert "unknown step" in result.output


def test_duplicate_code_fails(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    def fail_load(_path: Path) -> object:
        raise RunbookValidationError("Duplicate runbook code 'TEST_RUNBOOK'")

    monkeypatch.setattr("app.runbooks_cli._load_runbooks", fail_load)

    result = validate_runbooks(Path("runbooks"))

    assert result.exit_code == 1
    assert "Duplicate runbook code" in result.output


def test_list_outputs_sample_runbooks() -> None:
    result = list_runbooks(Path("runbooks"))

    assert result.exit_code == 0
    assert "KIOSK_OFFLINE" in result.output
    assert "SYNC_FAILED" in result.output
    assert "APP_FREEZE" in result.output
    assert "steps=" in result.output
    assert "actions=" in result.output


def test_help_shows_runbooks_commands(capsys) -> None:  # type: ignore[no-untyped-def]
    parser = build_parser()

    try:
        parser.parse_args(["runbooks", "--help"])
    except SystemExit as exc:
        assert exc.code == 0

    captured = capsys.readouterr()
    assert "validate" in captured.out
    assert "list" in captured.out
