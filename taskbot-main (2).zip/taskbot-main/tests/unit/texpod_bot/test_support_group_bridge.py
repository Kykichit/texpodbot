from dataclasses import dataclass

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from texpod_bot.domain.enums import IssueType, MessageSenderType, TicketPriority, TicketStatus
from texpod_bot.domain.schemas import ClientCreate, MessageRoutingCreate, TicketCreate
from texpod_bot.infrastructure.database.models import Base
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.support_group_bridge import (
    SUPPORT_GROUP_READY_MESSAGE,
    SupportGroupBridgeService,
)
from texpod_bot.services.telegram_escalation import SentTelegramMessage


@dataclass(frozen=True, slots=True)
class SentCall:
    chat_id: str
    text: str
    reply_to_message_id: str | None
    message_thread_id: str | None


class FakeTelegramApi:
    def __init__(self) -> None:
        self.calls: list[SentCall] = []

    async def send_message(
        self,
        *,
        chat_id: str,
        text: str,
        reply_to_message_id: str | None = None,
        message_thread_id: str | None = None,
    ) -> SentTelegramMessage:
        self.calls.append(
            SentCall(
                chat_id=chat_id,
                text=text,
                reply_to_message_id=reply_to_message_id,
                message_thread_id=message_thread_id,
            )
        )
        return SentTelegramMessage(message_id=str(9000 + len(self.calls)))


@pytest.fixture
async def sessionmaker() -> async_sessionmaker[AsyncSession]:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

    maker = async_sessionmaker(engine, expire_on_commit=False)
    yield maker
    await engine.dispose()


@pytest.mark.asyncio
async def test_support_group_start_returns_bridge_hint(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service = SupportGroupBridgeService(
        sessionmaker=sessionmaker,
        telegram_api=FakeTelegramApi(),
        support_group_id="-100",
    )

    response = await service.handle_support_group_start()

    assert response.text == SUPPORT_GROUP_READY_MESSAGE


@pytest.mark.asyncio
async def test_operator_reply_to_ticket_summary_sends_message_to_client(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    api = FakeTelegramApi()
    service = SupportGroupBridgeService(
        sessionmaker=sessionmaker,
        telegram_api=api,
        support_group_id="-100",
    )
    ticket_id = await _create_ticket_with_routing(sessionmaker)

    response = await service.handle_operator_reply(
        operator_telegram_user_id="9001",
        replied_message_id="5001",
        support_thread_id=None,
        text="Проверьте терминал после перезагрузки.",
        telegram_message_id="7001",
    )

    timeline = await _ticket_timeline(sessionmaker, ticket_id)
    assert response.text == "Ответ отправлен клиенту по SUP-1001."
    assert api.calls[-1].chat_id == "100"
    assert api.calls[-1].text == "Проверьте терминал после перезагрузки."
    assert timeline["messages"][-1].sender_type == MessageSenderType.SUPPORT.value
    assert timeline["messages"][-1].sender_id == "9001"


@pytest.mark.asyncio
async def test_command_reply_is_not_sent_to_client(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    api = FakeTelegramApi()
    service = SupportGroupBridgeService(
        sessionmaker=sessionmaker,
        telegram_api=api,
        support_group_id="-100",
    )
    ticket_id = await _create_ticket_with_routing(sessionmaker)

    response = await service.handle_operator_reply(
        operator_telegram_user_id="9001",
        replied_message_id="5001",
        support_thread_id=None,
        text="/ban spam",
        telegram_message_id="7001",
    )

    timeline = await _ticket_timeline(sessionmaker, ticket_id)
    assert response.text is None
    assert api.calls == []
    assert timeline["messages"] == []


@pytest.mark.asyncio
async def test_close_by_public_id_closes_ticket_and_notifies_client(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    api = FakeTelegramApi()
    service = SupportGroupBridgeService(
        sessionmaker=sessionmaker,
        telegram_api=api,
        support_group_id="-100",
    )
    ticket_id = await _create_ticket_with_routing(sessionmaker)

    response = await service.handle_close_command(command_text="/close SUP-1001 причина")

    timeline = await _ticket_timeline(sessionmaker, ticket_id)
    assert response.text == "Обращение SUP-1001 закрыто."
    assert timeline["ticket"].status == TicketStatus.CLOSED.value
    assert timeline["ticket"].closed_at is not None
    assert api.calls[-1].chat_id == "100"
    assert api.calls[-1].text == "Обращение SUP-1001 закрыто. Спасибо!"


@pytest.mark.asyncio
async def test_reply_close_closes_ticket(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    api = FakeTelegramApi()
    service = SupportGroupBridgeService(
        sessionmaker=sessionmaker,
        telegram_api=api,
        support_group_id="-100",
    )
    ticket_id = await _create_ticket_with_routing(sessionmaker)

    response = await service.handle_close_command(
        command_text="/close",
        replied_message_id="5001",
    )

    timeline = await _ticket_timeline(sessionmaker, ticket_id)
    assert response.text == "Обращение SUP-1001 закрыто."
    assert timeline["ticket"].status == TicketStatus.CLOSED.value


@pytest.mark.asyncio
async def test_close_unknown_ticket_returns_useful_message(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service = SupportGroupBridgeService(
        sessionmaker=sessionmaker,
        telegram_api=FakeTelegramApi(),
        support_group_id="-100",
    )

    response = await service.handle_close_command(command_text="/close SUP-NOPE")

    assert response.text == "Обращение SUP-NOPE не найдено."


@pytest.mark.asyncio
async def test_close_already_closed_ticket_returns_useful_message(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service = SupportGroupBridgeService(
        sessionmaker=sessionmaker,
        telegram_api=FakeTelegramApi(),
        support_group_id="-100",
    )
    ticket_id = await _create_ticket_with_routing(sessionmaker)
    await service.handle_close_command(command_text="/close SUP-1001")

    response = await service.handle_close_command(command_text="/close SUP-1001")

    timeline = await _ticket_timeline(sessionmaker, ticket_id)
    assert response.text == "Обращение SUP-1001 уже закрыто."
    assert timeline["ticket"].status == TicketStatus.CLOSED.value


@pytest.mark.asyncio
async def test_status_command_returns_ticket_card(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service = SupportGroupBridgeService(
        sessionmaker=sessionmaker,
        telegram_api=FakeTelegramApi(),
        support_group_id="-100",
    )
    await _create_ticket_with_routing(sessionmaker)

    response = await service.handle_status_command(command_text="/status SUP-1001")

    assert response.text is not None
    assert "Обращение SUP-1001" in response.text
    assert "Статус: waiting_support" in response.text
    assert "Приоритет: p2" in response.text


@pytest.mark.asyncio
async def test_stats_command_returns_support_metrics(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service = SupportGroupBridgeService(
        sessionmaker=sessionmaker,
        telegram_api=FakeTelegramApi(),
        support_group_id="-100",
    )
    await _create_ticket_with_routing(sessionmaker)

    response = await service.handle_stats_command(command_text="/stats week")

    assert response.text is not None
    assert "Статистика поддержки" in response.text
    assert "Всего обращений:" in response.text


async def _create_ticket_with_routing(sessionmaker: async_sessionmaker[AsyncSession]) -> str:
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        client = await uow.clients.create(ClientCreate(name="Bakery", telegram_user_id="42"))
        ticket = await uow.tickets.create(
            TicketCreate(
                public_id="SUP-1001",
                client_id=client.id,
                telegram_chat_id="100",
                issue_type=IssueType.TERMINAL_NOT_WORKING,
                status=TicketStatus.WAITING_SUPPORT,
                priority=TicketPriority.P2,
            )
        )
        await uow.message_routings.create(
            MessageRoutingCreate(
                ticket_id=ticket.id,
                client_chat_id="100",
                support_group_message_id="5001",
            )
        )
        await uow.commit()
        return ticket.id


async def _ticket_timeline(
    sessionmaker: async_sessionmaker[AsyncSession],
    ticket_id: str,
):
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        ticket = await uow.tickets.get(ticket_id)
        assert ticket is not None
        return {
            "ticket": ticket,
            "messages": await uow.messages.list_for_ticket(ticket.id),
            "events": await uow.events.list_for_ticket(ticket.id),
        }
