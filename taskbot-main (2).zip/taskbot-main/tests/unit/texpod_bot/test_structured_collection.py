import pytest
from texpod_bot.domain.enums import IssueType, TicketPriority
from texpod_bot.services.structured_collection import (
    AffectedScope,
    BusinessBlocked,
    CollectionAnswer,
    CollectionField,
    CollectionResult,
    CollectionValidationError,
    MediaAttachment,
    answer_collection,
    collection_event_payload,
    collection_from_json,
    collection_to_json,
    format_client_summary,
    format_support_summary,
    priority_input_from_collection,
    start_collection,
)
from texpod_bot.services.tickets import decide_priority


def test_start_collection_returns_first_field_and_question() -> None:
    result = start_collection(IssueType.DEVICE_OFFLINE)

    assert result.session.current_field == CollectionField.CLIENT_NAME
    assert "клиента" in result.prompt
    assert result.session.data.issue_type == IssueType.DEVICE_OFFLINE


def test_happy_path_completes_collection() -> None:
    session = _complete_collection().session

    assert session.complete
    assert session.data.client_name == "Bakery LLC"
    assert session.data.location == "Branch 1"
    assert session.data.problem_started_at == "today 10:00"
    assert session.data.affected_scope == AffectedScope.ONE_DEVICE
    assert session.data.business_blocked == BusinessBlocked.NO
    assert session.data.device_id == "KIOSK-1"
    assert session.data.app_version == "1.2.3"
    assert session.data.free_text_description == "App does not sync menu"


def test_optional_fields_accept_unknown_answer() -> None:
    result = start_collection(IssueType.MENU_SYNC)
    result = answer_collection(result.session, CollectionAnswer(text="Bakery LLC"))
    result = answer_collection(result.session, CollectionAnswer(text="Не знаю"))
    result = answer_collection(result.session, CollectionAnswer(text="today"))
    result = answer_collection(result.session, CollectionAnswer(text="unknown"))
    result = answer_collection(result.session, CollectionAnswer(text="unknown"))
    result = answer_collection(result.session, CollectionAnswer(text="Не знаю"))
    result = answer_collection(result.session, CollectionAnswer(text="Не знаю"))

    assert result.session.data.location is None
    assert result.session.data.device_id is None
    assert result.session.data.app_version is None


def test_optional_fields_accept_skip() -> None:
    result = start_collection(IssueType.MENU_SYNC)
    result = answer_collection(result.session, CollectionAnswer(text="Bakery LLC"))
    result = answer_collection(result.session, CollectionAnswer(text="skip"))
    result = answer_collection(result.session, CollectionAnswer(text="today"))
    result = answer_collection(result.session, CollectionAnswer(text="unknown"))
    result = answer_collection(result.session, CollectionAnswer(text="unknown"))
    result = answer_collection(result.session, CollectionAnswer(text="skip"))
    result = answer_collection(result.session, CollectionAnswer(text="skip"))

    assert result.session.data.location is None
    assert result.session.data.device_id is None
    assert result.session.data.app_version is None


def test_optional_fields_accept_empty_answer() -> None:
    result = start_collection(IssueType.MENU_SYNC)
    result = answer_collection(result.session, CollectionAnswer(text="Bakery LLC"))
    result = answer_collection(result.session, CollectionAnswer(text=""))
    result = answer_collection(result.session, CollectionAnswer(text="today"))
    result = answer_collection(result.session, CollectionAnswer(text="unknown"))
    result = answer_collection(result.session, CollectionAnswer(text="unknown"))
    result = answer_collection(result.session, CollectionAnswer(text=""))
    result = answer_collection(result.session, CollectionAnswer(text=""))
    result = answer_collection(result.session, CollectionAnswer(text=""))

    assert result.session.data.location is None
    assert result.session.data.device_id is None
    assert result.session.data.app_version is None
    assert result.session.data.screenshot_or_video is None


def test_invalid_affected_scope_fails_with_useful_error() -> None:
    result = _advance_to(CollectionField.AFFECTED_SCOPE)

    with pytest.raises(CollectionValidationError, match="affected_scope"):
        answer_collection(result.session, CollectionAnswer(text="somewhere"))


def test_invalid_business_blocked_fails_with_useful_error() -> None:
    result = _advance_to(CollectionField.BUSINESS_BLOCKED)

    with pytest.raises(CollectionValidationError, match="business_blocked"):
        answer_collection(result.session, CollectionAnswer(text="maybe later"))


def test_empty_client_name_raises_validation_error() -> None:
    result = start_collection(IssueType.MENU_SYNC)

    with pytest.raises(CollectionValidationError, match="client_name"):
        answer_collection(result.session, CollectionAnswer(text=""))


def test_empty_free_text_description_raises_validation_error() -> None:
    result = _advance_to(CollectionField.DESCRIPTION)

    with pytest.raises(CollectionValidationError, match="free_text_description"):
        answer_collection(result.session, CollectionAnswer(text=""))


def test_russian_scope_and_business_answers_are_supported() -> None:
    result = _advance_to(CollectionField.AFFECTED_SCOPE)
    result = answer_collection(result.session, CollectionAnswer(text="все устройства"))
    result = answer_collection(result.session, CollectionAnswer(text="да"))

    assert result.session.data.affected_scope == AffectedScope.ALL_DEVICES
    assert result.session.data.business_blocked == BusinessBlocked.YES


@pytest.mark.parametrize(
    ("answer", "expected"),
    [
        ("одно устройство", AffectedScope.ONE_DEVICE),
        ("на одном", AffectedScope.ONE_DEVICE),
        ("все устройства", AffectedScope.ALL_DEVICES),
        ("на всех", AffectedScope.ALL_DEVICES),
        ("не знаю", AffectedScope.UNKNOWN),
    ],
)
def test_russian_affected_scope_variants_are_supported(
    answer: str,
    expected: AffectedScope,
) -> None:
    result = _advance_to(CollectionField.AFFECTED_SCOPE)

    result = answer_collection(result.session, CollectionAnswer(text=answer))

    assert result.session.data.affected_scope == expected


@pytest.mark.parametrize(
    ("answer", "expected"),
    [
        ("да", BusinessBlocked.YES),
        ("нет", BusinessBlocked.NO),
        ("не знаю", BusinessBlocked.UNKNOWN),
    ],
)
def test_russian_business_blocked_variants_are_supported(
    answer: str,
    expected: BusinessBlocked,
) -> None:
    result = _advance_to(CollectionField.BUSINESS_BLOCKED)

    result = answer_collection(result.session, CollectionAnswer(text=answer))

    assert result.session.data.business_blocked == expected


def test_media_metadata_is_stored_and_round_trips() -> None:
    attachment = MediaAttachment(
        file_id="file-1",
        file_unique_id="unique-1",
        mime_type="image/jpeg",
        file_size=12345,
        metadata={"width": "1280"},
    )
    result = _advance_to(CollectionField.MEDIA)
    result = answer_collection(result.session, CollectionAnswer(attachment=attachment))

    raw = collection_to_json(result.session)
    restored = collection_from_json(raw)

    assert restored.data.screenshot_or_video == attachment


def test_summary_formatting_works() -> None:
    session = _complete_collection().session

    client_summary = format_client_summary(session.data)
    support_summary = format_support_summary(session.data)

    assert "Данные собраны" in client_summary
    assert "Bakery LLC" in client_summary
    assert "Structured data:" in support_summary
    assert "client_name: Bakery LLC" in support_summary
    assert "affected_scope: one_device" in support_summary


def test_event_payload_contains_all_fields() -> None:
    session = _complete_collection().session

    payload = collection_event_payload(session)

    assert payload["client_name"] == "Bakery LLC"
    assert payload["location"] == "Branch 1"
    assert payload["issue_type"] == "menu_sync"
    assert payload["problem_started_at"] == "today 10:00"
    assert payload["affected_scope"] == "one_device"
    assert payload["business_blocked"] == "no"
    assert payload["device_id"] == "KIOSK-1"
    assert payload["app_version"] == "1.2.3"
    assert payload["free_text_description"] == "App does not sync menu"


def test_collection_json_roundtrip() -> None:
    session = _complete_collection().session

    restored = collection_from_json(collection_to_json(session))

    assert restored == session


def test_affected_scope_all_devices_maps_to_p1() -> None:
    session = _complete_collection(affected_scope="all_devices", business_blocked="no").session

    priority_input = priority_input_from_collection(session.data)
    priority = decide_priority(priority_input)

    assert priority_input.affected_scope == "multiple_devices"
    assert priority == TicketPriority.P1


def test_business_blocked_yes_maps_to_p2() -> None:
    session = _complete_collection(affected_scope="one_device", business_blocked="yes").session

    priority_input = priority_input_from_collection(session.data)
    priority = decide_priority(priority_input)

    assert priority_input.business_blocked is True
    assert priority == TicketPriority.P2


def test_incomplete_collection_does_not_produce_final_payload() -> None:
    result = start_collection(IssueType.MENU_SYNC)

    with pytest.raises(CollectionValidationError, match="incomplete"):
        collection_event_payload(result.session)


def _advance_to(field: CollectionField) -> CollectionResult:
    result = start_collection(IssueType.MENU_SYNC)
    answers = {
        CollectionField.CLIENT_NAME: "Bakery LLC",
        CollectionField.LOCATION: "Branch 1",
        CollectionField.PROBLEM_STARTED_AT: "today 10:00",
        CollectionField.AFFECTED_SCOPE: "one_device",
        CollectionField.BUSINESS_BLOCKED: "no",
        CollectionField.DEVICE_ID: "KIOSK-1",
        CollectionField.APP_VERSION: "1.2.3",
        CollectionField.MEDIA: "skip",
        CollectionField.DESCRIPTION: "App does not sync menu",
    }
    while result.session.current_field != field:
        result = answer_collection(
            result.session,
            CollectionAnswer(text=answers[result.session.current_field]),
        )
    return result


def _complete_collection(
    *,
    affected_scope: str = "one_device",
    business_blocked: str = "no",
) -> CollectionResult:
    result = start_collection(IssueType.MENU_SYNC)
    answers = (
        "Bakery LLC",
        "Branch 1",
        "today 10:00",
        affected_scope,
        business_blocked,
        "KIOSK-1",
        "1.2.3",
        "skip",
        "App does not sync menu",
    )
    for answer in answers:
        result = answer_collection(result.session, CollectionAnswer(text=answer))
    return result
