import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from texpod_bot.domain.enums import (
    IssueType,
    MessageSenderType,
    TicketEventType,
    TicketPriority,
    TicketStatus,
)
from texpod_bot.domain.runbooks import RunbookSession
from texpod_bot.domain.schemas import ClientCreate, SupportOperatorCreate
from texpod_bot.infrastructure.database.models import Base
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.tickets import (
    PriorityDecisionInput,
    TicketService,
    TicketTransitionError,
    decide_priority,
)


@pytest.fixture
async def session() -> AsyncSession:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

    sessionmaker = async_sessionmaker(engine, expire_on_commit=False)
    async with sessionmaker() as session:
        yield session

    await engine.dispose()


async def create_client(uow: SupportUnitOfWork) -> str:
    client = await uow.clients.create(
        ClientCreate(name="Bakery", contact_name="Owner", telegram_user_id="42")
    )
    await uow.commit()
    return client.id


async def create_ticket(service: TicketService, client_id: str) -> str:
    ticket = await service.create_ticket_from_runbook_session(
        client_id=client_id,
        telegram_chat_id="100",
        issue_type=IssueType.DEVICE_OFFLINE,
        runbook_session=RunbookSession(
            runbook_code="KIOSK_OFFLINE",
            current_step_key="check_internet",
        ),
        priority_input=PriorityDecisionInput(affected_scope="single_device", has_workaround=True),
    )
    return ticket.id


def test_decide_priority_rules() -> None:
    assert (
        decide_priority(PriorityDecisionInput(affected_scope="multiple_devices"))
        == TicketPriority.P1
    )
    assert (
        decide_priority(
            PriorityDecisionInput(affected_scope="single_device", business_blocked=True)
        )
        == TicketPriority.P2
    )
    assert (
        decide_priority(PriorityDecisionInput(affected_scope="single_device", has_workaround=True))
        == TicketPriority.P3
    )
    assert (
        decide_priority(PriorityDecisionInput(affected_scope="single_device", is_question=True))
        == TicketPriority.P4
    )


@pytest.mark.asyncio
async def test_create_ticket_from_runbook_session_adds_events(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    service = TicketService(uow)
    client_id = await create_client(uow)

    ticket = await service.create_ticket_from_runbook_session(
        client_id=client_id,
        telegram_chat_id="100",
        issue_type=IssueType.DEVICE_OFFLINE,
        runbook_session=RunbookSession(
            runbook_code="KIOSK_OFFLINE",
            current_step_key="start",
        ),
        priority_input=PriorityDecisionInput(affected_scope="multiple_devices"),
    )
    timeline = await service.get_ticket_timeline(ticket.id)

    assert ticket.status == TicketStatus.RUNBOOK_IN_PROGRESS.value
    assert ticket.priority == TicketPriority.P1.value
    assert [event.event_type for event in timeline.events] == [
        TicketEventType.CREATED.value,
        TicketEventType.RUNBOOK_STARTED.value,
    ]


@pytest.mark.asyncio
async def test_add_message_adds_message_event(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    service = TicketService(uow)
    client_id = await create_client(uow)
    ticket_id = await create_ticket(service, client_id)

    message = await service.add_message(
        ticket_id,
        sender_type=MessageSenderType.CLIENT,
        sender_id=client_id,
        text="The kiosk is still offline",
    )
    timeline = await service.get_ticket_timeline(ticket_id)

    assert message.text == "The kiosk is still offline"
    assert timeline.messages == [message]
    assert timeline.events[-1].event_type == TicketEventType.MESSAGE_ADDED.value


@pytest.mark.asyncio
async def test_add_event_records_custom_event(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    service = TicketService(uow)
    client_id = await create_client(uow)
    ticket_id = await create_ticket(service, client_id)

    event = await service.add_event(
        ticket_id,
        TicketEventType.RUNBOOK_STEP_COMPLETED,
        {"step_key": "check_internet"},
    )
    await uow.commit()

    assert event.event_type == TicketEventType.RUNBOOK_STEP_COMPLETED.value


@pytest.mark.asyncio
async def test_assign_operator_changes_status_and_records_event(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    service = TicketService(uow)
    client_id = await create_client(uow)
    ticket_id = await create_ticket(service, client_id)
    operator = await uow.operators.create(
        SupportOperatorCreate(telegram_user_id="9001", display_name="Support")
    )
    await uow.commit()

    ticket = await service.assign_operator(ticket_id, operator.id)
    timeline = await service.get_ticket_timeline(ticket_id)

    assert ticket.status == TicketStatus.ASSIGNED.value
    assert ticket.assigned_to == operator.id
    assert timeline.events[-1].event_type == TicketEventType.ASSIGNED.value


@pytest.mark.asyncio
async def test_change_status_validates_transitions(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    service = TicketService(uow)
    client_id = await create_client(uow)
    ticket_id = await create_ticket(service, client_id)

    ticket = await service.change_status(ticket_id, TicketStatus.WAITING_CLIENT)

    assert ticket.status == TicketStatus.WAITING_CLIENT.value

    with pytest.raises(TicketTransitionError):
        await service.change_status(ticket_id, TicketStatus.RESOLVED)


@pytest.mark.asyncio
async def test_close_ticket_sets_closed_at_and_event(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    service = TicketService(uow)
    client_id = await create_client(uow)
    ticket_id = await create_ticket(service, client_id)

    await service.change_status(ticket_id, TicketStatus.RESOLVED)
    ticket = await service.close_ticket(ticket_id)
    timeline = await service.get_ticket_timeline(ticket_id)

    assert ticket.status == TicketStatus.CLOSED.value
    assert ticket.closed_at is not None
    assert timeline.events[-1].event_type == TicketEventType.CLOSED.value


@pytest.mark.asyncio
async def test_escalate_ticket_moves_to_waiting_support(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    service = TicketService(uow)
    client_id = await create_client(uow)
    ticket_id = await create_ticket(service, client_id)

    ticket = await service.escalate_ticket(ticket_id)
    timeline = await service.get_ticket_timeline(ticket_id)

    assert ticket.status == TicketStatus.WAITING_SUPPORT.value
    assert timeline.events[-1].event_type == TicketEventType.ESCALATED.value


@pytest.mark.asyncio
async def test_list_open_tickets_excludes_closed(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    service = TicketService(uow)
    client_id = await create_client(uow)
    ticket_id = await create_ticket(service, client_id)

    assert [ticket.id for ticket in await service.list_open_tickets(client_id)] == [ticket_id]

    await service.change_status(ticket_id, TicketStatus.RESOLVED)
    await service.close_ticket(ticket_id)

    assert await service.list_open_tickets(client_id) == []


@pytest.mark.asyncio
async def test_get_ticket_timeline_returns_messages_and_events(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    service = TicketService(uow)
    client_id = await create_client(uow)
    ticket_id = await create_ticket(service, client_id)
    await service.add_message(
        ticket_id, sender_type=MessageSenderType.BOT, text="Please check power"
    )

    timeline = await service.get_ticket_timeline(ticket_id)

    assert timeline.ticket.id == ticket_id
    assert len(timeline.messages) == 1
    assert len(timeline.events) >= 3
