from typing import cast

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from texpod_bot.domain.enums import IssueType
from texpod_bot.domain.runbooks import RunbookAction, RunbookHistoryItem, RunbookSession
from texpod_bot.infrastructure.database.models import Base, SupportSession
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.structured_collection import (
    CollectionAnswer,
    CollectionField,
    answer_collection,
    start_collection,
)
from texpod_bot.services.support_sessions import (
    SupportFlowState,
    SupportSessionService,
    SupportSessionStateMissingError,
)


@pytest.fixture
async def session() -> AsyncSession:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

    sessionmaker = async_sessionmaker(engine, expire_on_commit=False)
    async with sessionmaker() as session:
        yield session

    await engine.dispose()


@pytest.mark.asyncio
async def test_get_or_create_session_creates_new_session(session: AsyncSession) -> None:
    service = SupportSessionService(SupportUnitOfWork(session))

    support_session = await service.get_or_create_session(
        telegram_user_id="user-1",
        telegram_chat_id="chat-1",
    )

    assert support_session.telegram_user_id == "user-1"
    assert support_session.telegram_chat_id == "chat-1"
    assert support_session.state == SupportFlowState.MAIN_MENU.value


@pytest.mark.asyncio
async def test_get_or_create_session_returns_existing_session(session: AsyncSession) -> None:
    service = SupportSessionService(SupportUnitOfWork(session))

    first = await service.get_or_create_session(
        telegram_user_id="user-1",
        telegram_chat_id="chat-1",
    )
    second = await service.get_or_create_session(
        telegram_user_id="user-1",
        telegram_chat_id="chat-1",
    )

    assert second.id == first.id


def test_reset_session_clears_runbook_ticket_and_history_state() -> None:
    service = _service_without_db()
    support_session = SupportSession(
        telegram_user_id="user-1",
        telegram_chat_id="chat-1",
        ticket_id="ticket-1",
        runbook_code="KIOSK_OFFLINE",
        current_step_key="start",
        state=SupportFlowState.COLLECTING_DATA.value,
        history_json=[{"runbook_code": "KIOSK_OFFLINE"}],
    )

    result = service.reset_session(support_session)

    assert result.ticket_id is None
    assert result.runbook_code is None
    assert result.current_step_key is None
    assert result.history_json == []
    assert result.state == SupportFlowState.MAIN_MENU.value


def test_set_state_works_and_maps_legacy_runbook_state() -> None:
    service = _service_without_db()
    support_session = _support_session()

    service.set_state(support_session, SupportFlowState.CHOOSING_ISSUE)
    assert support_session.state == SupportFlowState.CHOOSING_ISSUE.value

    service.set_state(support_session, "runbook")
    assert support_session.state == SupportFlowState.RUNBOOK_IN_PROGRESS.value


def test_start_runbook_stores_runbook_code_current_step_state_and_history() -> None:
    service = _service_without_db()
    support_session = _support_session()
    runbook_session = _runbook_session(current_step_key="start")

    result = service.start_runbook(support_session, runbook_session)

    assert result.runbook_code == "KIOSK_OFFLINE"
    assert result.current_step_key == "start"
    assert result.state == SupportFlowState.RUNBOOK_IN_PROGRESS.value
    assert result.history_json[0]["runbook_code"] == "KIOSK_OFFLINE"


def test_update_runbook_session_replaces_previous_runbook_state() -> None:
    service = _service_without_db()
    support_session = _support_session()

    service.start_runbook(support_session, _runbook_session(current_step_key="start"))
    service.update_runbook_session(support_session, _runbook_session(current_step_key="next"))

    runbook_items = [item for item in support_session.history_json if "runbook_code" in item]
    assert len(runbook_items) == 1
    assert support_session.current_step_key == "next"
    assert runbook_items[0]["current_step_key"] == "next"


def test_load_runbook_session_restores_runbook_session() -> None:
    service = _service_without_db()
    support_session = _support_session()
    expected = _runbook_session(current_step_key="check_internet")

    service.start_runbook(support_session, expected)

    assert service.load_runbook_session(support_session) == expected


def test_load_runbook_session_raises_clear_error_when_missing() -> None:
    service = _service_without_db()

    with pytest.raises(SupportSessionStateMissingError, match="runbook"):
        service.load_runbook_session(_support_session())


def test_start_collection_stores_collection_state() -> None:
    service = _service_without_db()
    support_session = _support_session()
    collection = start_collection(IssueType.MENU_SYNC).session

    result = service.start_collection(support_session, collection)

    assert result.state == SupportFlowState.COLLECTING_DATA.value
    assert result.history_json[0]["kind"] == "collection"


def test_update_collection_session_replaces_previous_collection_state() -> None:
    service = _service_without_db()
    support_session = _support_session()

    first = start_collection(IssueType.MENU_SYNC).session
    second = answer_collection(first, CollectionAnswer(text="Bakery LLC")).session
    service.start_collection(support_session, first)
    service.update_collection_session(support_session, second)

    collection_items = [
        item for item in support_session.history_json if item.get("kind") == "collection"
    ]
    assert len(collection_items) == 1
    assert collection_items[0]["current_field"] == CollectionField.LOCATION.value


def test_load_collection_session_restores_collection_session() -> None:
    service = _service_without_db()
    support_session = _support_session()
    expected = start_collection(IssueType.MENU_SYNC).session

    service.start_collection(support_session, expected)

    assert service.load_collection_session(support_session) == expected


def test_load_collection_session_raises_clear_error_when_missing() -> None:
    service = _service_without_db()

    with pytest.raises(SupportSessionStateMissingError, match="collection"):
        service.load_collection_session(_support_session())


def test_bind_client_stores_client_id() -> None:
    service = _service_without_db()
    support_session = _support_session()

    service.bind_client(support_session, "client-1")

    assert support_session.client_id == "client-1"


def test_bind_ticket_stores_ticket_id() -> None:
    service = _service_without_db()
    support_session = _support_session()

    service.bind_ticket(support_session, "ticket-1")

    assert support_session.ticket_id == "ticket-1"


def test_runbook_and_collection_can_coexist_without_duplication() -> None:
    service = _service_without_db()
    support_session = _support_session()
    collection = start_collection(IssueType.MENU_SYNC).session

    service.start_runbook(support_session, _runbook_session(current_step_key="start"))
    service.start_collection(support_session, collection)
    service.update_runbook_session(support_session, _runbook_session(current_step_key="next"))
    service.update_collection_session(
        support_session,
        answer_collection(collection, CollectionAnswer(text="Bakery LLC")).session,
    )

    runbook_items = [item for item in support_session.history_json if "runbook_code" in item]
    collection_items = [
        item for item in support_session.history_json if item.get("kind") == "collection"
    ]
    assert len(runbook_items) == 1
    assert len(collection_items) == 1
    assert service.load_runbook_session(support_session).current_step_key == "next"
    assert (
        service.load_collection_session(support_session).current_field == CollectionField.LOCATION
    )


def _service_without_db() -> SupportSessionService:
    return SupportSessionService(cast(SupportUnitOfWork, object()))


def _support_session() -> SupportSession:
    return SupportSession(
        telegram_user_id="user-1",
        telegram_chat_id="chat-1",
        state=SupportFlowState.MAIN_MENU.value,
        history_json=[],
    )


def _runbook_session(current_step_key: str) -> RunbookSession:
    history = ()
    if current_step_key != "start":
        history = (
            RunbookHistoryItem(
                step_key="start",
                selected_option="Next",
                next_step=current_step_key,
                action=RunbookAction.COLLECT_MEDIA,
            ),
        )
    return RunbookSession(
        runbook_code="KIOSK_OFFLINE",
        current_step_key=current_step_key,
        history=history,
    )
