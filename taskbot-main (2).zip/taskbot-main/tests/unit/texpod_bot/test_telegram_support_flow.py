from pathlib import Path

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from texpod_bot.domain.enums import MessageSenderType, TicketEventType
from texpod_bot.infrastructure.database.models import Base
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.runbook_service import RunbookService
from texpod_bot.services.telegram_support import (
    IncomingClientMessage,
    TelegramSupportHandlers,
    TelegramUserContext,
)
from texpod_bot.services.tickets import TicketService


@pytest.fixture
async def session() -> AsyncSession:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

    sessionmaker = async_sessionmaker(engine, expire_on_commit=False)
    async with sessionmaker() as session:
        yield session

    await engine.dispose()


def context() -> TelegramUserContext:
    return TelegramUserContext(
        telegram_user_id="42",
        telegram_chat_id="100",
        display_name="Client User",
    )


def build_handlers(session: AsyncSession) -> tuple[TelegramSupportHandlers, SupportUnitOfWork]:
    uow = SupportUnitOfWork(session)
    handlers = TelegramSupportHandlers(
        uow=uow,
        runbook_service=RunbookService.from_yaml_dir(Path("runbooks")),
        ticket_service=TicketService(uow),
    )
    return handlers, uow


async def complete_collection(
    handlers: TelegramSupportHandlers,
    *,
    affected_scope: str = "one_device",
    business_blocked: str = "yes",
    device_id: str = "kiosk-001",
    app_version: str = "1.2.3",
) -> None:
    answers = (
        "Texpod Bakery",
        "Central branch",
        "2026-04-27 09:00",
        affected_scope,
        business_blocked,
        device_id,
        app_version,
        "Не знаю",
        "Kiosk app is frozen after restart",
    )
    for answer in answers:
        await handlers.handle_client_message(context(), IncomingClientMessage(text=answer))


@pytest.mark.asyncio
async def test_start_handler_creates_db_backed_session(session: AsyncSession) -> None:
    handlers, uow = build_handlers(session)

    response = await handlers.handle_start(context())
    support_session = await uow.sessions.get_by_telegram_chat("42", "100")

    assert response.keyboard == "issue_type_menu"
    assert support_session is not None
    assert support_session.state == "main_menu"


@pytest.mark.asyncio
async def test_choose_issue_type_starts_runbook(session: AsyncSession) -> None:
    handlers, uow = build_handlers(session)

    response = await handlers.handle_issue_type(context(), "KIOSK_OFFLINE")
    support_session = await uow.sessions.get_by_telegram_chat("42", "100")

    assert response.keyboard == "runbook_options"
    assert response.options == ("На одном", "На всех")
    assert support_session is not None
    assert support_session.runbook_code == "KIOSK_OFFLINE"
    assert support_session.current_step_key == "start"


@pytest.mark.asyncio
async def test_runbook_option_moves_to_next_step(session: AsyncSession) -> None:
    handlers, uow = build_handlers(session)

    await handlers.handle_issue_type(context(), "KIOSK_OFFLINE")
    response = await handlers.handle_runbook_option(context(), "На одном")
    support_session = await uow.sessions.get_by_telegram_chat("42", "100")

    assert response.keyboard == "runbook_options"
    assert "Проверьте интернет" in response.text
    assert support_session is not None
    assert support_session.current_step_key == "check_internet"


@pytest.mark.asyncio
async def test_escalate_action_creates_ticket(session: AsyncSession) -> None:
    handlers, uow = build_handlers(session)

    await handlers.handle_issue_type(context(), "APP_FREEZE")
    await handlers.handle_runbook_option(context(), "Постоянно")
    await handlers.handle_runbook_option(context(), "Нет")
    response = await handlers.handle_client_message(
        context(),
        IncomingClientMessage(attachment_url="telegram-file-id", telegram_message_id="777"),
    )
    await complete_collection(handlers)
    support_session = await uow.sessions.get_by_telegram_chat("42", "100")

    assert response.keyboard == "main_menu"
    assert support_session is not None
    assert support_session.ticket_id is not None
    timeline = await TicketService(uow).get_ticket_timeline(support_session.ticket_id)
    assert any(event.event_type == TicketEventType.ESCALATED.value for event in timeline.events)


@pytest.mark.asyncio
async def test_media_message_is_attached_to_ticket(session: AsyncSession) -> None:
    handlers, uow = build_handlers(session)

    await handlers.handle_issue_type(context(), "APP_FREEZE")
    await handlers.handle_runbook_option(context(), "Постоянно")
    await handlers.handle_runbook_option(context(), "Нет")
    await handlers.handle_client_message(
        context(),
        IncomingClientMessage(attachment_url="telegram-file-id", telegram_message_id="777"),
    )
    await complete_collection(handlers)
    support_session = await uow.sessions.get_by_telegram_chat("42", "100")
    assert support_session is not None
    assert support_session.ticket_id is not None

    await handlers.handle_client_message(
        context(),
        IncomingClientMessage(
            text="Additional details",
            attachment_url="second-file-id",
            telegram_message_id="778",
        ),
    )
    timeline = await TicketService(uow).get_ticket_timeline(support_session.ticket_id)

    assert timeline.messages[-1].sender_type == MessageSenderType.CLIENT.value
    assert timeline.messages[-1].attachment_url == "second-file-id"


@pytest.mark.asyncio
async def test_happy_path_collection_creates_ticket_after_summary(session: AsyncSession) -> None:
    handlers, uow = build_handlers(session)

    await handlers.handle_issue_type(context(), "APP_FREEZE")
    await handlers.handle_runbook_option(context(), "Постоянно")
    response = await handlers.handle_runbook_option(context(), "Нет")
    assert response.keyboard == "runbook_options"
    response = await handlers.handle_client_message(
        context(),
        IncomingClientMessage(text="Не знаю"),
    )
    assert "Укажите" in response.text

    final_response = None
    for answer in (
        "Texpod Bakery",
        "Central branch",
        "2026-04-27 09:00",
        "one_device",
        "yes",
        "kiosk-001",
        "1.2.3",
        "Не знаю",
        "App freezes on checkout screen",
    ):
        final_response = await handlers.handle_client_message(
            context(),
            IncomingClientMessage(text=answer),
        )
    support_session = await uow.sessions.get_by_telegram_chat("42", "100")

    assert final_response is not None
    assert "Передаю обращение оператору" in final_response.text
    assert support_session is not None
    assert support_session.ticket_id is not None
    timeline = await TicketService(uow).get_ticket_timeline(support_session.ticket_id)
    assert timeline.ticket.priority == "p2"
    assert "client_name: Texpod Bakery" in timeline.messages[0].text


@pytest.mark.asyncio
async def test_collection_accepts_unknown_optional_fields(session: AsyncSession) -> None:
    handlers, uow = build_handlers(session)

    await handlers.handle_issue_type(context(), "KIOSK_OFFLINE")
    await handlers.handle_runbook_option(context(), "На всех")
    await complete_collection(
        handlers,
        affected_scope="unknown",
        business_blocked="unknown",
        device_id="Не знаю",
        app_version="Не знаю",
    )
    support_session = await uow.sessions.get_by_telegram_chat("42", "100")
    assert support_session is not None
    assert support_session.ticket_id is not None

    timeline = await TicketService(uow).get_ticket_timeline(support_session.ticket_id)

    assert timeline.ticket.device_id is None
    assert "device_id: unknown" in timeline.messages[0].text
    assert "app_version: unknown" in timeline.messages[0].text


@pytest.mark.asyncio
async def test_collection_priority_uses_answers(session: AsyncSession) -> None:
    handlers, uow = build_handlers(session)

    await handlers.handle_issue_type(context(), "KIOSK_OFFLINE")
    await handlers.handle_runbook_option(context(), "На всех")
    await complete_collection(
        handlers,
        affected_scope="all_devices",
        business_blocked="no",
    )
    support_session = await uow.sessions.get_by_telegram_chat("42", "100")
    assert support_session is not None
    assert support_session.ticket_id is not None

    timeline = await TicketService(uow).get_ticket_timeline(support_session.ticket_id)

    assert timeline.ticket.priority == "p1"


@pytest.mark.asyncio
async def test_collection_media_is_saved_with_file_id(session: AsyncSession) -> None:
    handlers, uow = build_handlers(session)

    await handlers.handle_issue_type(context(), "APP_FREEZE")
    await handlers.handle_runbook_option(context(), "Постоянно")
    await handlers.handle_runbook_option(context(), "Нет")
    await handlers.handle_client_message(
        context(),
        IncomingClientMessage(
            attachment_url="photo-file-id",
            attachment_metadata={"type": "photo", "width": "1024"},
        ),
    )
    await complete_collection(handlers, business_blocked="no")
    support_session = await uow.sessions.get_by_telegram_chat("42", "100")
    assert support_session is not None
    assert support_session.ticket_id is not None

    timeline = await TicketService(uow).get_ticket_timeline(support_session.ticket_id)

    assert timeline.messages[0].attachment_url == "photo-file-id"
    assert any(
        event.payload_json.get("collection", {})
        .get("screenshot_or_video", {})
        .get("metadata", {})
        .get("type")
        == "photo"
        for event in timeline.events
    )


@pytest.mark.asyncio
async def test_client_follow_up_after_ticket_creation_is_silent(session: AsyncSession) -> None:
    handlers, uow = build_handlers(session)

    await handlers.handle_issue_type(context(), "APP_FREEZE")
    await handlers.handle_runbook_option(context(), "Постоянно")
    await handlers.handle_runbook_option(context(), "Нет")
    await handlers.handle_client_message(
        context(),
        IncomingClientMessage(attachment_url="telegram-file-id", telegram_message_id="777"),
    )
    await complete_collection(handlers)
    support_session = await uow.sessions.get_by_telegram_chat("42", "100")
    assert support_session is not None
    assert support_session.ticket_id is not None

    response = await handlers.handle_client_message(
        context(),
        IncomingClientMessage(text="Добавляю: терминал перезагружали"),
    )

    assert response.should_reply is False
    assert response.keyboard == "operator"
    timeline = await TicketService(uow).get_ticket_timeline(support_session.ticket_id)
    assert timeline.messages[-1].text == "Добавляю: терминал перезагружали"
