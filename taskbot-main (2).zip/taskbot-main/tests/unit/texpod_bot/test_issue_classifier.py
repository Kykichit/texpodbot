from texpod_bot.domain.enums import IssueType
from texpod_bot.services.issue_classifier import ClassificationConfidence, RuleBasedIssueClassifier


def test_classifier_detects_scanner_issue() -> None:
    result = RuleBasedIssueClassifier().classify("Сканер не сканирует штрихкод")

    assert result.issue_type == IssueType.SCANNER_NOT_WORKING
    assert "сканер" in result.matched_keywords


def test_classifier_detects_release_issue() -> None:
    result = RuleBasedIssueClassifier().classify("Не вижу выпуск на планшете")

    assert result.issue_type == IssueType.RELEASE_NOT_DISPLAYED


def test_classifier_detects_timesheet_issue() -> None:
    result = RuleBasedIssueClassifier().classify("Не открывается табельная смена сотрудников")

    assert result.issue_type == IssueType.TIMESHEET_SHIFT_OPEN_FAILED


def test_classifier_detects_cash_shift_issue() -> None:
    result = RuleBasedIssueClassifier().classify("Не можем открыть кассовую смену")

    assert result.issue_type == IssueType.CASH_SHIFT_OPEN_FAILED


def test_classifier_detects_receipts_issue() -> None:
    result = RuleBasedIssueClassifier().classify("Принтер не печатает чеки")

    assert result.issue_type == IssueType.RECEIPTS_NOT_PRINTING


def test_classifier_detects_terminal_issue() -> None:
    result = RuleBasedIssueClassifier().classify("Не проходит оплата картой через терминал")

    assert result.issue_type == IssueType.TERMINAL_NOT_WORKING


def test_classifier_returns_other_for_unknown_text() -> None:
    result = RuleBasedIssueClassifier().classify("На экране странное сообщение")

    assert result.issue_type == IssueType.OTHER
    assert result.confidence == ClassificationConfidence.LOW
    assert result.matched_keywords == ()


def test_classifier_prefers_specific_cash_shift_match() -> None:
    result = RuleBasedIssueClassifier().classify("Касса пишет ошибку: кассовая смена не открыта")

    assert result.issue_type == IssueType.CASH_SHIFT_OPEN_FAILED
    assert "кассовая смена" in result.matched_keywords
