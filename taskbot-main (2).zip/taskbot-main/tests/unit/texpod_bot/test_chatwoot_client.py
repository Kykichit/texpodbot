import json

import httpx
import pytest
from texpod_bot.infrastructure.chatwoot import (
    ChatwootApiError,
    ChatwootClient,
    ChatwootSettings,
    ChatwootSupportDeskAdapter,
)
from texpod_bot.services.support_desk import (
    SupportDeskContact,
    SupportDeskConversation,
    SupportDeskMessage,
)


def chatwoot_settings(**overrides: object) -> ChatwootSettings:
    values: dict[str, object] = {
        "base_url": "https://chatwoot.example.test/",
        "api_token": "chatwoot-api-value",
        "account_id": 10,
        "inbox_id": 20,
        "webhook_secret": "chatwoot-webhook-secret",
    }
    values.update(overrides)
    return ChatwootSettings(**values)


@pytest.mark.asyncio
async def test_client_requires_complete_settings() -> None:
    with pytest.raises(ValueError, match="requires"):
        ChatwootClient(settings=chatwoot_settings(api_token=None))


@pytest.mark.asyncio
async def test_upsert_contact_posts_contact_payload() -> None:
    requests: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(
            200,
            json={
                "payload": [
                    {
                        "id": 123,
                        "contact_inboxes": [
                            {"source_id": "telegram-42-source", "inbox": {"id": 20}}
                        ],
                    }
                ]
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http_client:
        client = ChatwootClient(settings=chatwoot_settings(), client=http_client)

        contact = await client.upsert_contact(
            SupportDeskContact(
                id="",
                external_id="telegram:42",
                name="Bakery Counter",
                phone="+10000000000",
                custom_attributes={"ticket_source": "telegram"},
            )
        )

    assert contact.id == "123"
    assert contact.source_id == "telegram-42-source"
    assert requests[0].method == "POST"
    assert str(requests[0].url) == "https://chatwoot.example.test/api/v1/accounts/10/contacts"
    assert requests[0].headers["api_access_token"] == "-".join(("chatwoot", "api", "value"))
    payload = json.loads(requests[0].content)
    assert payload == {
        "inbox_id": 20,
        "name": "Bakery Counter",
        "identifier": "telegram:42",
        "custom_attributes": {"ticket_source": "telegram"},
        "phone_number": "+10000000000",
    }


@pytest.mark.asyncio
async def test_create_conversation_posts_conversation_payload() -> None:
    requests: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json={"id": 456})

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http_client:
        client = ChatwootClient(settings=chatwoot_settings(), client=http_client)

        conversation = await client.create_conversation(
            contact_id="123",
            source_id="ticket:SUP-1001",
            custom_attributes={"ticket_id": "ticket-1", "public_id": "SUP-1001"},
        )

    assert conversation.id == "456"
    assert conversation.contact_id == "123"
    assert str(requests[0].url) == (
        "https://chatwoot.example.test/api/v1/accounts/10/conversations"
    )
    assert json.loads(requests[0].content) == {
        "source_id": "ticket:SUP-1001",
        "inbox_id": 20,
        "contact_id": "123",
        "custom_attributes": {"ticket_id": "ticket-1", "public_id": "SUP-1001"},
    }


@pytest.mark.asyncio
async def test_upsert_contact_duplicate_searches_existing_contact() -> None:
    requests: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        if request.method == "POST":
            return httpx.Response(
                422,
                request=request,
                json={"errors": {"identifier": ["has already been taken"]}},
            )
        return httpx.Response(
            200,
            request=request,
            json={
                "payload": [
                    {
                        "id": 321,
                        "identifier": "telegram:42",
                        "contact_inboxes": [{"source_id": "existing-source", "inbox": {"id": 20}}],
                    }
                ]
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http_client:
        client = ChatwootClient(settings=chatwoot_settings(), client=http_client)

        contact = await client.upsert_contact(
            SupportDeskContact(id="", external_id="telegram:42", name="Bakery Counter")
        )

    assert contact.id == "321"
    assert contact.source_id == "existing-source"
    assert requests[0].method == "POST"
    assert requests[1].method == "GET"
    assert str(requests[1].url) == (
        "https://chatwoot.example.test/api/v1/accounts/10/contacts/search?q=telegram%3A42"
    )


@pytest.mark.asyncio
async def test_upsert_contact_non_duplicate_422_raises_chatwoot_api_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            422,
            request=request,
            json={
                "message": "Validation failed",
                "errors": {"inbox_id": ["is invalid"]},
                "api_access_token": "should-not-leak",
            },
        )

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http_client:
        client = ChatwootClient(settings=chatwoot_settings(), client=http_client)

        with pytest.raises(ChatwootApiError) as exc_info:
            await client.upsert_contact(
                SupportDeskContact(id="", external_id="telegram:42", name="Bakery Counter")
            )

    error = exc_info.value
    assert error.status_code == 422
    assert error.method == "POST"
    assert error.path == "/api/v1/accounts/10/contacts"
    assert error.operation == "create_or_update_contact"
    assert error.account_id == 10
    assert error.inbox_id == 20
    assert isinstance(error.response_body, dict)
    assert error.response_body["api_access_token"] == "".join(("<", "redacted", ">"))
    payload = error.event_payload(ticket_public_id="SUP-1001")
    assert payload["chatwoot_message"] == "Validation failed"
    assert payload["chatwoot_errors"] == {"inbox_id": ["is invalid"]}
    assert "should-not-leak" not in str(payload)


@pytest.mark.asyncio
async def test_upsert_contact_missing_source_id_raises_clear_error() -> None:
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"payload": [{"id": 123, "contact_inboxes": []}]})

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http_client:
        client = ChatwootClient(settings=chatwoot_settings(), client=http_client)

        with pytest.raises(RuntimeError, match="source_id"):
            await client.upsert_contact(
                SupportDeskContact(id="", external_id="telegram:42", name="Bakery Counter")
            )


@pytest.mark.asyncio
async def test_send_customer_message_posts_incoming_message() -> None:
    requests: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        requests.append(request)
        return httpx.Response(200, json={"id": 789})

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http_client:
        client = ChatwootClient(settings=chatwoot_settings(), client=http_client)

        message = await client.send_customer_message(
            conversation_id="456",
            content="Kiosk is offline again",
            source_id="telegram-message-777",
        )

    assert message.id == "789"
    assert message.conversation_id == "456"
    assert str(requests[0].url) == (
        "https://chatwoot.example.test/api/v1/accounts/10/conversations/456/messages"
    )
    assert json.loads(requests[0].content) == {
        "content": "Kiosk is offline again",
        "message_type": "incoming",
        "private": False,
        "source_id": "telegram-message-777",
    }


@pytest.mark.asyncio
async def test_invalid_json_shape_raises_runtime_error() -> None:
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=["unexpected"])

    async with httpx.AsyncClient(transport=httpx.MockTransport(handler)) as http_client:
        client = ChatwootClient(settings=chatwoot_settings(), client=http_client)

        with pytest.raises(RuntimeError, match="JSON object"):
            await client.send_customer_message(conversation_id="456", content="hello")


class FakeChatwootClient:
    def __init__(self) -> None:
        self.contact: SupportDeskContact | None = None
        self.conversation_source_id: str | None = None
        self.message_content: str | None = None
        self.messages: list[tuple[str, str, str | None]] = []

    async def upsert_contact(self, contact: SupportDeskContact) -> SupportDeskContact:
        self.contact = contact
        return SupportDeskContact(
            id="contact-1",
            external_id=contact.external_id,
            name=contact.name,
            source_id="telegram-42-source",
            custom_attributes=contact.custom_attributes,
        )

    async def create_conversation(
        self,
        *,
        contact_id: str,
        source_id: str,
        custom_attributes: dict[str, object] | None = None,
    ) -> SupportDeskConversation:
        assert contact_id == "contact-1"
        assert custom_attributes is not None
        self.conversation_source_id = source_id
        return SupportDeskConversation(id="conversation-1", contact_id=contact_id)

    async def send_customer_message(
        self,
        *,
        conversation_id: str,
        content: str,
        source_id: str | None = None,
    ) -> SupportDeskMessage:
        self.messages.append((conversation_id, content, source_id))
        self.message_content = content
        return SupportDeskMessage(id="message-1", conversation_id=conversation_id)


@pytest.mark.asyncio
async def test_support_desk_adapter_creates_chatwoot_thread() -> None:
    fake_client = FakeChatwootClient()
    adapter = ChatwootSupportDeskAdapter(
        fake_client,  # type: ignore[arg-type]
        base_url="https://chatwoot.example.test",
        account_id=10,
    )

    payload = await adapter.create_ticket_thread(
        ticket_public_id="SUP-1001",
        customer_name=None,
        customer_channel="telegram",
        summary="Новое обращение SUP-1001",
        metadata={
            "telegram_user_id": "42",
            "telegram_chat_id": "100",
            "issue_type": "terminal_not_working",
            "priority": "p2",
            "location": "Филиал 1",
        },
    )

    assert fake_client.contact is not None
    assert fake_client.contact.external_id == "telegram:42"
    assert fake_client.contact.name == "Telegram user 42"
    assert fake_client.contact.custom_attributes["ticket_public_id"] == "SUP-1001"
    assert fake_client.conversation_source_id == "telegram-42-source"
    assert fake_client.message_content == "Новое обращение SUP-1001"
    assert fake_client.messages == [
        ("conversation-1", "Новое обращение SUP-1001", "ticket:SUP-1001:summary")
    ]
    assert payload == {
        "external_system": "chatwoot",
        "external_contact_id": "contact-1",
        "external_conversation_id": "conversation-1",
        "external_url": "https://chatwoot.example.test/app/accounts/10/conversations/conversation-1",
        "metadata": {
            "telegram_user_id": "42",
            "telegram_chat_id": "100",
            "issue_type": "terminal_not_working",
            "priority": "p2",
            "location": "Филиал 1",
            "contact_source_id": "telegram-42-source",
            "summary_message_id": "message-1",
        },
    }


@pytest.mark.asyncio
async def test_support_desk_adapter_sends_customer_followup() -> None:
    fake_client = FakeChatwootClient()
    adapter = ChatwootSupportDeskAdapter(fake_client)  # type: ignore[arg-type]

    await adapter.send_customer_message(
        external_conversation_id="conversation-1",
        text="Добавляю: терминал перезагружали",
        metadata={"source_id": "ticket:SUP-1001:customer_reply"},
    )

    assert fake_client.messages == [
        (
            "conversation-1",
            "Добавляю: терминал перезагружали",
            "ticket:SUP-1001:customer_reply",
        )
    ]
