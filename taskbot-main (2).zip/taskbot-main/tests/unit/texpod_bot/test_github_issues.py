from dataclasses import dataclass

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from texpod_bot.domain.enums import (
    IssueType,
    MessageSenderType,
    TicketEventType,
    TicketPriority,
    TicketStatus,
)
from texpod_bot.domain.schemas import (
    ClientCreate,
    DeviceCreate,
    TicketCreate,
    TicketEventCreate,
    TicketMessageCreate,
)
from texpod_bot.infrastructure.database.models import Base, Ticket
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.github_issues import (
    CreatedGitHubIssue,
    GitHubIssueService,
    GitHubIssueSettings,
)
from texpod_bot.services.tickets import TicketService


@dataclass(frozen=True, slots=True)
class CreateIssueCall:
    repo: str
    title: str
    body: str


class FakeGitHubIssueClient:
    def __init__(self, *, fail: bool = False) -> None:
        self.calls: list[CreateIssueCall] = []
        self._fail = fail

    async def create_issue(self, *, repo: str, title: str, body: str) -> CreatedGitHubIssue:
        self.calls.append(CreateIssueCall(repo=repo, title=title, body=body))
        if self._fail:
            raise RuntimeError("github unavailable")
        return CreatedGitHubIssue(html_url="https://github.test/acme/support/issues/7", number=7)


@pytest.fixture
async def session() -> AsyncSession:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

    sessionmaker = async_sessionmaker(engine, expire_on_commit=False)
    async with sessionmaker() as session:
        yield session

    await engine.dispose()


async def create_ticket_fixture(uow: SupportUnitOfWork) -> Ticket:
    client = await uow.clients.create(
        ClientCreate(
            name="Client Name",
            contact_name="Anna",
            phone="+10000000000",
            telegram_user_id="42",
        )
    )
    device = await uow.devices.create(
        DeviceCreate(
            client_id=client.id,
            device_id="kiosk-001",
            name="Front counter",
            app_version="1.2.3",
        )
    )
    ticket = await uow.tickets.create(
        TicketCreate(
            public_id="SUP-1001",
            client_id=client.id,
            device_id=device.id,
            telegram_chat_id="100",
            issue_type=IssueType.DEVICE_OFFLINE,
            status=TicketStatus.DEV_NEEDED,
            priority=TicketPriority.P1,
        )
    )
    await uow.events.create(
        TicketEventCreate(
            ticket_id=ticket.id,
            event_type=TicketEventType.RUNBOOK_STARTED,
            payload_json={
                "history": [
                    {
                        "step_key": "start",
                        "selected_option": "all devices",
                        "next_step": "escalate_p1",
                    }
                ]
            },
        )
    )
    await uow.messages.create(
        TicketMessageCreate(
            ticket_id=ticket.id,
            sender_type=MessageSenderType.CLIENT,
            sender_id=client.id,
            text="Kiosk is offline",
            attachment_url="telegram-file-id",
            telegram_message_id="777",
        )
    )
    await uow.commit()
    return ticket


def build_service(
    session: AsyncSession,
    client: FakeGitHubIssueClient,
    *,
    token: str | None = None,
    repo: str | None = "acme/support",
) -> tuple[GitHubIssueService, SupportUnitOfWork]:
    uow = SupportUnitOfWork(session)
    return (
        GitHubIssueService(
            uow=uow,
            ticket_service=TicketService(uow),
            settings=GitHubIssueSettings(token=token, repo=repo),
            client=client,
        ),
        uow,
    )


@pytest.mark.asyncio
async def test_github_integration_is_disabled_without_token_or_repo(
    session: AsyncSession,
) -> None:
    client = FakeGitHubIssueClient()
    service, uow = build_service(session, client, token=None)
    ticket = await create_ticket_fixture(uow)

    result = await service.create_issue_from_ticket(ticket.id)
    events = await uow.events.list_for_ticket(ticket.id)

    assert result is None
    assert client.calls == []
    assert all(event.event_type != TicketEventType.GITHUB_ISSUE_CREATED.value for event in events)


@pytest.mark.asyncio
async def test_create_issue_from_ticket_posts_formatted_issue(session: AsyncSession) -> None:
    client = FakeGitHubIssueClient()
    service, uow = build_service(session, client, token="dummy-github-token")
    ticket = await create_ticket_fixture(uow)

    result = await service.create_issue_from_ticket(ticket.id)
    events = await uow.events.list_for_ticket(ticket.id)

    assert result is not None
    assert result.number == 7
    assert client.calls[0].repo == "acme/support"
    assert client.calls[0].title == "[P1] KIOSK_OFFLINE — Client Name"
    assert "## Client" in client.calls[0].body
    assert "Client Name" in client.calls[0].body
    assert "kiosk-001" in client.calls[0].body
    assert "app_version: 1.2.3" in client.calls[0].body
    assert "device_offline" in client.calls[0].body
    assert "telegram-file-id" in client.calls[0].body
    assert "start -> escalate_p1 via all devices" in client.calls[0].body
    assert "SUP-1001" in client.calls[0].body
    assert any(event.event_type == TicketEventType.GITHUB_ISSUE_CREATED.value for event in events)


@pytest.mark.asyncio
async def test_format_issue_body_contains_required_sections(session: AsyncSession) -> None:
    client = FakeGitHubIssueClient()
    service, uow = build_service(session, client, token="dummy-github-token")
    ticket = await create_ticket_fixture(uow)

    body = await service.format_issue_body(ticket)

    assert "## Internal ticket" in body
    assert "## Client" in body
    assert "## Device" in body
    assert "## Issue" in body
    assert "## Timeline" in body
    assert "## Runbook path" in body
    assert "## Attachments" in body


@pytest.mark.asyncio
async def test_github_failure_creates_ticket_event_without_breaking_flow(
    session: AsyncSession,
) -> None:
    client = FakeGitHubIssueClient(fail=True)
    service, uow = build_service(session, client, token="dummy-github-token")
    ticket = await create_ticket_fixture(uow)

    result = await service.create_issue_from_ticket(ticket.id)
    events = await uow.events.list_for_ticket(ticket.id)

    assert result is None
    assert client.calls
    assert any(
        event.event_type == TicketEventType.GITHUB_ISSUE_CREATE_FAILED.value
        and event.payload_json["error"] == "RuntimeError"
        for event in events
    )
