from dataclasses import dataclass
from datetime import UTC, date, datetime, timedelta

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from texpod_bot.domain.enums import (
    IssueType,
    MessageSenderType,
    TicketEventType,
    TicketPriority,
    TicketStatus,
)
from texpod_bot.domain.schemas import (
    ClientCreate,
    DeviceCreate,
    TicketCreate,
    TicketEventCreate,
    TicketMessageCreate,
)
from texpod_bot.infrastructure.database.models import Base
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.analytics import AnalyticsService
from texpod_bot.services.telegram_escalation import SentTelegramMessage


@dataclass(frozen=True, slots=True)
class SentReport:
    chat_id: str
    text: str


class FakeTelegramApi:
    def __init__(self) -> None:
        self.sent: list[SentReport] = []

    async def send_message(
        self,
        *,
        chat_id: str,
        text: str,
        reply_to_message_id: str | None = None,
        message_thread_id: str | None = None,
    ) -> SentTelegramMessage:
        self.sent.append(SentReport(chat_id=chat_id, text=text))
        return SentTelegramMessage(message_id="1", message_thread_id=message_thread_id)


@pytest.fixture
async def session() -> AsyncSession:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

    sessionmaker = async_sessionmaker(engine, expire_on_commit=False)
    async with sessionmaker() as session:
        yield session

    await engine.dispose()


async def seed_daily_report_data(uow: SupportUnitOfWork) -> None:
    report_day = date(2026, 4, 27)
    base = datetime.combine(report_day, datetime.min.time(), tzinfo=UTC)
    other_day = base - timedelta(days=1)

    bakery = await uow.clients.create(ClientCreate(name="Bakery One", telegram_user_id="42"))
    cafe = await uow.clients.create(ClientCreate(name="Cafe Two", telegram_user_id="43"))
    device = await uow.devices.create(
        DeviceCreate(client_id=bakery.id, device_id="kiosk-001", app_version="1.2.3")
    )
    device_missing_version = await uow.devices.create(
        DeviceCreate(client_id=cafe.id, device_id="kiosk-002")
    )

    ticket_runbook = await uow.tickets.create(
        TicketCreate(
            public_id="SUP-1",
            client_id=bakery.id,
            device_id=device.id,
            telegram_chat_id="100",
            issue_type=IssueType.DEVICE_OFFLINE,
            status=TicketStatus.RESOLVED,
            priority=TicketPriority.P2,
        )
    )
    ticket_runbook.created_at = base + timedelta(hours=1)
    ticket_runbook.updated_at = base + timedelta(hours=1, minutes=20)
    ticket_runbook.closed_at = base + timedelta(hours=1, minutes=30)

    ticket_operator = await uow.tickets.create(
        TicketCreate(
            public_id="SUP-2",
            client_id=bakery.id,
            telegram_chat_id="101",
            issue_type=IssueType.SOFTWARE,
            status=TicketStatus.WAITING_SUPPORT,
            priority=TicketPriority.P1,
        )
    )
    ticket_operator.created_at = base + timedelta(hours=2)

    ticket_missing_version = await uow.tickets.create(
        TicketCreate(
            public_id="SUP-3",
            client_id=cafe.id,
            device_id=device_missing_version.id,
            telegram_chat_id="102",
            issue_type=IssueType.SOFTWARE,
            status=TicketStatus.CLOSED,
            priority=TicketPriority.P3,
        )
    )
    ticket_missing_version.created_at = base + timedelta(hours=3)
    ticket_missing_version.closed_at = base + timedelta(hours=5)

    old_ticket = await uow.tickets.create(
        TicketCreate(
            public_id="SUP-OLD",
            client_id=cafe.id,
            telegram_chat_id="103",
            issue_type=IssueType.PAYMENT,
            status=TicketStatus.CLOSED,
            priority=TicketPriority.P4,
        )
    )
    old_ticket.created_at = other_day

    await uow.messages.create(
        TicketMessageCreate(
            ticket_id=ticket_runbook.id,
            sender_type=MessageSenderType.BOT,
            text="Runbook answer",
        )
    )
    await uow.messages.create(
        TicketMessageCreate(
            ticket_id=ticket_operator.id,
            sender_type=MessageSenderType.SUPPORT,
            text="Operator answer",
        )
    )
    await uow.messages.create(
        TicketMessageCreate(
            ticket_id=ticket_missing_version.id,
            sender_type=MessageSenderType.SUPPORT,
            text="Closed answer",
        )
    )
    await uow.session.flush()

    messages = await uow.messages.list_for_ticket(ticket_runbook.id)
    messages[0].created_at = ticket_runbook.created_at + timedelta(minutes=10)
    messages = await uow.messages.list_for_ticket(ticket_operator.id)
    messages[0].created_at = ticket_operator.created_at + timedelta(minutes=30)
    messages = await uow.messages.list_for_ticket(ticket_missing_version.id)
    messages[0].created_at = ticket_missing_version.created_at + timedelta(minutes=20)

    await uow.events.create(
        TicketEventCreate(
            ticket_id=ticket_runbook.id,
            event_type=TicketEventType.RESOLVED,
            payload_json={},
        )
    )
    escalated = await uow.events.create(
        TicketEventCreate(
            ticket_id=ticket_operator.id,
            event_type=TicketEventType.ESCALATED,
            payload_json={},
        )
    )
    path_event = await uow.events.create(
        TicketEventCreate(
            ticket_id=ticket_operator.id,
            event_type=TicketEventType.RUNBOOK_STARTED,
            payload_json={
                "history": [{"step_key": "start", "selected_option": "no", "next_step": "collect"}]
            },
        )
    )
    escalated.created_at = ticket_operator.created_at + timedelta(minutes=5)
    path_event.created_at = ticket_operator.created_at
    await uow.commit()


@pytest.mark.asyncio
async def test_daily_report_calculates_support_metrics(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    await seed_daily_report_data(uow)
    service = AnalyticsService(uow)

    report = await service.build_daily_report(date(2026, 4, 27))

    assert report.tickets_total == 3
    assert report.tickets_by_issue_type == {"device_offline": 1, "software": 2}
    assert report.tickets_by_priority == {"p1": 1, "p2": 1, "p3": 1}
    assert report.resolved_by_runbook == 1
    assert report.escalated_to_operator == 1
    assert report.average_first_response_seconds == 1200
    assert report.average_close_seconds == 4500
    assert report.top_clients[0] == ("Bakery One", 2)
    assert report.top_problems[0] == ("software", 2)
    assert report.tickets_missing_app_version_or_device_id == 2


@pytest.mark.asyncio
async def test_daily_report_format_is_telegram_markdown_text(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    await seed_daily_report_data(uow)
    service = AnalyticsService(uow)

    text = service.format_daily_report(await service.build_daily_report(date(2026, 4, 27)))

    assert "*Daily support report — 2026-04-27*" in text
    assert "*Tickets total:* 3" in text
    assert "- software: 2" in text
    assert "*Avg first response:* 20.0 min" in text
    assert "*Missing app_version/device_id:* 2" in text


@pytest.mark.asyncio
async def test_daily_report_can_be_sent_to_support_group(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    await seed_daily_report_data(uow)
    service = AnalyticsService(uow)
    telegram = FakeTelegramApi()

    text = await service.send_daily_report(
        report_date=date(2026, 4, 27),
        telegram_api=telegram,
        support_group_id="-100123",
    )

    assert telegram.sent == [SentReport(chat_id="-100123", text=text)]
