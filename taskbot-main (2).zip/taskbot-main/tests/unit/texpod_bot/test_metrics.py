from datetime import UTC, date, datetime, timedelta

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from texpod_bot.domain.enums import (
    IssueType,
    MessageSenderType,
    TicketEventType,
    TicketPriority,
    TicketStatus,
)
from texpod_bot.domain.schemas import (
    ClientCreate,
    TicketCreate,
    TicketEventCreate,
    TicketMessageCreate,
)
from texpod_bot.infrastructure.database.models import Base
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.metrics import MetricsFilter, MetricsService


@pytest.fixture
async def session() -> AsyncSession:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

    sessionmaker = async_sessionmaker(engine, expire_on_commit=False)
    async with sessionmaker() as session:
        yield session

    await engine.dispose()


async def seed_metrics_data(uow: SupportUnitOfWork) -> datetime:
    base = datetime.combine(date(2026, 4, 29), datetime.min.time(), tzinfo=UTC)
    client = await uow.clients.create(ClientCreate(name="Bakery", telegram_user_id="42"))
    self_resolved = await uow.tickets.create(
        TicketCreate(
            public_id="SUP-1",
            client_id=client.id,
            telegram_chat_id="100",
            issue_type=IssueType.MENU_SYNC,
            status=TicketStatus.RESOLVED,
            priority=TicketPriority.P3,
        )
    )
    self_resolved.created_at = base + timedelta(hours=1)
    self_resolved.resolved_at = base + timedelta(hours=1, minutes=15)

    escalated = await uow.tickets.create(
        TicketCreate(
            public_id="SUP-2",
            client_id=client.id,
            telegram_chat_id="101",
            issue_type=IssueType.SOFTWARE,
            status=TicketStatus.WAITING_SUPPORT,
            priority=TicketPriority.P1,
        )
    )
    escalated.created_at = base + timedelta(hours=2)
    escalated.first_response_at = base + timedelta(hours=2, minutes=20)

    cancelled = await uow.tickets.create(
        TicketCreate(
            public_id="SUP-3",
            client_id=client.id,
            telegram_chat_id="102",
            issue_type=IssueType.SOFTWARE,
            status=TicketStatus.CANCELLED,
            priority=TicketPriority.P4,
        )
    )
    cancelled.created_at = base + timedelta(hours=3)

    await uow.events.create(
        TicketEventCreate(
            ticket_id=self_resolved.id,
            event_type=TicketEventType.RUNBOOK_STARTED,
            payload_json={"runbook_code": "SYNC_FAILED"},
        )
    )
    await uow.events.create(
        TicketEventCreate(
            ticket_id=escalated.id,
            event_type=TicketEventType.ESCALATED,
            payload_json={"source": "telegram"},
        )
    )
    await uow.events.create(
        TicketEventCreate(
            ticket_id=cancelled.id,
            event_type=TicketEventType.RUNBOOK_ABANDONED,
            payload_json={"step_key": "collect_media"},
        )
    )
    await uow.messages.create(
        TicketMessageCreate(
            ticket_id=escalated.id,
            sender_type=MessageSenderType.SUPPORT,
            sender_id="operator-1",
            text="Checking",
            attachment_url="file-1",
        )
    )
    await uow.commit()
    return base


@pytest.mark.asyncio
async def test_metrics_snapshot_aggregates_support_and_runbook_metrics(
    session: AsyncSession,
) -> None:
    uow = SupportUnitOfWork(session)
    base = await seed_metrics_data(uow)
    service = MetricsService(uow)

    snapshot = await service.build_snapshot(
        MetricsFilter(date_from=base, date_to=base + timedelta(days=1))
    )

    assert snapshot.support.tickets_total == 3
    assert snapshot.support.tickets_by_status["waiting_support"] == 1
    assert snapshot.support.tickets_by_category["software"] == 2
    assert snapshot.support.tickets_by_priority["p1"] == 1
    assert snapshot.support.escalation_rate == pytest.approx(1 / 3)
    assert snapshot.support.runbook_self_resolution_rate == pytest.approx(1 / 3)
    assert snapshot.support.average_first_response_seconds == 1200
    assert snapshot.support.average_resolution_seconds == 900
    assert snapshot.support.cancelled_or_abandoned == 1
    assert snapshot.support.tickets_with_attachments == 1
    assert snapshot.support.operator_workload == {"operator-1": 1}
    assert snapshot.runbooks.starts == 1
    assert snapshot.runbooks.escalated == 1
    assert snapshot.runbooks.drop_off_by_step == {"collect_media": 1}


@pytest.mark.asyncio
async def test_metrics_filter_limits_by_channel_and_status(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    base = await seed_metrics_data(uow)
    service = MetricsService(uow)

    snapshot = await service.build_snapshot(
        MetricsFilter(
            date_from=base,
            date_to=base + timedelta(days=1),
            status=TicketStatus.WAITING_SUPPORT.value,
        )
    )

    assert snapshot.support.tickets_total == 1
    assert snapshot.support.tickets_by_status == {"waiting_support": 1}


@pytest.mark.asyncio
async def test_metrics_summary_format_is_operator_friendly(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    base = await seed_metrics_data(uow)
    service = MetricsService(uow)

    snapshot = await service.build_snapshot(
        MetricsFilter(date_from=base, date_to=base + timedelta(days=1))
    )
    text = service.format_support_summary(snapshot)

    assert "Статистика поддержки" in text
    assert "Всего обращений: 3" in text
    assert "По статусам:" in text
    assert "Эскалации: 33.3%" in text
    assert "Первый ответ: 20.0 мин" in text


@pytest.mark.asyncio
async def test_metrics_summary_has_empty_state(session: AsyncSession) -> None:
    service = MetricsService(SupportUnitOfWork(session))
    base = datetime.combine(date(2026, 4, 29), datetime.min.time(), tzinfo=UTC)

    snapshot = await service.build_snapshot(
        MetricsFilter(date_from=base, date_to=base + timedelta(days=1))
    )

    assert "За выбранный период обращений нет." in service.format_support_summary(snapshot)
