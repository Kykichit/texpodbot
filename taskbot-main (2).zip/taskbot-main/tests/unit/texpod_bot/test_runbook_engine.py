from pathlib import Path

import pytest
from texpod_bot.domain.runbooks import (
    RunbookAction,
    RunbookEngine,
    RunbookValidationError,
    UnknownRunbookOptionError,
    load_runbook_from_yaml,
    load_runbooks_from_dir,
    parse_runbook,
)


def test_load_valid_sample_runbook() -> None:
    runbook = load_runbook_from_yaml(Path("runbooks/KIOSK_OFFLINE.yaml"))

    assert runbook.code == "KIOSK_OFFLINE"
    assert runbook.step("start").text == "Проблема на одном устройстве или на всех?"
    assert [option.label for option in runbook.step("start").options] == ["На одном", "На всех"]


def test_invalid_runbook_raises_validation_error() -> None:
    with pytest.raises(RunbookValidationError, match="unknown step"):
        parse_runbook(
            {
                "code": "BROKEN",
                "title": "Broken",
                "steps": {
                    "start": {
                        "text": "Choose",
                        "options": [{"label": "Next", "next": "missing"}],
                    }
                },
            }
        )


def test_engine_transitions_between_steps() -> None:
    engine = RunbookEngine(load_runbooks_from_dir(Path("runbooks")))
    session = engine.start("KIOSK_OFFLINE")

    assert engine.current_step(session).step_key == "start"

    session = engine.choose_option(session, "На одном")

    assert engine.current_step(session).step_key == "check_internet"
    assert session.history[-1].selected_option == "На одном"


def test_engine_resolved_action_finishes_session() -> None:
    engine = RunbookEngine(load_runbooks_from_dir(Path("runbooks")))
    session = engine.start("KIOSK_OFFLINE")

    session = engine.choose_option(session, "На одном")
    session = engine.choose_option(session, "Интернет есть")
    session = engine.choose_option(session, "Да")

    assert session.finished is True
    assert session.action == RunbookAction.RESOLVED
    assert engine.current_step(session).step_key == "resolved"


def test_engine_escalate_action_finishes_after_action_step_advance() -> None:
    engine = RunbookEngine(load_runbooks_from_dir(Path("runbooks")))
    session = engine.start("APP_FREEZE")

    session = engine.choose_option(session, "Постоянно")
    session = engine.choose_option(session, "Нет")

    assert session.finished is False
    assert engine.current_step(session).action == RunbookAction.COLLECT_MEDIA

    session = engine.advance_action_step(session)

    assert session.finished is True
    assert session.action == RunbookAction.ESCALATE
    assert engine.current_step(session).step_key == "escalate_support"


def test_engine_create_ticket_action_finishes_session() -> None:
    engine = RunbookEngine(load_runbooks_from_dir(Path("runbooks")))
    session = engine.start("SYNC_FAILED")

    session = engine.choose_option(session, "Меню")
    session = engine.choose_option(session, "Сохранены")
    session = engine.choose_option(session, "Нет")
    session = engine.advance_action_step(session)

    assert session.finished is True
    assert session.action == RunbookAction.CREATE_TICKET
    assert engine.current_step(session).step_key == "create_ticket"


def test_engine_unknown_option_raises_error() -> None:
    engine = RunbookEngine(load_runbooks_from_dir(Path("runbooks")))
    session = engine.start("KIOSK_OFFLINE")

    with pytest.raises(UnknownRunbookOptionError, match="Unknown option"):
        engine.choose_option(session, "Неизвестно")
