from pathlib import Path

from bot.common.messages import GENERIC_ERROR_MESSAGE
from bot.telegram.support_keyboards import build_main_menu_keyboard

FORBIDDEN_MOJIBAKE_MARKERS = (
    "Ð",
    "Ñ",
    "вЂ",
    "вњ",
    "Ѓ",
    "Љ",
    "Њ",
    "Ќ",
    "Џ",
    "Ћ",
    "Ђ",
    "Є",
    "Ѕ",
    "Ј",
    "њ",
    "љ",
    "џ",
    "ћ",
    "ѓ",
    "є",
    "ѕ",
    "ј",
)

FORBIDDEN_CLIENT_COPY_MARKERS = (
    "Сообщение добавлено к обращению",
    "Ответ поддержки по",
)

UX_COPY_FILES = (
    Path("src/bot/common/messages.py"),
    Path("src/bot/telegram/support_keyboards.py"),
    Path("src/bot/telegram/support_handlers.py"),
    Path("src/bot/telegram/intake_handlers.py"),
    Path("texpod_bot/services/intake_prototype.py"),
    Path("texpod_bot/services/structured_collection.py"),
    Path("texpod_bot/services/support_group_bridge.py"),
    Path("texpod_bot/services/telegram_escalation.py"),
    Path("texpod_bot/services/telegram_support.py"),
    Path("texpod_bot/services/metrics.py"),
    Path("texpod_bot/services/chatwoot_webhook.py"),
)

CLIENT_RUNTIME_COPY_FILES = (
    Path("src/bot/telegram/intake_handlers.py"),
    Path("src/bot/telegram/support_handlers.py"),
    Path("texpod_bot/services/intake_prototype.py"),
    Path("texpod_bot/services/chatwoot_webhook.py"),
    Path("texpod_bot/services/telegram_support.py"),
)


def test_key_ux_copy_files_do_not_contain_mojibake() -> None:
    for path in UX_COPY_FILES:
        text = path.read_text(encoding="utf-8")
        for marker in FORBIDDEN_MOJIBAKE_MARKERS:
            assert marker not in text, f"{path} contains mojibake marker {marker!r}"


def test_client_runtime_copy_does_not_use_confirmation_spam() -> None:
    for path in CLIENT_RUNTIME_COPY_FILES:
        text = path.read_text(encoding="utf-8")
        for marker in FORBIDDEN_CLIENT_COPY_MARKERS:
            assert marker not in text, f"{path} contains client copy marker {marker!r}"


def test_generic_error_message_is_customer_safe() -> None:
    assert "traceback" not in GENERIC_ERROR_MESSAGE.casefold()
    assert "JSON" not in GENERIC_ERROR_MESSAGE
    assert "/start" in GENERIC_ERROR_MESSAGE


def test_main_menu_keyboard_copy_is_short_and_readable() -> None:
    keyboard = build_main_menu_keyboard()
    labels = [button.text for row in keyboard.inline_keyboard for button in row]

    assert labels == ["Выбрать проблему", "Отмена"]
    assert all(len(label) <= 24 for label in labels)
