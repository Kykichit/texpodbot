import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from texpod_bot.domain.enums import (
    IssueType,
    MessageSenderType,
    TicketEventType,
    TicketPriority,
    TicketStatus,
)
from texpod_bot.domain.schemas import ClientCreate, TicketCreate, TicketExternalRefCreate
from texpod_bot.infrastructure.database.models import Base, Ticket
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.chatwoot_webhook import (
    ChatwootWebhookService,
    WebhookHandleStatus,
    parse_chatwoot_conversation_status_event,
    parse_chatwoot_message_event,
)


class FakeMessenger:
    def __init__(self, *, fail: bool = False) -> None:
        self.fail = fail
        self.sent: list[tuple[str, str]] = []

    async def send_text(self, *, chat_id: str, text: str) -> None:
        self.sent.append((chat_id, text))
        if self.fail:
            raise RuntimeError("telegram unavailable")


@pytest.fixture
async def sessionmaker() -> async_sessionmaker[AsyncSession]:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

    maker = async_sessionmaker(engine, expire_on_commit=False)
    yield maker
    await engine.dispose()


def test_parser_extracts_outgoing_operator_message() -> None:
    event = parse_chatwoot_message_event(
        {
            "event": "message_created",
            "conversation": {"id": 123},
            "content": "Здравствуйте, проверяем терминал",
            "message_type": "outgoing",
            "private": False,
            "id": 777,
            "sender": {"id": 5, "name": "Operator"},
        }
    )

    assert event.should_route_to_customer is True
    assert event.conversation_id == "123"
    assert event.content == "Здравствуйте, проверяем терминал"
    assert event.message_type == "outgoing"
    assert event.private is False
    assert event.message_id == "777"
    assert event.sender_id == "5"
    assert event.sender_name == "Operator"


def test_parser_ignores_private_note() -> None:
    event = parse_chatwoot_message_event(
        {
            "event": "message_created",
            "conversation_id": "conversation-1",
            "content": "Internal note",
            "message_type": "outgoing",
            "private": True,
        }
    )

    assert event.should_route_to_customer is False


def test_parser_ignores_incoming_customer_message() -> None:
    event = parse_chatwoot_message_event(
        {
            "event": "message_created",
            "conversation_id": "conversation-1",
            "content": "Customer echo",
            "message_type": "incoming",
        }
    )

    assert event.should_route_to_customer is False


def test_parser_handles_missing_fields_gracefully() -> None:
    event = parse_chatwoot_message_event({"event": "message_created"})

    assert event.should_route_to_customer is False
    assert event.conversation_id is None
    assert event.content is None


def test_parser_extracts_nested_message_shape() -> None:
    event = parse_chatwoot_message_event(
        {
            "event": "message_created",
            "message": {
                "conversation_id": "conversation-2",
                "content": "Готово, попробуйте снова",
                "message_type": "outgoing",
                "private": False,
                "id": "message-2",
            },
        }
    )

    assert event.should_route_to_customer is True
    assert event.conversation_id == "conversation-2"
    assert event.message_id == "message-2"


def test_parser_extracts_conversation_status_changed_resolved() -> None:
    event = parse_chatwoot_conversation_status_event(
        {
            "event": "conversation_status_changed",
            "conversation": {"id": 123, "status": "resolved"},
            "previous_status": "open",
        }
    )

    assert event.should_close_ticket is True
    assert event.conversation_id == "123"
    assert event.conversation_status == "resolved"
    assert event.previous_status == "open"


def test_parser_extracts_conversation_updated_closed() -> None:
    event = parse_chatwoot_conversation_status_event(
        {
            "event": "conversation_updated",
            "conversation": {"id": "conversation-1", "status": "closed"},
        }
    )

    assert event.should_close_ticket is True
    assert event.conversation_id == "conversation-1"
    assert event.conversation_status == "closed"


def test_parser_ignores_non_closed_conversation_status() -> None:
    event = parse_chatwoot_conversation_status_event(
        {
            "event": "conversation_updated",
            "conversation": {"id": "conversation-1", "status": "open"},
        }
    )

    assert event.should_close_ticket is False


def test_parser_handles_missing_conversation_id_for_close_event() -> None:
    event = parse_chatwoot_conversation_status_event(
        {
            "event": "conversation_status_changed",
            "status": "resolved",
        }
    )

    assert event.should_close_ticket is False
    assert event.conversation_id is None


@pytest.mark.asyncio
async def test_operator_reply_routes_to_telegram_and_persists(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    messenger = FakeMessenger()
    service = ChatwootWebhookService(sessionmaker=sessionmaker, messenger=messenger)
    ticket = await _create_ticket_with_chatwoot_ref(sessionmaker, conversation_id="conversation-1")

    result = await service.handle_webhook(_operator_payload(conversation_id="conversation-1"))

    assert result.status == WebhookHandleStatus.SENT
    assert messenger.sent == [("100", "Здравствуйте, проверяем терминал")]
    assert "SUP-1001" not in messenger.sent[0][1]
    assert "Ответ поддержки по" not in messenger.sent[0][1]
    timeline = await _ticket_timeline(sessionmaker, ticket.id)
    assert len(timeline["messages"]) == 1
    assert timeline["messages"][0].sender_type == MessageSenderType.SUPPORT.value
    assert timeline["messages"][0].sender_id == "5"
    assert timeline["messages"][0].text == "Здравствуйте, проверяем терминал"
    assert any(
        event.event_type == TicketEventType.CHATWOOT_OPERATOR_REPLY_SENT.value
        for event in timeline["events"]
    )


@pytest.mark.asyncio
async def test_missing_external_ref_returns_not_found(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    messenger = FakeMessenger()
    service = ChatwootWebhookService(sessionmaker=sessionmaker, messenger=messenger)

    result = await service.handle_webhook(_operator_payload(conversation_id="missing"))

    assert result.status == WebhookHandleStatus.NOT_FOUND
    assert result.reason == "external_ref_not_found"
    assert messenger.sent == []


@pytest.mark.asyncio
async def test_private_note_does_not_send(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    messenger = FakeMessenger()
    service = ChatwootWebhookService(sessionmaker=sessionmaker, messenger=messenger)
    await _create_ticket_with_chatwoot_ref(sessionmaker, conversation_id="conversation-1")

    result = await service.handle_webhook(
        {
            "event": "message_created",
            "conversation_id": "conversation-1",
            "content": "internal",
            "message_type": "outgoing",
            "private": True,
        }
    )

    assert result.status == WebhookHandleStatus.IGNORED
    assert result.reason == "private_note"
    assert messenger.sent == []


@pytest.mark.asyncio
async def test_telegram_send_failure_creates_event_without_crashing(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    messenger = FakeMessenger(fail=True)
    service = ChatwootWebhookService(sessionmaker=sessionmaker, messenger=messenger)
    ticket = await _create_ticket_with_chatwoot_ref(sessionmaker, conversation_id="conversation-1")

    result = await service.handle_webhook(_operator_payload(conversation_id="conversation-1"))

    assert result.status == WebhookHandleStatus.SEND_FAILED
    timeline = await _ticket_timeline(sessionmaker, ticket.id)
    assert timeline["messages"] == []
    assert any(
        event.event_type == TicketEventType.CHATWOOT_OPERATOR_REPLY_SEND_FAILED.value
        and event.payload_json["error"] == "RuntimeError"
        for event in timeline["events"]
    )


@pytest.mark.asyncio
async def test_resolved_event_closes_ticket_and_notifies_customer(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    messenger = FakeMessenger()
    service = ChatwootWebhookService(sessionmaker=sessionmaker, messenger=messenger)
    ticket = await _create_ticket_with_chatwoot_ref(sessionmaker, conversation_id="conversation-1")

    result = await service.handle_webhook(_resolved_payload(conversation_id="conversation-1"))

    assert result.status == WebhookHandleStatus.CLOSED
    assert messenger.sent == [("100", "Обращение SUP-1001 закрыто. Спасибо!")]
    saved_ticket = await _ticket(sessionmaker, ticket.id)
    assert saved_ticket is not None
    assert saved_ticket.status == TicketStatus.CLOSED.value
    assert saved_ticket.closed_at is not None
    timeline = await _ticket_timeline(sessionmaker, ticket.id)
    assert any(
        event.event_type == TicketEventType.CHATWOOT_CONVERSATION_RESOLVED.value
        and event.payload_json["external_conversation_id"] == "conversation-1"
        for event in timeline["events"]
    )


@pytest.mark.asyncio
async def test_closed_event_already_closed_ticket_does_not_notify_twice(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    messenger = FakeMessenger()
    service = ChatwootWebhookService(sessionmaker=sessionmaker, messenger=messenger)
    ticket = await _create_ticket_with_chatwoot_ref(sessionmaker, conversation_id="conversation-1")
    await _set_ticket_status(sessionmaker, ticket.id, TicketStatus.CLOSED)

    result = await service.handle_webhook(_resolved_payload(conversation_id="conversation-1"))

    assert result.status == WebhookHandleStatus.ALREADY_CLOSED
    assert result.reason == "ticket_already_closed"
    assert messenger.sent == []


@pytest.mark.asyncio
async def test_resolved_event_missing_external_ref_returns_not_found(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    messenger = FakeMessenger()
    service = ChatwootWebhookService(sessionmaker=sessionmaker, messenger=messenger)

    result = await service.handle_webhook(_resolved_payload(conversation_id="missing"))

    assert result.status == WebhookHandleStatus.NOT_FOUND
    assert result.reason == "external_ref_not_found"
    assert messenger.sent == []


@pytest.mark.asyncio
async def test_close_notification_failure_keeps_ticket_closed_and_records_event(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    messenger = FakeMessenger(fail=True)
    service = ChatwootWebhookService(sessionmaker=sessionmaker, messenger=messenger)
    ticket = await _create_ticket_with_chatwoot_ref(sessionmaker, conversation_id="conversation-1")

    result = await service.handle_webhook(_resolved_payload(conversation_id="conversation-1"))

    assert result.status == WebhookHandleStatus.CLOSE_NOTIFY_FAILED
    saved_ticket = await _ticket(sessionmaker, ticket.id)
    assert saved_ticket is not None
    assert saved_ticket.status == TicketStatus.CLOSED.value
    assert saved_ticket.closed_at is not None
    timeline = await _ticket_timeline(sessionmaker, ticket.id)
    assert any(
        event.event_type == TicketEventType.CHATWOOT_TICKET_CLOSE_NOTIFY_FAILED.value
        and event.payload_json["error"] == "RuntimeError"
        for event in timeline["events"]
    )


@pytest.mark.asyncio
async def test_operator_reply_flow_still_works_after_close_support_added(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    messenger = FakeMessenger()
    service = ChatwootWebhookService(sessionmaker=sessionmaker, messenger=messenger)
    ticket = await _create_ticket_with_chatwoot_ref(sessionmaker, conversation_id="conversation-1")

    result = await service.handle_webhook(_operator_payload(conversation_id="conversation-1"))

    assert result.status == WebhookHandleStatus.SENT
    saved_ticket = await _ticket(sessionmaker, ticket.id)
    assert saved_ticket is not None
    assert saved_ticket.status != TicketStatus.CLOSED.value
    assert messenger.sent == [("100", "Здравствуйте, проверяем терминал")]
    assert "SUP-1001" not in messenger.sent[0][1]
    assert "Ответ поддержки по" not in messenger.sent[0][1]


async def _create_ticket_with_chatwoot_ref(
    sessionmaker: async_sessionmaker[AsyncSession],
    *,
    conversation_id: str,
) -> Ticket:
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        client = await uow.clients.create(ClientCreate(name="Bakery", telegram_user_id="42"))
        ticket = await uow.tickets.create(
            TicketCreate(
                public_id="SUP-1001",
                client_id=client.id,
                telegram_chat_id="100",
                issue_type=IssueType.TERMINAL_NOT_WORKING,
                priority=TicketPriority.P2,
            )
        )
        await uow.external_refs.create_or_update_external_ref(
            TicketExternalRefCreate(
                ticket_id=ticket.id,
                external_system="chatwoot",
                external_contact_id="contact-1",
                external_conversation_id=conversation_id,
            )
        )
        await uow.commit()
        return ticket


async def _ticket(
    sessionmaker: async_sessionmaker[AsyncSession],
    ticket_id: str,
) -> Ticket | None:
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        return await uow.tickets.get(ticket_id)


async def _ticket_timeline(
    sessionmaker: async_sessionmaker[AsyncSession],
    ticket_id: str,
) -> dict[str, list[object]]:
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        return {
            "messages": await uow.messages.list_for_ticket(ticket_id),
            "events": await uow.events.list_for_ticket(ticket_id),
        }


async def _set_ticket_status(
    sessionmaker: async_sessionmaker[AsyncSession],
    ticket_id: str,
    status: TicketStatus,
) -> None:
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        ticket = await uow.tickets.get(ticket_id)
        assert ticket is not None
        ticket.status = status.value
        await uow.commit()


def _operator_payload(*, conversation_id: str) -> dict[str, object]:
    return {
        "event": "message_created",
        "conversation_id": conversation_id,
        "content": "Здравствуйте, проверяем терминал",
        "message_type": "outgoing",
        "private": False,
        "id": "message-1",
        "sender": {"id": 5, "name": "Operator"},
    }


def _resolved_payload(*, conversation_id: str) -> dict[str, object]:
    return {
        "event": "conversation_status_changed",
        "conversation": {"id": conversation_id, "status": "resolved"},
        "previous_status": "open",
    }
