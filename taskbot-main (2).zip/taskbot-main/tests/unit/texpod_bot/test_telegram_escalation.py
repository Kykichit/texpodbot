from dataclasses import dataclass

import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from texpod_bot.domain.enums import (
    IssueType,
    MessageSenderType,
    TicketEventType,
    TicketPriority,
    TicketStatus,
)
from texpod_bot.domain.schemas import (
    ClientCreate,
    SupportOperatorCreate,
    TicketCreate,
    TicketEventCreate,
)
from texpod_bot.infrastructure.database.models import Base, Ticket
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.telegram_escalation import (
    ACCESS_DENIED_MESSAGE,
    ClientReply,
    SentTelegramMessage,
    SupportGroupReply,
    TelegramEscalationService,
)
from texpod_bot.services.tickets import TicketService


@dataclass(frozen=True, slots=True)
class SentCall:
    chat_id: str
    text: str
    reply_to_message_id: str | None
    message_thread_id: str | None


class FakeTelegramSupportApi:
    def __init__(self) -> None:
        self.calls: list[SentCall] = []
        self._next_message_id = 1000

    async def send_message(
        self,
        *,
        chat_id: str,
        text: str,
        reply_to_message_id: str | None = None,
        message_thread_id: str | None = None,
    ) -> SentTelegramMessage:
        self.calls.append(
            SentCall(
                chat_id=chat_id,
                text=text,
                reply_to_message_id=reply_to_message_id,
                message_thread_id=message_thread_id,
            )
        )
        self._next_message_id += 1
        return SentTelegramMessage(
            message_id=str(self._next_message_id),
            message_thread_id=message_thread_id,
        )


@pytest.fixture
async def session() -> AsyncSession:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

    sessionmaker = async_sessionmaker(engine, expire_on_commit=False)
    async with sessionmaker() as session:
        yield session

    await engine.dispose()


async def create_ticket(uow: SupportUnitOfWork) -> Ticket:
    client = await uow.clients.create(
        ClientCreate(
            name="Texpod Bakery",
            contact_name="Anna",
            telegram_user_id="42",
        )
    )
    ticket = await uow.tickets.create(
        TicketCreate(
            public_id="SUP-1001",
            client_id=client.id,
            telegram_chat_id="client-chat-1",
            issue_type=IssueType.DEVICE_OFFLINE,
            status=TicketStatus.NEW,
            priority=TicketPriority.P2,
        )
    )
    await uow.events.create(
        TicketEventCreate(
            ticket_id=ticket.id,
            event_type=TicketEventType.RUNBOOK_STARTED,
            payload_json={
                "history": [
                    {"step_key": "check_internet", "selected_option": "internet ok"},
                    {"step_key": "restart_app", "selected_option": "not helped"},
                ]
            },
        )
    )
    await uow.commit()
    return ticket


def build_service(
    session: AsyncSession,
    api: FakeTelegramSupportApi,
) -> tuple[TelegramEscalationService, SupportUnitOfWork]:
    uow = SupportUnitOfWork(session)
    ticket_service = TicketService(uow)
    return (
        TelegramEscalationService(
            uow=uow,
            ticket_service=ticket_service,
            telegram_api=api,
            support_group_id="support-group",
        ),
        uow,
    )


@pytest.mark.asyncio
async def test_escalate_sends_summary(session: AsyncSession) -> None:
    api = FakeTelegramSupportApi()
    service, uow = build_service(session, api)
    ticket = await create_ticket(uow)

    routing = await service.escalate_to_support_group(ticket.id)

    assert api.calls[0].chat_id == "support-group"
    assert "SUP-1001" in api.calls[0].text
    assert "Texpod Bakery" in api.calls[0].text
    assert "p2" in api.calls[0].text
    assert "check_internet: internet ok" in api.calls[0].text
    assert routing.client_chat_id == "client-chat-1"
    assert routing.support_group_message_id == "1001"


@pytest.mark.asyncio
async def test_ticket_summary_includes_structured_collection(session: AsyncSession) -> None:
    api = FakeTelegramSupportApi()
    service, uow = build_service(session, api)
    ticket = await create_ticket(uow)
    await uow.events.create(
        TicketEventCreate(
            ticket_id=ticket.id,
            event_type=TicketEventType.RUNBOOK_STEP_COMPLETED,
            payload_json={
                "collection": {
                    "client_name": "Texpod Bakery",
                    "location": "Central branch",
                    "problem_started_at": "today",
                    "affected_scope": "all_devices",
                    "business_blocked": "yes",
                    "device_id": None,
                    "app_version": None,
                    "screenshot_or_video": {"file_id": "photo-file-id"},
                    "free_text_description": "All kiosks are offline",
                }
            },
        )
    )
    await uow.commit()

    await service.escalate_to_support_group(ticket.id)

    assert "Collected:" in api.calls[0].text
    assert "location: Central branch" in api.calls[0].text
    assert "affected_scope: all_devices" in api.calls[0].text
    assert "screenshot_or_video: photo-file-id" in api.calls[0].text


@pytest.mark.asyncio
async def test_operator_reply_is_routed_to_client(session: AsyncSession) -> None:
    api = FakeTelegramSupportApi()
    service, uow = build_service(session, api)
    ticket = await create_ticket(uow)
    await service.escalate_to_support_group(ticket.id)
    operator = await uow.operators.create(
        SupportOperatorCreate(telegram_user_id="9001", display_name="Support One")
    )
    await uow.commit()

    result = await service.route_operator_reply(
        SupportGroupReply(
            operator_telegram_user_id="9001",
            support_group_message_id="1001",
            support_thread_id=None,
            text="Please restart router",
            telegram_message_id="2001",
        )
    )
    timeline = await TicketService(uow).get_ticket_timeline(ticket.id)

    assert result.routed is True
    assert api.calls[-1].chat_id == "client-chat-1"
    assert api.calls[-1].text == "Please restart router"
    assert timeline.messages[-1].sender_type == MessageSenderType.SUPPORT.value
    assert timeline.messages[-1].sender_id == operator.id


@pytest.mark.asyncio
async def test_client_reply_is_routed_to_support(session: AsyncSession) -> None:
    api = FakeTelegramSupportApi()
    service, uow = build_service(session, api)
    ticket = await create_ticket(uow)
    await service.escalate_to_support_group(ticket.id)

    result = await service.route_client_reply(
        ClientReply(
            ticket_id=ticket.id,
            client_id=ticket.client_id,
            text="Router restarted, still offline",
            telegram_message_id="3001",
        )
    )
    timeline = await TicketService(uow).get_ticket_timeline(ticket.id)

    assert result.routed is True
    assert api.calls[-1].chat_id == "support-group"
    assert api.calls[-1].reply_to_message_id == "1001"
    assert api.calls[-1].text == "Router restarted, still offline"
    assert timeline.messages[-1].sender_type == MessageSenderType.CLIENT.value


@pytest.mark.asyncio
async def test_unknown_operator_is_rejected(session: AsyncSession) -> None:
    api = FakeTelegramSupportApi()
    service, uow = build_service(session, api)
    ticket = await create_ticket(uow)
    await service.escalate_to_support_group(ticket.id)

    result = await service.route_operator_reply(
        SupportGroupReply(
            operator_telegram_user_id="unknown",
            support_group_message_id="1001",
            support_thread_id=None,
            text="hidden support answer",
            telegram_message_id="2001",
        )
    )
    timeline = await TicketService(uow).get_ticket_timeline(ticket.id)

    assert result.routed is False
    assert result.reason == "operator_not_allowed"
    assert api.calls[-1].chat_id == "support-group"
    assert api.calls[-1].text == ACCESS_DENIED_MESSAGE
    assert all(message.text != "hidden support answer" for message in timeline.messages)


@pytest.mark.asyncio
async def test_all_routed_messages_are_saved_to_ticket_messages(session: AsyncSession) -> None:
    api = FakeTelegramSupportApi()
    service, uow = build_service(session, api)
    ticket = await create_ticket(uow)
    await service.escalate_to_support_group(ticket.id)
    await uow.operators.create(
        SupportOperatorCreate(telegram_user_id="9001", display_name="Support One")
    )
    await uow.commit()

    await service.route_client_reply(
        ClientReply(ticket_id=ticket.id, client_id=ticket.client_id, text="Client details")
    )
    await service.route_operator_reply(
        SupportGroupReply(
            operator_telegram_user_id="9001",
            support_group_message_id="1001",
            support_thread_id=None,
            text="Support answer",
            telegram_message_id="2002",
        )
    )
    messages = await uow.messages.list_for_ticket(ticket.id)

    assert [message.sender_type for message in messages] == [
        MessageSenderType.BOT.value,
        MessageSenderType.CLIENT.value,
        MessageSenderType.SUPPORT.value,
    ]
