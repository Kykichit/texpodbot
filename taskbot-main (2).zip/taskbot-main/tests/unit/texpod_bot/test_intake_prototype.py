import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from texpod_bot.domain.enums import TicketEventType, TicketStatus
from texpod_bot.infrastructure.chatwoot import ChatwootApiError
from texpod_bot.infrastructure.database.models import Base
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.intake_prototype import (
    INTAKE_HISTORY_KIND,
    IntakeContext,
    IntakePrototypeService,
    issue_type_human_title,
)
from texpod_bot.services.telegram_escalation import SentTelegramMessage


class FakeNotifier:
    def __init__(self, *, fail: bool = False) -> None:
        self.fail = fail
        self.calls: list[tuple[str, str]] = []
        self.client_reply_calls: list[tuple[str, str, str, str | None]] = []

    async def notify_ticket_created(
        self,
        ticket_id: str,
        summary: str,
    ) -> SentTelegramMessage:
        self.calls.append((ticket_id, summary))
        if self.fail:
            raise RuntimeError("support group is down")
        return SentTelegramMessage(message_id="5001")

    async def notify_client_reply(
        self,
        *,
        public_id: str,
        text: str,
        reply_to_message_id: str,
        message_thread_id: str | None = None,
    ) -> SentTelegramMessage:
        self.client_reply_calls.append((public_id, text, reply_to_message_id, message_thread_id))
        if self.fail:
            raise RuntimeError("support group is down")
        return SentTelegramMessage(message_id="5002")


class FakeSupportDesk:
    def __init__(
        self,
        *,
        fail: bool = False,
        fail_customer_message: bool = False,
        create_error: Exception | None = None,
    ) -> None:
        self.fail = fail
        self.fail_customer_message = fail_customer_message
        self.create_error = create_error
        self.calls: list[dict[str, object]] = []
        self.customer_message_calls: list[dict[str, object]] = []

    async def create_ticket_thread(
        self,
        *,
        ticket_public_id: str,
        customer_name: str | None,
        customer_channel: str,
        summary: str,
        metadata: dict[str, object],
    ) -> dict[str, object]:
        self.calls.append(
            {
                "ticket_public_id": ticket_public_id,
                "customer_name": customer_name,
                "customer_channel": customer_channel,
                "summary": summary,
                "metadata": metadata,
            }
        )
        if self.create_error is not None:
            raise self.create_error
        if self.fail:
            raise RuntimeError("chatwoot unavailable")
        return {
            "external_system": "chatwoot",
            "external_contact_id": "contact-1",
            "external_conversation_id": "conversation-1",
            "external_url": "https://chatwoot.example.test/app/accounts/1/conversations/1",
            "metadata": {"summary_message_id": "message-1"},
        }

    async def send_customer_message(
        self,
        *,
        external_conversation_id: str,
        text: str,
        metadata: dict[str, object] | None = None,
    ) -> None:
        self.customer_message_calls.append(
            {
                "external_conversation_id": external_conversation_id,
                "text": text,
                "metadata": metadata or {},
            }
        )
        if self.fail_customer_message:
            raise RuntimeError("chatwoot unavailable")


@pytest.fixture
async def sessionmaker() -> async_sessionmaker[AsyncSession]:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

    maker = async_sessionmaker(engine, expire_on_commit=False)
    yield maker
    await engine.dispose()


@pytest.mark.asyncio
async def test_start_sets_awaiting_problem(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service = IntakePrototypeService(sessionmaker=sessionmaker)

    response = await service.start(_context())

    assert (
        response.text
        == "Здравствуйте! Опишите проблему одним сообщением. Я уточню детали и создам обращение."
    )
    payload = await _session_payload(sessionmaker)
    assert payload["state"] == "awaiting_problem"


@pytest.mark.asyncio
async def test_problem_text_classifies_issue_and_asks_clarification(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service = IntakePrototypeService(sessionmaker=sessionmaker)
    await service.start(_context())

    response = await service.handle_text(_context(), "Сканер не сканирует штрихкод")

    assert "Сканер совсем не реагирует" in response.text
    payload = await _session_payload(sessionmaker)
    assert payload["state"] == "asking_clarification"
    assert payload["issue_type"] == "scanner_not_working"


@pytest.mark.asyncio
async def test_clarification_answer_asks_location(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service = IntakePrototypeService(sessionmaker=sessionmaker)
    await service.start(_context())
    await service.handle_text(_context(), "Не проходит оплата картой")

    response = await service.handle_text(_context(), "Терминал пишет нет связи")

    assert response.text == "Укажите филиал или точку. Если не знаете, напишите: не знаю."
    payload = await _session_payload(sessionmaker)
    assert payload["state"] == "asking_location"
    assert payload["clarification_answer"] == "Терминал пишет нет связи"


@pytest.mark.asyncio
async def test_location_answer_creates_ticket_and_returns_public_id(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service = IntakePrototypeService(sessionmaker=sessionmaker)
    await _reach_location_question(service)

    response = await service.handle_text(_context(), "Пекарня на Ленина")

    assert response.ticket_public_id is not None
    assert response.ticket_public_id.startswith("SUP-")
    assert response.ticket_public_id in response.text
    assert "Обращение создано." in response.text
    assert "Категория: Не работает терминал" in response.text
    assert "Точка: Пекарня на Ленина" in response.text
    assert "Специалист скоро подключится." in response.text
    timeline = await _ticket_timeline(sessionmaker)
    assert timeline["ticket_count"] == 1
    assert timeline["ticket"].issue_type == "terminal_not_working"
    assert timeline["ticket"].priority == "p2"


@pytest.mark.asyncio
async def test_ticket_message_contains_summary(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service = IntakePrototypeService(sessionmaker=sessionmaker)
    await _reach_location_question(service)

    await service.handle_text(_context(), "Филиал 1")

    timeline = await _ticket_timeline(sessionmaker)
    assert len(timeline["messages"]) == 1
    assert "Новое обращение SUP-" in timeline["messages"][0].text
    assert "Категория: Не работает терминал" in timeline["messages"][0].text
    assert "Описание: Не проходит оплата картой" in timeline["messages"][0].text
    assert "Уточнение: Терминал пишет нет связи" in timeline["messages"][0].text
    assert "Точка: Филиал 1" in timeline["messages"][0].text


@pytest.mark.asyncio
async def test_support_group_notifier_called_when_configured(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    notifier = FakeNotifier()
    service = IntakePrototypeService(sessionmaker=sessionmaker, notifier=notifier)
    await _reach_location_question(service)

    await service.handle_text(_context(), "Филиал 1")

    assert len(notifier.calls) == 1
    assert "Новое обращение SUP-" in notifier.calls[0][1]
    assert "Категория: Не работает терминал" in notifier.calls[0][1]
    assert "Описание: Не проходит оплата картой" in notifier.calls[0][1]
    assert "Уточнение: Терминал пишет нет связи" in notifier.calls[0][1]
    assert "Точка: Филиал 1" in notifier.calls[0][1]
    assert "Telegram user id: 42" in notifier.calls[0][1]
    assert "Telegram chat id: 100" in notifier.calls[0][1]
    assert "Клиент: Bakery Operator" in notifier.calls[0][1]
    assert "Классификация:" in notifier.calls[0][1]
    routing = await _message_routing(sessionmaker)
    assert routing.support_group_message_id == "5001"
    assert routing.client_chat_id == "100"


@pytest.mark.asyncio
async def test_support_group_send_failure_does_not_break_ticket_creation(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    notifier = FakeNotifier(fail=True)
    service = IntakePrototypeService(sessionmaker=sessionmaker, notifier=notifier)
    await _reach_location_question(service)

    response = await service.handle_text(_context(), "Филиал 1")

    assert response.ticket_public_id is not None
    timeline = await _ticket_timeline(sessionmaker)
    assert timeline["ticket_count"] == 1
    assert any(
        event.event_type == TicketEventType.SUPPORT_GROUP_SEND_FAILED.value
        for event in timeline["events"]
    )


@pytest.mark.asyncio
async def test_support_desk_disabled_does_not_call_adapter(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    notifier = FakeNotifier()
    service = IntakePrototypeService(sessionmaker=sessionmaker, notifier=notifier)
    await _reach_location_question(service)

    await service.handle_text(_context(), "Филиал 1")

    timeline = await _ticket_timeline(sessionmaker)
    assert timeline["ticket_count"] == 1
    assert len(notifier.calls) == 1
    assert not any(
        event.event_type == TicketEventType.CHATWOOT_THREAD_CREATED.value
        for event in timeline["events"]
    )


@pytest.mark.asyncio
async def test_support_desk_thread_created_for_new_ticket(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    support_desk = FakeSupportDesk()
    notifier = FakeNotifier()
    service = IntakePrototypeService(
        sessionmaker=sessionmaker,
        notifier=notifier,
        support_desk=support_desk,
    )
    await _reach_location_question(service)

    response = await service.handle_text(_context(), "Филиал 1")

    assert response.ticket_public_id is not None
    assert notifier.calls == []
    assert len(support_desk.calls) == 1
    call = support_desk.calls[0]
    assert call["ticket_public_id"] == response.ticket_public_id
    assert call["customer_name"] == "Bakery Operator"
    assert call["customer_channel"] == "telegram"
    assert "Новое обращение SUP-" in str(call["summary"])
    assert "Описание: Не проходит оплата картой" in str(call["summary"])
    metadata = call["metadata"]
    assert isinstance(metadata, dict)
    assert metadata["telegram_user_id"] == "42"
    assert metadata["telegram_chat_id"] == "100"
    assert metadata["issue_type"] == "terminal_not_working"
    assert metadata["priority"] == "p2"
    ref = await _external_ref(sessionmaker)
    assert ref.external_system == "chatwoot"
    assert ref.external_contact_id == "contact-1"
    assert ref.external_conversation_id == "conversation-1"
    timeline = await _ticket_timeline(sessionmaker)
    assert any(
        event.event_type == TicketEventType.CHATWOOT_THREAD_CREATED.value
        for event in timeline["events"]
    )


@pytest.mark.asyncio
async def test_support_desk_failure_does_not_break_ticket_creation(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    support_desk = FakeSupportDesk(fail=True)
    service = IntakePrototypeService(sessionmaker=sessionmaker, support_desk=support_desk)
    await _reach_location_question(service)

    response = await service.handle_text(_context(), "Филиал 1")

    assert response.ticket_public_id is not None
    assert response.ticket_public_id in response.text
    timeline = await _ticket_timeline(sessionmaker)
    assert timeline["ticket_count"] == 1
    assert any(
        event.event_type == TicketEventType.CHATWOOT_THREAD_CREATE_FAILED.value
        and event.payload_json["error"] == "RuntimeError"
        and event.payload_json["ticket_public_id"] == response.ticket_public_id
        for event in timeline["events"]
    )


@pytest.mark.asyncio
async def test_support_desk_chatwoot_api_error_records_safe_payload(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    chatwoot_error = ChatwootApiError(
        status_code=422,
        method="POST",
        path="/api/v1/accounts/3/contacts",
        response_body={
            "message": "Validation failed",
            "errors": {"identifier": ["has already been taken"]},
        },
        safe_message="Chatwoot API returned HTTP 422 for POST /api/v1/accounts/3/contacts",
        operation="create_or_update_contact",
        account_id=3,
        inbox_id=1,
    )
    support_desk = FakeSupportDesk(create_error=chatwoot_error)
    service = IntakePrototypeService(sessionmaker=sessionmaker, support_desk=support_desk)
    await _reach_location_question(service)

    response = await service.handle_text(_context(), "Р¤РёР»РёР°Р» 1")

    assert response.ticket_public_id is not None
    timeline = await _ticket_timeline(sessionmaker)
    event = next(
        event
        for event in timeline["events"]
        if event.event_type == TicketEventType.CHATWOOT_THREAD_CREATE_FAILED.value
    )
    assert event.payload_json == {
        "error": "ChatwootApiError",
        "status_code": 422,
        "method": "POST",
        "path": "/api/v1/accounts/3/contacts",
        "safe_message": "Chatwoot API returned HTTP 422 for POST /api/v1/accounts/3/contacts",
        "operation": "create_or_update_contact",
        "ticket_public_id": response.ticket_public_id,
        "account_id": 3,
        "inbox_id": 1,
        "chatwoot_message": "Validation failed",
        "chatwoot_errors": {"identifier": ["has already been taken"]},
    }


@pytest.mark.asyncio
async def test_cancel_resets_session(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service = IntakePrototypeService(sessionmaker=sessionmaker)
    await service.start(_context())

    response = await service.cancel(_context())

    assert response.text == "Обращение отменено. Чтобы начать заново, нажмите /start."
    payload = await _session_payload(sessionmaker)
    assert payload["state"] == "cancelled"


@pytest.mark.asyncio
async def test_waiting_support_text_does_not_create_duplicate_ticket(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service = IntakePrototypeService(sessionmaker=sessionmaker)
    await _reach_location_question(service)
    first_response = await service.handle_text(_context(), "Филиал 1")

    response = await service.handle_text(_context(), "Добавляю: терминал перезагружали")

    assert response.should_reply is False
    assert response.ticket_public_id == first_response.ticket_public_id
    timeline = await _ticket_timeline(sessionmaker)
    assert timeline["ticket_count"] == 1
    assert len(timeline["messages"]) == 2
    assert timeline["messages"][1].text == "Добавляю: терминал перезагружали"


@pytest.mark.asyncio
async def test_waiting_support_text_is_forwarded_to_support_group(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    notifier = FakeNotifier()
    service = IntakePrototypeService(sessionmaker=sessionmaker, notifier=notifier)
    await _reach_location_question(service)
    first_response = await service.handle_text(_context(), "Филиал 1")

    await service.handle_text(_context(), "Добавляю: терминал перезагружали")

    assert notifier.client_reply_calls == [
        (
            str(first_response.ticket_public_id),
            "Добавляю: терминал перезагружали",
            "5001",
            None,
        )
    ]


@pytest.mark.asyncio
async def test_waiting_support_text_without_chatwoot_saves_message_only(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service = IntakePrototypeService(sessionmaker=sessionmaker)
    await _reach_location_question(service)
    first_response = await service.handle_text(_context(), "Филиал 1")

    response = await service.handle_text(_context(), "Добавляю: кассу перезапускали")

    assert response.should_reply is False
    assert response.ticket_public_id == first_response.ticket_public_id
    timeline = await _ticket_timeline(sessionmaker)
    assert len(timeline["messages"]) == 2
    assert timeline["messages"][1].text == "Добавляю: кассу перезапускали"
    assert not any(
        event.event_type == TicketEventType.CHATWOOT_CUSTOMER_MESSAGE_SENT.value
        for event in timeline["events"]
    )


@pytest.mark.asyncio
async def test_waiting_support_text_is_forwarded_to_chatwoot(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    support_desk = FakeSupportDesk()
    service = IntakePrototypeService(sessionmaker=sessionmaker, support_desk=support_desk)
    await _reach_location_question(service)
    first_response = await service.handle_text(_context(), "Филиал 1")

    response = await service.handle_text(_context(), "Добавляю: терминал перезагружали")

    assert response.should_reply is False
    assert response.ticket_public_id == first_response.ticket_public_id
    assert support_desk.customer_message_calls == [
        {
            "external_conversation_id": "conversation-1",
            "text": "Добавляю: терминал перезагружали",
            "metadata": {
                "ticket_id": (await _first_ticket(sessionmaker)).id,
                "ticket_public_id": str(first_response.ticket_public_id),
            },
        }
    ]
    timeline = await _ticket_timeline(sessionmaker)
    assert len(timeline["messages"]) == 2
    assert timeline["messages"][1].text == "Добавляю: терминал перезагружали"
    assert any(
        event.event_type == TicketEventType.CHATWOOT_CUSTOMER_MESSAGE_SENT.value
        and event.payload_json["external_conversation_id"] == "conversation-1"
        for event in timeline["events"]
    )


@pytest.mark.asyncio
async def test_waiting_support_text_chatwoot_failure_keeps_client_flow(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    support_desk = FakeSupportDesk(fail_customer_message=True)
    service = IntakePrototypeService(sessionmaker=sessionmaker, support_desk=support_desk)
    await _reach_location_question(service)
    first_response = await service.handle_text(_context(), "Филиал 1")

    response = await service.handle_text(_context(), "Добавляю: терминал перезагружали")

    assert response.should_reply is False
    assert response.ticket_public_id == first_response.ticket_public_id
    timeline = await _ticket_timeline(sessionmaker)
    assert len(timeline["messages"]) == 2
    assert any(
        event.event_type == TicketEventType.CHATWOOT_CUSTOMER_MESSAGE_SEND_FAILED.value
        and event.payload_json["error"] == "RuntimeError"
        for event in timeline["events"]
    )


@pytest.mark.asyncio
async def test_waiting_support_text_missing_chatwoot_ref_does_not_call_adapter(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    service_without_chatwoot = IntakePrototypeService(sessionmaker=sessionmaker)
    await _reach_location_question(service_without_chatwoot)
    first_response = await service_without_chatwoot.handle_text(_context(), "Филиал 1")
    support_desk = FakeSupportDesk()
    service_with_chatwoot = IntakePrototypeService(
        sessionmaker=sessionmaker,
        support_desk=support_desk,
    )

    response = await service_with_chatwoot.handle_text(
        _context(),
        "Добавляю: терминал перезагружали",
    )

    assert response.should_reply is False
    assert response.ticket_public_id == first_response.ticket_public_id
    assert support_desk.customer_message_calls == []
    timeline = await _ticket_timeline(sessionmaker)
    assert len(timeline["messages"]) == 2


@pytest.mark.asyncio
async def test_waiting_support_text_closed_ticket_is_rejected(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    support_desk = FakeSupportDesk()
    service = IntakePrototypeService(sessionmaker=sessionmaker, support_desk=support_desk)
    await _reach_location_question(service)
    first_response = await service.handle_text(_context(), "Филиал 1")
    ticket = await _set_first_ticket_status(sessionmaker, TicketStatus.CLOSED)

    response = await service.handle_text(_context(), "Добавляю: терминал перезагружали")

    assert response.text == (
        f"Обращение {first_response.ticket_public_id} уже закрыто. "
        "Чтобы создать новое, нажмите /start."
    )
    assert response.ticket_public_id == first_response.ticket_public_id
    assert support_desk.customer_message_calls == []
    messages = await _ticket_messages(sessionmaker, ticket.id)
    assert len(messages) == 1


def test_issue_type_human_title_maps_intake_issue_types() -> None:
    assert issue_type_human_title("scanner_not_working") == "Не работает сканер"
    assert issue_type_human_title("release_not_displayed") == "Не отображается выпуск"
    assert (
        issue_type_human_title("timesheet_shift_open_failed") == "Не могу открыть табельную смену"
    )
    assert issue_type_human_title("cash_shift_open_failed") == "Не могу открыть кассовую смену"
    assert issue_type_human_title("receipts_not_printing") == "Не выходят чеки"
    assert issue_type_human_title("terminal_not_working") == "Не работает терминал"
    assert issue_type_human_title("other") == "Другая проблема"
    assert issue_type_human_title("unknown") == "Другая проблема"


async def _reach_location_question(service: IntakePrototypeService) -> None:
    await service.start(_context())
    await service.handle_text(_context(), "Не проходит оплата картой")
    await service.handle_text(_context(), "Терминал пишет нет связи")


async def _session_payload(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> dict[str, object]:
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        support_session = await uow.sessions.get_by_telegram_chat("42", "100")
        assert support_session is not None
        for item in support_session.history_json:
            if item.get("kind") == INTAKE_HISTORY_KIND:
                return item
    raise AssertionError("intake payload was not found")


async def _ticket_timeline(
    sessionmaker: async_sessionmaker[AsyncSession],
) -> dict[str, object]:
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        tickets = await uow.tickets.list_open()
        assert tickets
        ticket = tickets[0]
        return {
            "ticket_count": len(tickets),
            "ticket": ticket,
            "messages": await uow.messages.list_for_ticket(ticket.id),
            "events": await uow.events.list_for_ticket(ticket.id),
        }


async def _first_ticket(sessionmaker: async_sessionmaker[AsyncSession]):
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        tickets = await uow.tickets.list_open()
        assert tickets
        return tickets[0]


async def _set_first_ticket_status(
    sessionmaker: async_sessionmaker[AsyncSession],
    status: TicketStatus,
):
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        tickets = await uow.tickets.list_open()
        assert tickets
        ticket = tickets[0]
        ticket.status = status.value
        await uow.commit()
        return ticket


async def _ticket_messages(sessionmaker: async_sessionmaker[AsyncSession], ticket_id: str):
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        return await uow.messages.list_for_ticket(ticket_id)


async def _message_routing(
    sessionmaker: async_sessionmaker[AsyncSession],
):
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        tickets = await uow.tickets.list_open()
        assert tickets
        routing = await uow.message_routings.get_by_ticket_id(tickets[0].id)
        assert routing is not None
        return routing


async def _external_ref(
    sessionmaker: async_sessionmaker[AsyncSession],
):
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        tickets = await uow.tickets.list_open()
        assert tickets
        ref = await uow.external_refs.get_by_ticket_and_system(tickets[0].id, "chatwoot")
        assert ref is not None
        return ref


def _context() -> IntakeContext:
    return IntakeContext(
        telegram_user_id="42",
        telegram_chat_id="100",
        display_name="Bakery Operator",
    )
