import pytest
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from texpod_bot.domain.enums import (
    IssueType,
    MessageSenderType,
    TicketEventType,
    TicketPriority,
)
from texpod_bot.domain.schemas import (
    ClientCreate,
    DeviceCreate,
    RunbookCreate,
    RunbookStepCreate,
    SupportOperatorCreate,
    TicketCreate,
    TicketEventCreate,
    TicketExternalRefCreate,
    TicketMessageCreate,
)
from texpod_bot.infrastructure.database.models import Base
from texpod_bot.infrastructure.repositories import SupportUnitOfWork


@pytest.fixture
async def session() -> AsyncSession:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

    sessionmaker = async_sessionmaker(engine, expire_on_commit=False)
    async with sessionmaker() as session:
        yield session

    await engine.dispose()


@pytest.mark.asyncio
async def test_repositories_create_ticket_with_message_and_event(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)

    client = await uow.clients.create(
        ClientCreate(
            name="Texpod Bakery",
            contact_name="Anna",
            phone="+10000000000",
            telegram_user_id="42",
        )
    )
    device = await uow.devices.create(
        DeviceCreate(
            client_id=client.id,
            device_id="kiosk-001",
            name="Front counter",
            app_version="1.2.3",
        )
    )
    operator = await uow.operators.create(
        SupportOperatorCreate(telegram_user_id="9001", display_name="Support One")
    )
    ticket = await uow.tickets.create(
        TicketCreate(
            public_id="SUP-0001",
            client_id=client.id,
            device_id=device.id,
            telegram_chat_id="100",
            issue_type=IssueType.DEVICE_OFFLINE,
            priority=TicketPriority.P2,
            assigned_to=operator.id,
        )
    )
    message = await uow.messages.create(
        TicketMessageCreate(
            ticket_id=ticket.id,
            sender_type=MessageSenderType.CLIENT,
            sender_id=client.id,
            text="Kiosk is offline",
            telegram_message_id="555",
        )
    )
    event = await uow.events.create(
        TicketEventCreate(
            ticket_id=ticket.id,
            event_type=TicketEventType.CREATED,
            payload_json={"source": "test"},
        )
    )
    await uow.commit()

    found_client = await uow.clients.get_by_telegram_user_id("42")
    found_ticket = await uow.tickets.get_by_public_id("SUP-0001")
    open_tickets = await uow.tickets.list_open_for_client(client.id)
    messages = await uow.messages.list_for_ticket(ticket.id)
    events = await uow.events.list_for_ticket(ticket.id)

    assert found_client is not None
    assert found_client.id == client.id
    assert found_ticket is not None
    assert found_ticket.id == ticket.id
    assert open_tickets == [ticket]
    assert messages == [message]
    assert events == [event]


@pytest.mark.asyncio
async def test_runbook_repository_returns_latest_active_version(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)

    old = await uow.runbooks.create(
        RunbookCreate(code="device_offline", title="Old offline runbook", active=True, version=1)
    )
    latest = await uow.runbooks.create(
        RunbookCreate(code="device_offline", title="Latest offline runbook", active=True, version=2)
    )
    await uow.runbooks.add_step(
        RunbookStepCreate(
            runbook_id=latest.id,
            step_key="check_power",
            text="Check kiosk power",
            options_json={"yes": "It is powered"},
            next_rules_json={"yes": "check_network"},
        )
    )
    await uow.commit()

    found = await uow.runbooks.get_active_by_code("device_offline")

    assert old.version == 1
    assert found is not None
    assert found.id == latest.id


@pytest.mark.asyncio
async def test_external_ref_repository_create_update_and_lookup(session: AsyncSession) -> None:
    uow = SupportUnitOfWork(session)
    client = await uow.clients.create(ClientCreate(name="Texpod Bakery", telegram_user_id="42"))
    ticket = await uow.tickets.create(
        TicketCreate(
            public_id="SUP-0002",
            client_id=client.id,
            telegram_chat_id="100",
            issue_type=IssueType.TERMINAL_NOT_WORKING,
            priority=TicketPriority.P2,
        )
    )

    created = await uow.external_refs.create_or_update_external_ref(
        TicketExternalRefCreate(
            ticket_id=ticket.id,
            external_system="chatwoot",
            external_contact_id="contact-1",
            external_conversation_id="conversation-1",
            metadata_json={"phase": "created"},
        )
    )
    updated = await uow.external_refs.create_or_update_external_ref(
        TicketExternalRefCreate(
            ticket_id=ticket.id,
            external_system="chatwoot",
            external_contact_id="contact-2",
            external_conversation_id="conversation-2",
            external_url="https://chatwoot.example.test/app/accounts/1/conversations/2",
            metadata_json={"phase": "updated"},
        )
    )
    await uow.commit()

    by_ticket = await uow.external_refs.get_by_ticket_and_system(ticket.id, "chatwoot")
    by_conversation = await uow.external_refs.get_by_external_conversation_id(
        "chatwoot",
        "conversation-2",
    )

    assert created.id == updated.id
    assert by_ticket is not None
    assert by_ticket.external_contact_id == "contact-2"
    assert by_ticket.metadata_json == {"phase": "updated"}
    assert by_conversation is not None
    assert by_conversation.id == created.id
