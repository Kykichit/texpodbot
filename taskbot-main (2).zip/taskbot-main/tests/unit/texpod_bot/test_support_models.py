from texpod_bot.domain.enums import DeviceStatus, TicketStatus
from texpod_bot.infrastructure.database.models import Base, Client, Device, Ticket


def test_support_tables_are_registered() -> None:
    assert {
        "clients",
        "devices",
        "tickets",
        "ticket_messages",
        "runbooks",
        "runbook_steps",
        "ticket_events",
        "ticket_external_refs",
        "support_operators",
    }.issubset(Base.metadata.tables)


def test_model_defaults_use_domain_constants() -> None:
    device = Device(client_id="client-id", device_id="kiosk-1")
    ticket = Ticket(public_id="SUP-1", client_id="client-id", telegram_chat_id="100")

    assert device.status is None
    assert ticket.status is None
    assert DeviceStatus.UNKNOWN.value == "unknown"
    assert TicketStatus.NEW.value == "new"


def test_client_model_accepts_optional_contact_fields() -> None:
    client = Client(name="Bakery")

    assert client.name == "Bakery"
    assert client.contact_name is None
    assert client.phone is None
