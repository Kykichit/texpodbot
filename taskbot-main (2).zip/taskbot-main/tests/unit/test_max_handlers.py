from bot.max.handlers import get_callback_id, update_to_request
from domain.models import InteractionType, Platform


def test_message_update_maps_to_domain_request() -> None:
    request = update_to_request(
        {
            "message": {
                "text": "/help",
                "sender": {"user_id": 42},
                "recipient": {"chat_id": 100},
            }
        }
    )

    assert request is not None
    assert request.platform == Platform.MAX
    assert request.interaction_type == InteractionType.COMMAND
    assert request.user_id == "42"
    assert request.chat_id == "100"


def test_callback_update_maps_to_domain_request() -> None:
    update = {
        "callback": {
            "callback_id": "callback-1",
            "payload": "help",
            "user": {"user_id": 42},
            "message": {"chat": {"chat_id": 100}},
        }
    }

    request = update_to_request(update)

    assert request is not None
    assert request.interaction_type == InteractionType.CALLBACK
    assert request.action == "help"
    assert get_callback_id(update) == "callback-1"
