from alembic.config import Config

from app.config import Settings
from app.main import build_parser, run_db_upgrade
from app.migrations import DatabaseMigrationError, run_alembic_upgrade


def test_db_upgrade_command_exists() -> None:
    args = build_parser().parse_args(["db-upgrade"])

    assert args.command == "db-upgrade"


def test_help_shows_db_upgrade(capsys) -> None:  # type: ignore[no-untyped-def]
    parser = build_parser()

    try:
        parser.parse_args(["--help"])
    except SystemExit as exc:
        assert exc.code == 0

    captured = capsys.readouterr()
    assert "db-upgrade" in captured.out


def test_alembic_upgrade_invocation_is_mockable(monkeypatch) -> None:  # type: ignore[no-untyped-def]
    calls: list[tuple[str, str | None]] = []

    def fake_upgrade(config: Config, revision: str) -> None:
        calls.append((revision, config.config_file_name))

    monkeypatch.delenv("DATABASE_URL", raising=False)

    run_alembic_upgrade(
        "postgresql+asyncpg://user:secret@localhost:5432/support",
        upgrade=fake_upgrade,
    )

    assert calls == [("head", "alembic.ini")]
    import os

    assert "DATABASE_URL" not in os.environ


def test_database_url_is_not_printed_on_failure(capsys) -> None:  # type: ignore[no-untyped-def]
    database_url = "postgresql+asyncpg://user:example@localhost:5432/support"

    def failing_upgrade(_config: Config, _revision: str) -> None:
        raise RuntimeError(database_url)

    try:
        run_alembic_upgrade(database_url, upgrade=failing_upgrade)
    except DatabaseMigrationError as exc:
        assert str(exc) == "alembic upgrade head failed"

    captured = capsys.readouterr()
    assert database_url not in captured.out
    assert database_url not in captured.err


def test_db_upgrade_failure_returns_non_zero_and_masks_url(monkeypatch, capsys) -> None:  # type: ignore[no-untyped-def]
    database_url = "postgresql+asyncpg://user:example@localhost:5432/support"

    def failing_runner(_database_url: str | None) -> None:
        raise DatabaseMigrationError("alembic upgrade head failed")

    monkeypatch.setattr("app.main.run_alembic_upgrade", failing_runner)

    exit_code = run_db_upgrade(Settings(database_url=database_url))

    captured = capsys.readouterr()
    assert exit_code == 1
    assert "Database migration failed: alembic upgrade head failed" in captured.err
    assert database_url not in captured.out
    assert database_url not in captured.err


def test_db_upgrade_success_returns_zero(monkeypatch, capsys) -> None:  # type: ignore[no-untyped-def]
    calls: list[str | None] = []

    def successful_runner(database_url: str | None) -> None:
        calls.append(database_url)

    monkeypatch.setattr("app.main.run_alembic_upgrade", successful_runner)

    exit_code = run_db_upgrade(Settings(database_url="postgresql+asyncpg://db"))

    captured = capsys.readouterr()
    assert exit_code == 0
    assert calls == ["postgresql+asyncpg://db"]
    assert "Database migrations applied successfully." in captured.out
