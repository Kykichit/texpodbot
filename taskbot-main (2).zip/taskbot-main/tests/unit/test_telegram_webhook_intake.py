from collections.abc import AsyncGenerator, AsyncIterator
from typing import Any

import pytest
from aiogram import Bot
from aiogram.client.session.base import BaseSession
from aiogram.methods import TelegramMethod
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from texpod_bot.infrastructure.database.models import Base
from texpod_bot.infrastructure.repositories import SupportUnitOfWork

from app.config import BotMode, Settings
from app.web import CHATWOOT_SECRET_HEADER, TELEGRAM_SECRET_HEADER, create_web_app
from bot.telegram.adapter import TelegramIntakeWebhookUpdateHandler


class HealthyReadiness:
    async def check(self) -> dict[str, str]:
        return {"database": "ok", "redis": "ok"}


class FakeTelegramSession(BaseSession):
    def __init__(self) -> None:
        super().__init__()
        self.requests: list[TelegramMethod[Any]] = []
        self.closed = False

    async def close(self) -> None:
        self.closed = True

    async def make_request(
        self,
        bot: Bot,
        method: TelegramMethod[Any],
        timeout: int | None = None,  # noqa: ASYNC109
    ) -> Any:
        self.requests.append(method)
        return True

    async def stream_content(
        self,
        url: str,
        headers: dict[str, Any] | None = None,
        timeout: int = 30,  # noqa: ASYNC109
        chunk_size: int = 65536,
        raise_for_status: bool = True,
    ) -> AsyncGenerator[bytes, None]:
        if False:
            yield b""


@pytest.fixture
async def sessionmaker() -> async_sessionmaker[AsyncSession]:
    engine = create_async_engine("sqlite+aiosqlite:///:memory:")
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

    maker = async_sessionmaker(engine, expire_on_commit=False)
    yield maker
    await engine.dispose()


@pytest.fixture
async def settings() -> Settings:
    return Settings(
        bot_mode=BotMode.TELEGRAM,
        database_url="postgresql+asyncpg://user:password@localhost:5432/support",
        redis_url="redis://localhost:6379/0",
        telegram_bot_token="1234567890:dummy-token",
        telegram_webhook_secret="expected-secret",
        telegram_webhook_url="https://support.example.test/telegram/webhook",
        chatwoot_webhook_secret="chatwoot-secret",
    )


async def make_client(app: web.Application) -> AsyncIterator[TestClient]:
    server = TestServer(app)
    client = TestClient(server)
    await client.start_server()
    try:
        yield client
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_telegram_webhook_start_goes_through_intake_flow(
    settings: Settings,
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    fake_session = FakeTelegramSession()
    handler = _intake_handler(sessionmaker=sessionmaker, fake_session=fake_session)

    async for client in make_client(
        create_web_app(
            settings,
            readiness_checker=HealthyReadiness(),
            telegram_update_handler=handler,
        )
    ):
        response = await client.post(
            "/telegram/webhook",
            headers={TELEGRAM_SECRET_HEADER: "expected-secret"},
            json=_telegram_message_update(update_id=1, text="/start"),
        )
        payload = await response.json()

    await handler.close()

    assert response.status == 200
    assert payload == {"ok": True}
    assert fake_session.closed is True
    assert _sent_texts(fake_session)
    assert "Опишите проблему одним сообщением" in _sent_texts(fake_session)[0]


@pytest.mark.asyncio
async def test_telegram_webhook_text_flow_creates_ticket(
    settings: Settings,
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    fake_session = FakeTelegramSession()
    handler = _intake_handler(sessionmaker=sessionmaker, fake_session=fake_session)

    async for client in make_client(
        create_web_app(
            settings,
            readiness_checker=HealthyReadiness(),
            telegram_update_handler=handler,
        )
    ):
        for update_id, text in enumerate(
            [
                "/start",
                "Не работает сканер",
                "Пробовали перезагрузить, не помогло",
                "Пекарня на Центральной",
            ],
            start=1,
        ):
            response = await client.post(
                "/telegram/webhook",
                headers={TELEGRAM_SECRET_HEADER: "expected-secret"},
                json=_telegram_message_update(update_id=update_id, text=text),
            )
            assert response.status == 200

        before_follow_up = len(_sent_texts(fake_session))
        response = await client.post(
            "/telegram/webhook",
            headers={TELEGRAM_SECRET_HEADER: "expected-secret"},
            json=_telegram_message_update(
                update_id=99,
                text="Добавляю: терминал перезагружали",
            ),
        )
        assert response.status == 200
        assert len(_sent_texts(fake_session)) == before_follow_up

    await handler.close()

    texts = _sent_texts(fake_session)
    assert any("SUP-" in text for text in texts)
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        tickets = await uow.tickets.list_open()
        assert len(tickets) == 1
        assert tickets[0].public_id.startswith("SUP-")
        messages = await uow.messages.list_for_ticket(tickets[0].id)
        assert any(message.text and "Не работает сканер" in message.text for message in messages)


@pytest.mark.asyncio
async def test_telegram_webhook_invalid_secret_rejected_before_intake(
    settings: Settings,
    sessionmaker: async_sessionmaker[AsyncSession],
) -> None:
    fake_session = FakeTelegramSession()
    handler = _intake_handler(sessionmaker=sessionmaker, fake_session=fake_session)

    async for client in make_client(
        create_web_app(
            settings,
            readiness_checker=HealthyReadiness(),
            telegram_update_handler=handler,
        )
    ):
        response = await client.post(
            "/telegram/webhook",
            headers={TELEGRAM_SECRET_HEADER: "wrong-secret"},
            json=_telegram_message_update(update_id=1, text="/start"),
        )

    await handler.close()

    assert response.status == 403
    assert fake_session.requests == []


@pytest.mark.asyncio
async def test_chatwoot_webhook_still_uses_chatwoot_handler(settings: Settings) -> None:
    seen_payloads: list[dict[str, object]] = []

    async def chatwoot_handler(payload: dict[str, object]) -> dict[str, object]:
        seen_payloads.append(payload)
        return {"ok": True, "status": "ignored", "reason": "unsupported_event"}

    async for client in make_client(
        create_web_app(
            settings,
            readiness_checker=HealthyReadiness(),
            chatwoot_webhook_handler=chatwoot_handler,
        )
    ):
        response = await client.post(
            "/chatwoot/webhook",
            headers={CHATWOOT_SECRET_HEADER: "chatwoot-secret"},
            json={"event": "conversation_updated", "status": "open"},
        )
        payload = await response.json()

    assert response.status == 200
    assert payload == {"ok": True, "status": "ignored", "reason": "unsupported_event"}
    assert seen_payloads == [{"event": "conversation_updated", "status": "open"}]


def _intake_handler(
    *,
    sessionmaker: async_sessionmaker[AsyncSession],
    fake_session: FakeTelegramSession,
) -> TelegramIntakeWebhookUpdateHandler:
    bot = Bot(token="1234567890:test-token", session=fake_session)
    return TelegramIntakeWebhookUpdateHandler(
        token="1234567890:test-token",
        sessionmaker=sessionmaker,
        support_group_id=None,
        bot=bot,
    )


def _sent_texts(fake_session: FakeTelegramSession) -> list[str]:
    return [
        str(method.text)  # type: ignore[attr-defined]
        for method in fake_session.requests
        if method.__class__.__name__ == "SendMessage"
    ]


def _telegram_message_update(*, update_id: int, text: str) -> dict[str, object]:
    return {
        "update_id": update_id,
        "message": {
            "message_id": update_id,
            "date": 1_700_000_000,
            "chat": {
                "id": 100,
                "type": "private",
                "first_name": "Test",
            },
            "from": {
                "id": 42,
                "is_bot": False,
                "first_name": "Test",
                "username": "test_user",
            },
            "text": text,
        },
    }
