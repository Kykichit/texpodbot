from aiogram import Bot
from aiogram.client.session.aiohttp import AiohttpSession

from bot.telegram.bot_factory import create_telegram_bot


async def test_create_telegram_bot_without_proxy_creates_bot() -> None:
    bot = create_telegram_bot(token="1234567890:test-token")

    try:
        assert isinstance(bot, Bot)
    finally:
        await bot.session.close()


async def test_create_telegram_bot_with_proxy_uses_aiohttp_session_proxy() -> None:
    bot = create_telegram_bot(
        token="1234567890:test-token",
        proxy_url="http://127.0.0.1:10809",
    )

    try:
        assert isinstance(bot.session, AiohttpSession)
        assert bot.session.proxy == "http://127.0.0.1:10809"
    finally:
        await bot.session.close()
