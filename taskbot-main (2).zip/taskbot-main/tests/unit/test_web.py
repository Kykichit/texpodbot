import hashlib
import hmac
from collections.abc import AsyncIterator
from types import SimpleNamespace

import pytest
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

from app.config import AppEnv, BotMode, Settings
from app.web import (
    CHATWOOT_SECRET_HEADER,
    CHATWOOT_SIGNATURE_HEADER,
    CHATWOOT_TIMESTAMP_HEADER,
    TELEGRAM_SECRET_HEADER,
    _allow_unsigned_local_chatwoot_webhooks,
    _looks_like_local_host,
    create_web_app,
)


class HealthyReadiness:
    async def check(self) -> dict[str, str]:
        return {"database": "ok", "redis": "ok"}


class FailingReadiness:
    async def check(self) -> dict[str, str]:
        from app.readiness import DependencyUnavailableError

        raise DependencyUnavailableError("dependency unavailable")


@pytest.fixture
async def settings() -> Settings:
    return Settings(
        bot_mode=BotMode.TELEGRAM,
        database_url="postgresql+asyncpg://user:password@localhost:5432/support",
        redis_url="redis://localhost:6379/0",
        telegram_bot_token="1234567890:dummy-token",
        telegram_webhook_secret="expected-secret",
        telegram_webhook_url="https://support.example.test/telegram/webhook",
        telegram_support_group_id="-1001234567890",
        chatwoot_webhook_secret="chatwoot-secret",
    )


async def make_client(app: web.Application) -> AsyncIterator[TestClient]:
    server = TestServer(app)
    client = TestClient(server)
    await client.start_server()
    try:
        yield client
    finally:
        await client.close()


@pytest.mark.asyncio
async def test_webhook_rejects_missing_secret(settings: Settings) -> None:
    async for client in make_client(create_web_app(settings, readiness_checker=HealthyReadiness())):
        response = await client.post("/telegram/webhook", json={"update_id": 1})

    assert response.status == 401


@pytest.mark.asyncio
async def test_webhook_rejects_invalid_secret(settings: Settings) -> None:
    async for client in make_client(create_web_app(settings, readiness_checker=HealthyReadiness())):
        response = await client.post(
            "/telegram/webhook",
            headers={TELEGRAM_SECRET_HEADER: "wrong-secret"},
            json={"update_id": 1},
        )

    assert response.status == 403


@pytest.mark.asyncio
async def test_webhook_accepts_valid_secret(settings: Settings) -> None:
    seen_updates: list[dict[str, object]] = []

    async def handler(update: dict[str, object]) -> None:
        seen_updates.append(update)

    async for client in make_client(
        create_web_app(
            settings,
            readiness_checker=HealthyReadiness(),
            telegram_update_handler=handler,
        )
    ):
        response = await client.post(
            "/telegram/webhook",
            headers={TELEGRAM_SECRET_HEADER: "expected-secret"},
            json={"update_id": 1},
        )
        payload = await response.json()

    assert response.status == 200
    assert payload == {"ok": True}
    assert seen_updates == [{"update_id": 1}]


@pytest.mark.asyncio
async def test_health_returns_ok(settings: Settings) -> None:
    async for client in make_client(create_web_app(settings, readiness_checker=HealthyReadiness())):
        response = await client.get("/health")
        payload = await response.json()

    assert response.status == 200
    assert payload == {"status": "ok"}


@pytest.mark.asyncio
async def test_ready_fails_when_dependencies_unavailable(settings: Settings) -> None:
    async for client in make_client(create_web_app(settings, readiness_checker=FailingReadiness())):
        response = await client.get("/ready")
        payload = await response.json()

    assert response.status == 503
    assert payload == {"status": "unavailable"}


@pytest.mark.asyncio
async def test_metrics_endpoint_exposes_prometheus_metrics(settings: Settings) -> None:
    settings.app_version = "1.2.3"
    settings.app_commit = "abc123"

    async for client in make_client(create_web_app(settings, readiness_checker=HealthyReadiness())):
        await client.get("/health")
        response = await client.get("/metrics")
        text = await response.text()

    assert response.status == 200
    assert response.content_type == "text/plain"
    assert "taskbot_http_requests_total" in text
    assert 'route="/health",method="GET",status="200"' in text
    assert "taskbot_http_request_duration_seconds_bucket" in text
    assert 'taskbot_build_info{version="1.2.3",commit="abc123"} 1' in text


@pytest.mark.asyncio
async def test_metrics_records_webhook_and_readiness_failures(settings: Settings) -> None:
    async for client in make_client(create_web_app(settings, readiness_checker=FailingReadiness())):
        await client.post(
            "/telegram/webhook",
            headers={TELEGRAM_SECRET_HEADER: "expected-secret"},
            json={"update_id": 1},
        )
        await client.post("/chatwoot/webhook", json={"event": "message_created"})
        await client.get("/ready")
        response = await client.get("/metrics")
        text = await response.text()

    assert response.status == 200
    assert 'taskbot_webhook_updates_total{channel="telegram",result="success"} 1' in text
    assert 'taskbot_webhook_updates_total{channel="chatwoot",result="error"} 1' in text
    assert 'taskbot_readiness_failures_total{dependency="unknown"} 1' in text
    assert 'taskbot_webhook_latency_seconds_count{channel="telegram"} 1' in text


@pytest.mark.asyncio
async def test_chatwoot_webhook_rejects_missing_secret(settings: Settings) -> None:
    async for client in make_client(create_web_app(settings, readiness_checker=HealthyReadiness())):
        response = await client.post("/chatwoot/webhook", json={"event": "message_created"})

    assert response.status == 401


@pytest.mark.asyncio
async def test_chatwoot_webhook_rejects_invalid_secret(settings: Settings) -> None:
    async for client in make_client(create_web_app(settings, readiness_checker=HealthyReadiness())):
        response = await client.post(
            "/chatwoot/webhook",
            headers={CHATWOOT_SECRET_HEADER: "wrong-secret"},
            json={"event": "message_created"},
        )

    assert response.status == 403


@pytest.mark.asyncio
async def test_chatwoot_webhook_accepts_valid_signature_without_custom_secret(
    settings: Settings,
) -> None:
    seen_payloads: list[dict[str, object]] = []

    async def handler(payload: dict[str, object]) -> dict[str, object]:
        seen_payloads.append(payload)
        return {"ok": True, "status": "ignored", "reason": "unsupported_event"}

    payload = {"event": "message_created", "conversation_id": "conversation-1"}
    raw_body = b'{"event":"message_created","conversation_id":"conversation-1"}'
    timestamp = "1710000000"
    signature = _chatwoot_signature(
        secret=settings.chatwoot_webhook_secret or "",
        timestamp=timestamp,
        raw_body=raw_body,
    )

    async for client in make_client(
        create_web_app(
            settings,
            readiness_checker=HealthyReadiness(),
            chatwoot_webhook_handler=handler,
        )
    ):
        response = await client.post(
            "/chatwoot/webhook",
            headers={
                "Content-Type": "application/json",
                CHATWOOT_SIGNATURE_HEADER: signature,
                CHATWOOT_TIMESTAMP_HEADER: timestamp,
            },
            data=raw_body,
        )
        result = await response.json()

    assert response.status == 200
    assert result == {"ok": True, "status": "ignored", "reason": "unsupported_event"}
    assert seen_payloads == [payload]


@pytest.mark.asyncio
async def test_chatwoot_webhook_allows_unsigned_local_demo_when_enabled(
    settings: Settings,
) -> None:
    settings.app_env = AppEnv.DEMO
    settings.chatwoot_allow_unsigned_local_webhooks = True
    seen_payloads: list[dict[str, object]] = []

    async def handler(payload: dict[str, object]) -> dict[str, object]:
        seen_payloads.append(payload)
        return {"ok": True, "status": "ignored", "reason": "unsupported_event"}

    async for client in make_client(
        create_web_app(
            settings,
            readiness_checker=HealthyReadiness(),
            chatwoot_webhook_handler=handler,
        )
    ):
        response = await client.post(
            "/chatwoot/webhook",
            headers={"Host": "127.0.0.1:18080"},
            json={"event": "message_created", "conversation_id": "conversation-1"},
        )
        result = await response.json()

    assert response.status == 200
    assert result == {"ok": True, "status": "ignored", "reason": "unsupported_event"}
    assert seen_payloads == [{"event": "message_created", "conversation_id": "conversation-1"}]


@pytest.mark.parametrize(
    ("remote", "host"),
    [("172.18.0.1", "172.18.0.1:18080"), ("127.0.0.1", "127.0.0.1:18080")],
)
def test_looks_like_local_host_accepts_allowed_private_ranges(remote: str, host: str) -> None:
    assert _looks_like_local_host(remote) is True
    assert _looks_like_local_host(host) is True


@pytest.mark.parametrize(
    "value",
    ["localhost", "LOCALHOST", "10.0.0.4", "192.168.1.10", "::1"],
)
def test_looks_like_local_host_accepts_local_and_private_values(value: str) -> None:
    assert _looks_like_local_host(value) is True


@pytest.mark.parametrize(
    "value",
    ["172.15.255.255", "172.32.0.1", "8.8.8.8", "example.test"],
)
def test_looks_like_local_host_rejects_non_local_values(value: str) -> None:
    assert _looks_like_local_host(value) is False


def test_unsigned_local_guard_accepts_private_range_in_demo_with_flag() -> None:
    settings = _chatwoot_settings(app_env=AppEnv.DEMO, allow_unsigned=True)
    request = _make_request(remote="172.18.0.1", host="support.example.test")

    assert _allow_unsigned_local_chatwoot_webhooks(settings, request) is True


def test_unsigned_local_guard_accepts_loopback_in_demo_with_flag() -> None:
    settings = _chatwoot_settings(app_env=AppEnv.DEMO, allow_unsigned=True)
    request = _make_request(remote="127.0.0.1", host="support.example.test")

    assert _allow_unsigned_local_chatwoot_webhooks(settings, request) is True


def test_unsigned_local_guard_rejects_private_range_without_flag() -> None:
    settings = _chatwoot_settings(app_env=AppEnv.DEMO, allow_unsigned=False)
    request = _make_request(remote="172.18.0.1", host="support.example.test")

    assert _allow_unsigned_local_chatwoot_webhooks(settings, request) is False


def test_unsigned_local_guard_rejects_private_range_in_staging() -> None:
    settings = _chatwoot_settings(app_env=AppEnv.STAGING, allow_unsigned=True)
    request = _make_request(remote="172.18.0.1", host="support.example.test")

    assert _allow_unsigned_local_chatwoot_webhooks(settings, request) is False


def test_unsigned_local_guard_rejects_private_range_in_production() -> None:
    settings = _chatwoot_settings(app_env=AppEnv.PRODUCTION, allow_unsigned=True)
    request = _make_request(remote="172.18.0.1", host="support.example.test")

    assert _allow_unsigned_local_chatwoot_webhooks(settings, request) is False


@pytest.mark.asyncio
async def test_chatwoot_webhook_rejects_unsigned_demo_when_disabled() -> None:
    settings = _chatwoot_settings(app_env=AppEnv.DEMO, allow_unsigned=False)
    async for client in make_client(create_web_app(settings, readiness_checker=HealthyReadiness())):
        response = await client.post(
            "/chatwoot/webhook",
            headers={"Host": "172.18.0.1:18080"},
            json={"event": "message_created"},
        )

    assert response.status == 401


@pytest.mark.asyncio
async def test_chatwoot_webhook_rejects_unsigned_production_even_when_enabled() -> None:
    settings = _chatwoot_settings(app_env=AppEnv.PRODUCTION, allow_unsigned=True)
    async for client in make_client(create_web_app(settings, readiness_checker=HealthyReadiness())):
        response = await client.post(
            "/chatwoot/webhook",
            headers={"Host": "172.18.0.1:18080"},
            json={"event": "message_created"},
        )

    assert response.status == 401


@pytest.mark.asyncio
async def test_chatwoot_webhook_rejects_unsigned_staging_even_when_enabled() -> None:
    settings = _chatwoot_settings(app_env=AppEnv.STAGING, allow_unsigned=True)
    async for client in make_client(create_web_app(settings, readiness_checker=HealthyReadiness())):
        response = await client.post(
            "/chatwoot/webhook",
            headers={"Host": "172.18.0.1:18080"},
            json={"event": "message_created"},
        )

    assert response.status == 401


@pytest.mark.asyncio
async def test_chatwoot_webhook_disabled_without_configured_secret(settings: Settings) -> None:
    settings.chatwoot_webhook_secret = None
    async for client in make_client(create_web_app(settings, readiness_checker=HealthyReadiness())):
        response = await client.post(
            "/chatwoot/webhook",
            headers={CHATWOOT_SECRET_HEADER: "chatwoot-secret"},
            json={"event": "message_created"},
        )
        payload = await response.json()

    assert response.status == 503
    assert payload == {"ok": False, "error": "webhook_not_configured"}


@pytest.mark.asyncio
async def test_chatwoot_webhook_missing_secret_in_production_returns_401() -> None:
    settings = _chatwoot_settings(app_env=AppEnv.PRODUCTION, allow_unsigned=False)
    async for client in make_client(create_web_app(settings, readiness_checker=HealthyReadiness())):
        response = await client.post(
            "/chatwoot/webhook",
            headers={"Host": "172.18.0.1:18080"},
            json={"event": "message_created"},
        )
        payload = await response.json()

    assert response.status == 401
    assert payload == {"ok": False, "error": "missing_secret"}


@pytest.mark.asyncio
async def test_chatwoot_webhook_invalid_secret_response_does_not_echo_secret(
    settings: Settings,
) -> None:
    async for client in make_client(create_web_app(settings, readiness_checker=HealthyReadiness())):
        response = await client.post(
            "/chatwoot/webhook",
            headers={CHATWOOT_SECRET_HEADER: "wrong-secret"},
            json={"event": "message_created"},
        )
        text = await response.text()

    assert "wrong-secret" not in text
    assert "chatwoot-secret" not in text


@pytest.mark.asyncio
async def test_chatwoot_webhook_accepts_valid_secret(settings: Settings) -> None:
    seen_payloads: list[dict[str, object]] = []

    async def handler(payload: dict[str, object]) -> dict[str, object]:
        seen_payloads.append(payload)
        return {"ok": True, "status": "ignored", "reason": "unsupported_event"}

    async for client in make_client(
        create_web_app(
            settings,
            readiness_checker=HealthyReadiness(),
            chatwoot_webhook_handler=handler,
        )
    ):
        response = await client.post(
            "/chatwoot/webhook",
            headers={CHATWOOT_SECRET_HEADER: "chatwoot-secret"},
            json={"event": "conversation_status_changed"},
        )
        payload = await response.json()

    assert response.status == 200
    assert payload == {"ok": True, "status": "ignored", "reason": "unsupported_event"}
    assert seen_payloads == [{"event": "conversation_status_changed"}]


@pytest.mark.asyncio
async def test_chatwoot_webhook_accepts_close_event_with_clean_json(settings: Settings) -> None:
    async def handler(_payload: dict[str, object]) -> dict[str, object]:
        return {"ok": True, "status": "closed", "ticket_id": "ticket-1"}

    async for client in make_client(
        create_web_app(
            settings,
            readiness_checker=HealthyReadiness(),
            chatwoot_webhook_handler=handler,
        )
    ):
        response = await client.post(
            "/chatwoot/webhook",
            headers={CHATWOOT_SECRET_HEADER: "chatwoot-secret"},
            json={
                "event": "conversation_status_changed",
                "conversation": {"id": "conversation-1", "status": "resolved"},
            },
        )
        payload = await response.json()
        text = await response.text()

    assert response.status == 200
    assert payload == {"ok": True, "status": "closed", "ticket_id": "ticket-1"}
    assert "chatwoot-secret" not in text


@pytest.mark.asyncio
async def test_chatwoot_webhook_close_notify_failed_still_returns_ok(
    settings: Settings,
) -> None:
    async def handler(_payload: dict[str, object]) -> dict[str, object]:
        return {
            "ok": True,
            "status": "close_notify_failed",
            "reason": "customer_close_notify_failed",
        }

    async for client in make_client(
        create_web_app(
            settings,
            readiness_checker=HealthyReadiness(),
            chatwoot_webhook_handler=handler,
        )
    ):
        response = await client.post(
            "/chatwoot/webhook",
            headers={CHATWOOT_SECRET_HEADER: "chatwoot-secret"},
            json={
                "event": "conversation_status_changed",
                "conversation": {"id": "conversation-1", "status": "resolved"},
            },
        )
        payload = await response.json()

    assert response.status == 200
    assert payload == {
        "ok": True,
        "status": "close_notify_failed",
        "reason": "customer_close_notify_failed",
    }


@pytest.mark.asyncio
async def test_chatwoot_webhook_send_failed_returns_bad_gateway(settings: Settings) -> None:
    async def handler(_payload: dict[str, object]) -> dict[str, object]:
        return {"ok": False, "status": "send_failed", "reason": "customer_send_failed"}

    async for client in make_client(
        create_web_app(
            settings,
            readiness_checker=HealthyReadiness(),
            chatwoot_webhook_handler=handler,
        )
    ):
        response = await client.post(
            "/chatwoot/webhook",
            headers={CHATWOOT_SECRET_HEADER: "chatwoot-secret"},
            json={"event": "message_created"},
        )

    assert response.status == 502


def _chatwoot_signature(*, secret: str, timestamp: str, raw_body: bytes) -> str:
    message = b".".join([timestamp.encode("utf-8"), raw_body])
    digest = hmac.new(secret.encode("utf-8"), message, hashlib.sha256).hexdigest()
    return f"sha256={digest}"


def _chatwoot_settings(*, app_env: AppEnv, allow_unsigned: bool) -> Settings:
    return Settings(
        app_env=app_env,
        bot_mode=BotMode.TELEGRAM,
        database_url="postgresql+asyncpg://user:password@localhost:5432/support",
        redis_url="redis://localhost:6379/0",
        telegram_bot_token="1234567890:dummy-token",
        telegram_webhook_secret="expected-secret",
        telegram_webhook_url="https://support.example.test/telegram/webhook",
        telegram_support_group_id="-1001234567890",
        chatwoot_webhook_secret="chatwoot-secret",
        chatwoot_allow_unsigned_local_webhooks=allow_unsigned,
    )


def _make_request(
    *,
    remote: str | None = None,
    host: str | None = None,
    headers: dict[str, str] | None = None,
) -> SimpleNamespace:
    return SimpleNamespace(remote=remote, host=host, headers=headers or {})
