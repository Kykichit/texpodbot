from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, cast
from urllib.parse import urlsplit

import httpx

from texpod_bot.services.support_desk import (
    SupportDeskContact,
    SupportDeskConversation,
    SupportDeskMessage,
    SupportDeskTicketThread,
)

CHATWOOT_EXTERNAL_SYSTEM = "chatwoot"
_REDACTED = "<redacted>"
_SENSITIVE_KEYS = ("token", "secret", "password", "authorization", "api_access_token")
_CHATWOOT_ERROR_KEYS = ("error", "errors", "message", "full_messages")
type RequestParams = Mapping[str, str | int | float | bool | None]


@dataclass(frozen=True, slots=True)
class ChatwootApiError(RuntimeError):
    status_code: int
    method: str
    path: str
    response_body: dict[str, Any] | str | None
    safe_message: str
    operation: str | None = None
    account_id: int | None = None
    inbox_id: int | None = None

    def __str__(self) -> str:
        return self.safe_message

    def event_payload(self, *, ticket_public_id: str | None = None) -> dict[str, object]:
        payload: dict[str, object] = {
            "error": self.__class__.__name__,
            "status_code": self.status_code,
            "method": self.method,
            "path": self.path,
            "safe_message": self.safe_message,
        }
        if self.operation:
            payload["operation"] = self.operation
        if ticket_public_id:
            payload["ticket_public_id"] = ticket_public_id
        if self.account_id is not None:
            payload["account_id"] = self.account_id
        if self.inbox_id is not None:
            payload["inbox_id"] = self.inbox_id

        if isinstance(self.response_body, dict):
            for key in _CHATWOOT_ERROR_KEYS:
                value = self.response_body.get(key)
                if value is not None:
                    payload[f"chatwoot_{key}"] = value
        elif isinstance(self.response_body, str) and self.response_body:
            payload["chatwoot_error"] = self.response_body
        return payload


@dataclass(frozen=True, slots=True)
class ChatwootSettings:
    base_url: str | None = None
    api_token: str | None = None
    account_id: int | None = None
    inbox_id: int | None = None
    webhook_secret: str | None = None

    @property
    def enabled(self) -> bool:
        return bool(
            self.base_url
            and self.api_token
            and self.account_id is not None
            and self.inbox_id is not None
        )


class ChatwootClient:
    def __init__(
        self,
        *,
        settings: ChatwootSettings,
        timeout_seconds: float = 10,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        if not settings.enabled:
            msg = "Chatwoot client requires base_url, api_token, account_id, and inbox_id"
            raise ValueError(msg)
        if settings.base_url is None or settings.api_token is None:
            msg = "Chatwoot settings are incomplete"
            raise ValueError(msg)
        self._base_url = settings.base_url.rstrip("/")
        self._api_token = settings.api_token
        self._account_id = settings.account_id
        self._inbox_id = settings.inbox_id
        self._timeout_seconds = timeout_seconds
        self._client = client

    async def upsert_contact(self, contact: SupportDeskContact) -> SupportDeskContact:
        payload = {
            "inbox_id": self._inbox_id,
            "name": contact.name,
            "identifier": contact.external_id,
            "custom_attributes": contact.custom_attributes,
        }
        if contact.phone:
            payload["phone_number"] = contact.phone
        if contact.email:
            payload["email"] = contact.email

        try:
            response_payload = await self._request(
                "POST",
                f"/api/v1/accounts/{self._account_id}/contacts",
                json=payload,
                operation="create_or_update_contact",
            )
        except ChatwootApiError as exc:
            if exc.status_code != 422 or not _looks_like_duplicate_contact(exc.response_body):
                raise
            response_payload = await self._find_contact_by_identifier(contact.external_id)
        contact_payload = _extract_contact_payload(response_payload)
        contact_id = _required_str_or_int(contact_payload, "id")
        source_id = _extract_contact_source_id(contact_payload, inbox_id=self._inbox_id)
        if source_id is None:
            msg = (
                "Chatwoot contact exists but no contact_inbox source_id was returned "
                f"for inbox_id={self._inbox_id}"
            )
            raise RuntimeError(msg)
        return SupportDeskContact(
            id=contact_id,
            external_id=contact.external_id,
            name=contact.name,
            source_id=source_id,
            phone=contact.phone,
            email=contact.email,
            custom_attributes=contact.custom_attributes,
        )

    async def create_conversation(
        self,
        *,
        contact_id: str,
        source_id: str,
        custom_attributes: dict[str, object] | None = None,
    ) -> SupportDeskConversation:
        response_payload = await self._request(
            "POST",
            f"/api/v1/accounts/{self._account_id}/conversations",
            json={
                "source_id": source_id,
                "inbox_id": self._inbox_id,
                "contact_id": contact_id,
                "custom_attributes": custom_attributes or {},
            },
            operation="create_conversation",
        )
        conversation_id = _required_str_or_int(response_payload, "id")
        return SupportDeskConversation(id=conversation_id, contact_id=contact_id)

    async def send_customer_message(
        self,
        *,
        conversation_id: str,
        content: str,
        source_id: str | None = None,
    ) -> SupportDeskMessage:
        payload = {
            "content": content,
            "message_type": "incoming",
            "private": False,
        }
        if source_id:
            payload["source_id"] = source_id

        response_payload = await self._request(
            "POST",
            f"/api/v1/accounts/{self._account_id}/conversations/{conversation_id}/messages",
            json=payload,
            operation="send_customer_message",
        )
        message_id = _required_str_or_int(response_payload, "id")
        return SupportDeskMessage(id=message_id, conversation_id=conversation_id)

    async def _find_contact_by_identifier(self, identifier: str) -> dict[str, Any]:
        return await self._request(
            "GET",
            f"/api/v1/accounts/{self._account_id}/contacts/search",
            params={"q": identifier},
            operation="find_contact_by_identifier",
        )

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: Mapping[str, object] | None = None,
        params: RequestParams | None = None,
        operation: str | None = None,
    ) -> dict[str, Any]:
        if self._client is not None:
            response = await self._client.request(
                method,
                f"{self._base_url}{path}",
                headers=self._headers(),
                json=json,
                params=params,
            )
            self._raise_for_status(response, method=method, operation=operation)
            payload = response.json()
            if not isinstance(payload, dict):
                msg = "Chatwoot response must be a JSON object"
                raise RuntimeError(msg)
            return payload

        async with httpx.AsyncClient(timeout=self._timeout_seconds) as client:
            response = await client.request(
                method,
                f"{self._base_url}{path}",
                headers=self._headers(),
                json=json,
                params=params,
            )
            self._raise_for_status(response, method=method, operation=operation)
            payload = response.json()
        if not isinstance(payload, dict):
            msg = "Chatwoot response must be a JSON object"
            raise RuntimeError(msg)
        return payload

    def _raise_for_status(
        self,
        response: httpx.Response,
        *,
        method: str,
        operation: str | None,
    ) -> None:
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            body = _safe_response_body(response)
            path = _safe_path(response.request.url)
            safe_message = f"Chatwoot API returned HTTP {response.status_code} for {method} {path}"
            raise ChatwootApiError(
                status_code=response.status_code,
                method=method,
                path=path,
                response_body=body,
                safe_message=safe_message,
                operation=operation,
                account_id=self._account_id,
                inbox_id=self._inbox_id,
            ) from exc

    def _headers(self) -> dict[str, str]:
        return {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "api_access_token": self._api_token,
        }


class ChatwootSupportDeskAdapter:
    def __init__(
        self,
        client: ChatwootClient,
        *,
        base_url: str | None = None,
        account_id: int | None = None,
    ) -> None:
        self._client = client
        self._base_url = base_url.rstrip("/") if base_url else None
        self._account_id = account_id

    async def create_ticket_thread(
        self,
        *,
        ticket_public_id: str,
        customer_name: str | None,
        customer_channel: str,
        summary: str,
        metadata: dict[str, object],
    ) -> dict[str, object]:
        telegram_user_id = _optional_str(metadata.get("telegram_user_id"))
        contact = await self._client.upsert_contact(
            SupportDeskContact(
                id="",
                external_id=_contact_identifier(customer_channel, telegram_user_id),
                name=customer_name or _fallback_customer_name(customer_channel, telegram_user_id),
                custom_attributes={
                    "customer_channel": customer_channel,
                    "telegram_user_id": telegram_user_id,
                    "telegram_chat_id": _optional_str(metadata.get("telegram_chat_id")),
                    "ticket_public_id": ticket_public_id,
                    "location": _optional_str(metadata.get("location")),
                },
            )
        )
        conversation = await self._client.create_conversation(
            contact_id=contact.id,
            source_id=contact.source_id or f"ticket:{ticket_public_id}",
            custom_attributes={
                "ticket_public_id": ticket_public_id,
                "issue_type": _optional_str(metadata.get("issue_type")),
                "priority": _optional_str(metadata.get("priority")),
                "location": _optional_str(metadata.get("location")),
                "customer_channel": customer_channel,
            },
        )
        message = await self._client.send_customer_message(
            conversation_id=conversation.id,
            content=summary,
            source_id=f"ticket:{ticket_public_id}:summary",
        )
        thread = SupportDeskTicketThread(
            external_system=CHATWOOT_EXTERNAL_SYSTEM,
            external_contact_id=contact.id,
            external_conversation_id=conversation.id,
            external_url=_conversation_url(self._base_url, self._account_id, conversation.id),
            metadata={
                **metadata,
                "contact_source_id": contact.source_id,
                "summary_message_id": message.id,
            },
        )
        return thread.as_external_ref_payload()

    async def send_customer_message(
        self,
        *,
        external_conversation_id: str,
        text: str,
        metadata: dict[str, object] | None = None,
    ) -> None:
        source_id = _optional_str((metadata or {}).get("source_id"))
        await self._client.send_customer_message(
            conversation_id=external_conversation_id,
            content=text,
            source_id=source_id,
        )


def _contact_identifier(customer_channel: str, telegram_user_id: str | None) -> str:
    if customer_channel == "telegram" and telegram_user_id:
        return f"telegram:{telegram_user_id}"
    return f"{customer_channel}:unknown"


def _fallback_customer_name(customer_channel: str, telegram_user_id: str | None) -> str:
    if customer_channel == "telegram" and telegram_user_id:
        return f"Telegram user {telegram_user_id}"
    return f"{customer_channel.title()} customer"


def _conversation_url(
    base_url: str | None,
    account_id: int | None,
    conversation_id: str,
) -> str | None:
    if base_url is None or account_id is None:
        return None
    return f"{base_url}/app/accounts/{account_id}/conversations/{conversation_id}"


def _optional_str(value: object) -> str | None:
    return value if isinstance(value, str) and value else None


def _extract_contact_payload(payload: dict[str, Any]) -> dict[str, Any]:
    nested = payload.get("payload")
    if isinstance(nested, list) and nested and isinstance(nested[0], dict):
        return nested[0]
    if isinstance(nested, dict):
        return nested
    return payload


def _extract_contact_source_id(payload: dict[str, Any], *, inbox_id: int | None) -> str | None:
    source_id = payload.get("source_id")
    if isinstance(source_id, str):
        return source_id
    contact_inboxes = payload.get("contact_inboxes")
    if not isinstance(contact_inboxes, list):
        return None
    for contact_inbox in contact_inboxes:
        if not isinstance(contact_inbox, dict):
            continue
        inbox = contact_inbox.get("inbox")
        if not isinstance(inbox, dict) or inbox.get("id") != inbox_id:
            continue
        contact_inbox_source_id = contact_inbox.get("source_id")
        if isinstance(contact_inbox_source_id, str):
            return contact_inbox_source_id
    return None


def _safe_path(url: httpx.URL) -> str:
    parts = urlsplit(str(url))
    return parts.path


def _safe_response_body(response: httpx.Response) -> dict[str, Any] | str | None:
    try:
        payload = response.json()
    except ValueError:
        text = response.text.strip()
        return text[:500] if text else None
    if isinstance(payload, dict):
        return cast(dict[str, Any], _redact_payload(payload))
    if isinstance(payload, list):
        return {"payload": _redact_payload(payload)}
    return str(payload)[:500]


def _redact_payload(value: Any) -> Any:
    if isinstance(value, dict):
        redacted: dict[str, Any] = {}
        for key, item in value.items():
            if any(marker in str(key).lower() for marker in _SENSITIVE_KEYS):
                redacted[str(key)] = _REDACTED
            else:
                redacted[str(key)] = _redact_payload(item)
        return redacted
    if isinstance(value, list):
        return [_redact_payload(item) for item in value]
    if isinstance(value, str):
        return value[:500]
    return value


def _looks_like_duplicate_contact(body: dict[str, Any] | str | None) -> bool:
    text = str(body or "").lower()
    return any(marker in text for marker in ("already", "exist", "taken", "duplicate"))


def _required_str_or_int(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key)
    if isinstance(value, str | int):
        return str(value)
    msg = f"Chatwoot response is missing {key}"
    raise RuntimeError(msg)
