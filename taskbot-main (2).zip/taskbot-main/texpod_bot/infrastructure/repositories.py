from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from texpod_bot.domain.enums import TicketStatus
from texpod_bot.domain.schemas import (
    ClientCreate,
    DeviceCreate,
    MessageRoutingCreate,
    RunbookCreate,
    RunbookStepCreate,
    SupportOperatorCreate,
    TicketCreate,
    TicketEventCreate,
    TicketExternalRefCreate,
    TicketMessageCreate,
)
from texpod_bot.infrastructure.database.models import (
    Client,
    Device,
    MessageRouting,
    Runbook,
    RunbookStep,
    SupportOperator,
    SupportSession,
    Ticket,
    TicketEvent,
    TicketExternalRef,
    TicketMessage,
)


class BaseRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def flush(self) -> None:
        await self._session.flush()


class ClientRepository(BaseRepository):
    async def create(self, data: ClientCreate) -> Client:
        client = Client(**data.model_dump())
        self._session.add(client)
        await self.flush()
        return client

    async def get(self, client_id: str) -> Client | None:
        return await self._session.get(Client, client_id)

    async def get_by_telegram_user_id(self, telegram_user_id: str) -> Client | None:
        result = await self._session.execute(
            select(Client).where(Client.telegram_user_id == telegram_user_id)
        )
        return result.scalar_one_or_none()


class DeviceRepository(BaseRepository):
    async def create(self, data: DeviceCreate) -> Device:
        device = Device(**data.model_dump(mode="json"))
        self._session.add(device)
        await self.flush()
        return device

    async def get_by_device_id(self, client_id: str, device_id: str) -> Device | None:
        result = await self._session.execute(
            select(Device).where(Device.client_id == client_id, Device.device_id == device_id)
        )
        return result.scalar_one_or_none()

    async def get(self, device_id: str) -> Device | None:
        return await self._session.get(Device, device_id)


class SupportOperatorRepository(BaseRepository):
    async def create(self, data: SupportOperatorCreate) -> SupportOperator:
        operator = SupportOperator(**data.model_dump())
        self._session.add(operator)
        await self.flush()
        return operator

    async def get_active_by_telegram_user_id(
        self,
        telegram_user_id: str,
    ) -> SupportOperator | None:
        result = await self._session.execute(
            select(SupportOperator).where(
                SupportOperator.telegram_user_id == telegram_user_id,
                SupportOperator.active.is_(True),
            )
        )
        return result.scalar_one_or_none()


class SupportSessionRepository(BaseRepository):
    async def get_by_telegram_chat(
        self,
        telegram_user_id: str,
        telegram_chat_id: str,
    ) -> SupportSession | None:
        result = await self._session.execute(
            select(SupportSession).where(
                SupportSession.telegram_user_id == telegram_user_id,
                SupportSession.telegram_chat_id == telegram_chat_id,
            )
        )
        return result.scalar_one_or_none()

    async def get_or_create(
        self,
        *,
        telegram_user_id: str,
        telegram_chat_id: str,
        client_id: str | None = None,
    ) -> SupportSession:
        session = await self.get_by_telegram_chat(telegram_user_id, telegram_chat_id)
        if session is not None:
            return session
        session = SupportSession(
            telegram_user_id=telegram_user_id,
            telegram_chat_id=telegram_chat_id,
            client_id=client_id,
        )
        self._session.add(session)
        await self.flush()
        return session


class TicketRepository(BaseRepository):
    async def create(self, data: TicketCreate) -> Ticket:
        ticket = Ticket(**data.model_dump(mode="json"))
        self._session.add(ticket)
        await self.flush()
        return ticket

    async def get(self, ticket_id: str) -> Ticket | None:
        return await self._session.get(Ticket, ticket_id)

    async def get_by_public_id(self, public_id: str) -> Ticket | None:
        result = await self._session.execute(select(Ticket).where(Ticket.public_id == public_id))
        return result.scalar_one_or_none()

    async def list_open_for_client(self, client_id: str) -> list[Ticket]:
        result = await self._session.execute(
            select(Ticket).where(
                Ticket.client_id == client_id,
                Ticket.status.not_in((TicketStatus.RESOLVED.value, TicketStatus.CLOSED.value)),
            )
        )
        return list(result.scalars().all())

    async def list_open(self) -> list[Ticket]:
        result = await self._session.execute(
            select(Ticket)
            .where(Ticket.status.not_in((TicketStatus.RESOLVED.value, TicketStatus.CLOSED.value)))
            .order_by(Ticket.created_at)
        )
        return list(result.scalars().all())


class TicketMessageRepository(BaseRepository):
    async def create(self, data: TicketMessageCreate) -> TicketMessage:
        message = TicketMessage(**data.model_dump(mode="json"))
        self._session.add(message)
        await self.flush()
        return message

    async def list_for_ticket(self, ticket_id: str) -> list[TicketMessage]:
        result = await self._session.execute(
            select(TicketMessage)
            .where(TicketMessage.ticket_id == ticket_id)
            .order_by(TicketMessage.created_at)
        )
        return list(result.scalars().all())


class RunbookRepository(BaseRepository):
    async def create(self, data: RunbookCreate) -> Runbook:
        runbook = Runbook(**data.model_dump())
        self._session.add(runbook)
        await self.flush()
        return runbook

    async def add_step(self, data: RunbookStepCreate) -> RunbookStep:
        step = RunbookStep(**data.model_dump())
        self._session.add(step)
        await self.flush()
        return step

    async def get_active_by_code(self, code: str) -> Runbook | None:
        result = await self._session.execute(
            select(Runbook)
            .where(Runbook.code == code, Runbook.active.is_(True))
            .order_by(Runbook.version.desc())
        )
        return result.scalars().first()


class TicketEventRepository(BaseRepository):
    async def create(self, data: TicketEventCreate) -> TicketEvent:
        event = TicketEvent(**data.model_dump(mode="json"))
        self._session.add(event)
        await self.flush()
        return event

    async def list_for_ticket(self, ticket_id: str) -> list[TicketEvent]:
        result = await self._session.execute(
            select(TicketEvent)
            .where(TicketEvent.ticket_id == ticket_id)
            .order_by(TicketEvent.created_at)
        )
        return list(result.scalars().all())


class MessageRoutingRepository(BaseRepository):
    async def create(self, data: MessageRoutingCreate) -> MessageRouting:
        routing = MessageRouting(**data.model_dump())
        self._session.add(routing)
        await self.flush()
        return routing

    async def get_by_ticket_id(self, ticket_id: str) -> MessageRouting | None:
        result = await self._session.execute(
            select(MessageRouting).where(MessageRouting.ticket_id == ticket_id)
        )
        return result.scalar_one_or_none()

    async def get_by_support_context(
        self,
        *,
        support_group_message_id: str | None = None,
        support_thread_id: str | None = None,
    ) -> MessageRouting | None:
        conditions = []
        if support_thread_id is not None:
            conditions.append(MessageRouting.support_thread_id == support_thread_id)
        if support_group_message_id is not None:
            conditions.append(MessageRouting.support_group_message_id == support_group_message_id)
        if not conditions:
            return None
        result = await self._session.execute(select(MessageRouting).where(*conditions))
        return result.scalars().first()


class TicketExternalRefRepository(BaseRepository):
    async def create_or_update_external_ref(
        self,
        data: TicketExternalRefCreate,
    ) -> TicketExternalRef:
        ref = await self.get_by_ticket_and_system(data.ticket_id, data.external_system)
        values = data.model_dump(mode="json")
        if ref is None:
            ref = TicketExternalRef(**values)
            self._session.add(ref)
        else:
            for key, value in values.items():
                setattr(ref, key, value)
        await self.flush()
        return ref

    async def get_by_ticket_and_system(
        self,
        ticket_id: str,
        external_system: str,
    ) -> TicketExternalRef | None:
        result = await self._session.execute(
            select(TicketExternalRef).where(
                TicketExternalRef.ticket_id == ticket_id,
                TicketExternalRef.external_system == external_system,
            )
        )
        return result.scalar_one_or_none()

    async def get_by_external_conversation_id(
        self,
        external_system: str,
        external_conversation_id: str,
    ) -> TicketExternalRef | None:
        result = await self._session.execute(
            select(TicketExternalRef).where(
                TicketExternalRef.external_system == external_system,
                TicketExternalRef.external_conversation_id == external_conversation_id,
            )
        )
        return result.scalar_one_or_none()


class SupportUnitOfWork:
    def __init__(self, session: AsyncSession) -> None:
        self.session = session
        self.clients = ClientRepository(session)
        self.devices = DeviceRepository(session)
        self.operators = SupportOperatorRepository(session)
        self.sessions = SupportSessionRepository(session)
        self.tickets = TicketRepository(session)
        self.messages = TicketMessageRepository(session)
        self.runbooks = RunbookRepository(session)
        self.events = TicketEventRepository(session)
        self.message_routings = MessageRoutingRepository(session)
        self.external_refs = TicketExternalRefRepository(session)

    async def commit(self) -> None:
        await self.session.commit()

    async def rollback(self) -> None:
        await self.session.rollback()


def dump_model(model: Any) -> dict[str, Any]:
    return {column.name: getattr(model, column.name) for column in model.__table__.columns}
