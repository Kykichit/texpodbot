"""Infrastructure adapters for the Texpod support bot."""
