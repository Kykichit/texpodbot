from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

from texpod_bot.domain.enums import (
    DeviceStatus,
    IssueType,
    MessageSenderType,
    TicketEventType,
    TicketPriority,
    TicketSource,
    TicketStatus,
)


def new_id() -> str:
    return str(uuid4())


def utc_now() -> datetime:
    return datetime.now(UTC)


class Base(DeclarativeBase):
    pass


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        default=utc_now,
        onupdate=utc_now,
    )


class Client(Base, TimestampMixin):
    __tablename__ = "clients"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    contact_name: Mapped[str | None] = mapped_column(String(255))
    phone: Mapped[str | None] = mapped_column(String(64))
    telegram_user_id: Mapped[str | None] = mapped_column(String(64), unique=True)

    devices: Mapped[list["Device"]] = relationship(back_populates="client")
    tickets: Mapped[list["Ticket"]] = relationship(back_populates="client")


class Device(Base, TimestampMixin):
    __tablename__ = "devices"
    __table_args__ = (UniqueConstraint("client_id", "device_id", name="uq_devices_client_device"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    client_id: Mapped[str] = mapped_column(ForeignKey("clients.id"), nullable=False, index=True)
    device_id: Mapped[str] = mapped_column(String(128), nullable=False)
    name: Mapped[str | None] = mapped_column(String(255))
    app_version: Mapped[str | None] = mapped_column(String(64))
    android_version: Mapped[str | None] = mapped_column(String(64))
    last_seen_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_sync_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    status: Mapped[str] = mapped_column(
        String(32),
        default=DeviceStatus.UNKNOWN.value,
        nullable=False,
    )

    client: Mapped[Client] = relationship(back_populates="devices")
    tickets: Mapped[list["Ticket"]] = relationship(back_populates="device")


class SupportOperator(Base):
    __tablename__ = "support_operators"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    telegram_user_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    display_name: Mapped[str] = mapped_column(String(255), nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    assigned_tickets: Mapped[list["Ticket"]] = relationship(back_populates="operator")


class Ticket(Base, TimestampMixin):
    __tablename__ = "tickets"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    public_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False)
    client_id: Mapped[str] = mapped_column(ForeignKey("clients.id"), nullable=False, index=True)
    device_id: Mapped[str | None] = mapped_column(ForeignKey("devices.id"), index=True)
    telegram_chat_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    issue_type: Mapped[str] = mapped_column(
        String(64),
        default=IssueType.UNKNOWN.value,
        nullable=False,
    )
    status: Mapped[str] = mapped_column(String(32), default=TicketStatus.NEW.value, nullable=False)
    priority: Mapped[str] = mapped_column(
        String(32),
        default=TicketPriority.P4.value,
        nullable=False,
    )
    assigned_to: Mapped[str | None] = mapped_column(ForeignKey("support_operators.id"), index=True)
    source: Mapped[str] = mapped_column(
        String(32),
        default=TicketSource.TELEGRAM.value,
        nullable=False,
    )
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    first_response_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    reopened_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    client: Mapped[Client] = relationship(back_populates="tickets")
    device: Mapped[Device | None] = relationship(back_populates="tickets")
    operator: Mapped[SupportOperator | None] = relationship(back_populates="assigned_tickets")
    messages: Mapped[list["TicketMessage"]] = relationship(back_populates="ticket")
    events: Mapped[list["TicketEvent"]] = relationship(back_populates="ticket")
    external_refs: Mapped[list["TicketExternalRef"]] = relationship(back_populates="ticket")


class TicketMessage(Base):
    __tablename__ = "ticket_messages"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    ticket_id: Mapped[str] = mapped_column(ForeignKey("tickets.id"), nullable=False, index=True)
    sender_type: Mapped[str] = mapped_column(
        String(32),
        default=MessageSenderType.SYSTEM.value,
        nullable=False,
    )
    sender_id: Mapped[str | None] = mapped_column(String(128))
    text: Mapped[str | None] = mapped_column(Text)
    attachment_url: Mapped[str | None] = mapped_column(String(2048))
    telegram_message_id: Mapped[str | None] = mapped_column(String(64))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    ticket: Mapped[Ticket] = relationship(back_populates="messages")


class Runbook(Base, TimestampMixin):
    __tablename__ = "runbooks"
    __table_args__ = (UniqueConstraint("code", "version", name="uq_runbooks_code_version"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    code: Mapped[str] = mapped_column(String(128), nullable=False, index=True)
    title: Mapped[str] = mapped_column(String(255), nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    version: Mapped[int] = mapped_column(Integer, default=1, nullable=False)

    steps: Mapped[list["RunbookStep"]] = relationship(back_populates="runbook")


class RunbookStep(Base):
    __tablename__ = "runbook_steps"
    __table_args__ = (UniqueConstraint("runbook_id", "step_key", name="uq_runbook_steps_key"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    runbook_id: Mapped[str] = mapped_column(ForeignKey("runbooks.id"), nullable=False, index=True)
    step_key: Mapped[str] = mapped_column(String(128), nullable=False)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    options_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)
    next_rules_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)
    action: Mapped[str | None] = mapped_column(String(128))

    runbook: Mapped[Runbook] = relationship(back_populates="steps")


class TicketEvent(Base):
    __tablename__ = "ticket_events"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    ticket_id: Mapped[str] = mapped_column(ForeignKey("tickets.id"), nullable=False, index=True)
    event_type: Mapped[str] = mapped_column(
        String(64),
        default=TicketEventType.CREATED.value,
        nullable=False,
    )
    payload_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    ticket: Mapped[Ticket] = relationship(back_populates="events")


class MessageRouting(Base, TimestampMixin):
    __tablename__ = "message_routings"
    __table_args__ = (
        UniqueConstraint("ticket_id", name="uq_message_routings_ticket_id"),
        UniqueConstraint(
            "support_group_message_id",
            "support_thread_id",
            name="uq_message_routings_support_context",
        ),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    ticket_id: Mapped[str] = mapped_column(ForeignKey("tickets.id"), nullable=False, index=True)
    client_chat_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    support_group_message_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    support_thread_id: Mapped[str | None] = mapped_column(String(64), index=True)

    ticket: Mapped[Ticket] = relationship()


class TicketExternalRef(Base, TimestampMixin):
    __tablename__ = "ticket_external_refs"
    __table_args__ = (
        UniqueConstraint("ticket_id", "external_system", name="uq_ticket_external_refs_system"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    ticket_id: Mapped[str] = mapped_column(ForeignKey("tickets.id"), nullable=False, index=True)
    external_system: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    external_contact_id: Mapped[str | None] = mapped_column(String(128))
    external_conversation_id: Mapped[str | None] = mapped_column(String(128), index=True)
    external_url: Mapped[str | None] = mapped_column(String(2048))
    metadata_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)

    ticket: Mapped[Ticket] = relationship(back_populates="external_refs")


class SupportSession(Base, TimestampMixin):
    __tablename__ = "support_sessions"
    __table_args__ = (
        UniqueConstraint("telegram_user_id", "telegram_chat_id", name="uq_support_sessions_chat"),
    )

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    telegram_user_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    telegram_chat_id: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    client_id: Mapped[str | None] = mapped_column(ForeignKey("clients.id"), index=True)
    ticket_id: Mapped[str | None] = mapped_column(ForeignKey("tickets.id"), index=True)
    runbook_code: Mapped[str | None] = mapped_column(String(128))
    current_step_key: Mapped[str | None] = mapped_column(String(128))
    state: Mapped[str] = mapped_column(String(64), nullable=False, default="main_menu")
    history_json: Mapped[list[dict[str, Any]]] = mapped_column(JSON, default=list, nullable=False)

    client: Mapped[Client | None] = relationship()
    ticket: Mapped[Ticket | None] = relationship()
