"""Texpod support bot domain package."""
