from enum import StrEnum


class DeviceStatus(StrEnum):
    UNKNOWN = "unknown"
    ONLINE = "online"
    OFFLINE = "offline"
    DEGRADED = "degraded"
    MAINTENANCE = "maintenance"


class IssueType(StrEnum):
    UNKNOWN = "unknown"
    SCANNER_NOT_WORKING = "scanner_not_working"
    RELEASE_NOT_DISPLAYED = "release_not_displayed"
    TIMESHEET_SHIFT_OPEN_FAILED = "timesheet_shift_open_failed"
    CASH_SHIFT_OPEN_FAILED = "cash_shift_open_failed"
    RECEIPTS_NOT_PRINTING = "receipts_not_printing"
    TERMINAL_NOT_WORKING = "terminal_not_working"
    OTHER = "other"
    DEVICE_OFFLINE = "device_offline"
    PAYMENT = "payment"
    PRINTER = "printer"
    MENU_SYNC = "menu_sync"
    LOGIN = "login"
    NETWORK = "network"
    HARDWARE = "hardware"
    SOFTWARE = "software"


class TicketStatus(StrEnum):
    NEW = "new"
    COLLECTING_DATA = "collecting_data"
    OPEN = "open"
    RUNBOOK_IN_PROGRESS = "runbook_in_progress"
    WAITING_CLIENT = "waiting_client"
    WAITING_CUSTOMER = "waiting_customer"
    WAITING_SUPPORT = "waiting_support"
    ASSIGNED = "assigned"
    DEV_NEEDED = "dev_needed"
    RESOLVED = "resolved"
    CLOSED = "closed"
    REOPENED = "reopened"
    CANCELLED = "cancelled"


class TicketPriority(StrEnum):
    P1 = "p1"
    P2 = "p2"
    P3 = "p3"
    P4 = "p4"


class TicketSource(StrEnum):
    TELEGRAM = "telegram"
    MAX = "max"
    CHATWOOT = "chatwoot"
    WHATSAPP = "whatsapp"
    PHONE = "phone"
    SYSTEM = "system"


class MessageSenderType(StrEnum):
    CLIENT = "client"
    BOT = "bot"
    SUPPORT = "support"
    SYSTEM = "system"


class TicketEventType(StrEnum):
    CREATED = "created"
    STATUS_CHANGED = "status_changed"
    PRIORITY_CHANGED = "priority_changed"
    ASSIGNED = "assigned"
    MESSAGE_ADDED = "message_added"
    CUSTOMER_MESSAGE_ADDED = "customer_message_added"
    OPERATOR_MESSAGE_ADDED = "operator_message_added"
    RUNBOOK_STARTED = "runbook_started"
    RUNBOOK_STEP_SHOWN = "runbook_step_shown"
    RUNBOOK_OPTION_SELECTED = "runbook_option_selected"
    RUNBOOK_STEP_COMPLETED = "runbook_step_completed"
    RUNBOOK_MEDIA_REQUESTED = "runbook_media_requested"
    RUNBOOK_RESOLVED = "runbook_resolved"
    RUNBOOK_ABANDONED = "runbook_abandoned"
    RUNBOOK_FAILED = "runbook_failed"
    ESCALATED = "escalated"
    FIRST_RESPONSE_RECORDED = "first_response_recorded"
    REOPENED = "reopened"
    CANCELLED = "cancelled"
    SLA_BREACHED = "sla_breached"
    SUPPORT_GROUP_SEND_FAILED = "support_group_send_failed"
    CHATWOOT_THREAD_CREATED = "chatwoot_thread_created"
    CHATWOOT_THREAD_CREATE_FAILED = "chatwoot_thread_create_failed"
    CHATWOOT_OPERATOR_REPLY_SENT = "chatwoot_operator_reply_sent"
    CHATWOOT_OPERATOR_REPLY_SEND_FAILED = "chatwoot_operator_reply_send_failed"
    CHATWOOT_WEBHOOK_IGNORED = "chatwoot_webhook_ignored"
    CHATWOOT_CUSTOMER_MESSAGE_SENT = "chatwoot_customer_message_sent"
    CHATWOOT_CUSTOMER_MESSAGE_SEND_FAILED = "chatwoot_customer_message_send_failed"
    CHATWOOT_CONVERSATION_RESOLVED = "chatwoot_conversation_resolved"
    CHATWOOT_TICKET_CLOSE_NOTIFY_FAILED = "chatwoot_ticket_close_notify_failed"
    GITHUB_ISSUE_CREATED = "github_issue_created"
    GITHUB_ISSUE_CREATE_FAILED = "github_issue_create_failed"
    DEV_NEEDED = "dev_needed"
    RESOLVED = "resolved"
    CLOSED = "closed"
