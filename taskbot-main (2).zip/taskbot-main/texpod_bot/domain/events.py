from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol

from texpod_bot.domain.enums import MessageSenderType, TicketEventType, TicketStatus
from texpod_bot.domain.schemas import TicketEventCreate


class TicketEventWriter(Protocol):
    async def create(self, data: TicketEventCreate) -> object:
        """Persist a ticket event."""


@dataclass(frozen=True, slots=True)
class TicketStatusChangedPayload:
    from_status: TicketStatus
    to_status: TicketStatus
    reason: str | None = None

    def as_json(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "from_status": self.from_status.value,
            "to_status": self.to_status.value,
        }
        if self.reason:
            payload["reason"] = self.reason
        return payload


@dataclass(frozen=True, slots=True)
class MessageAddedPayload:
    sender_type: MessageSenderType
    has_attachment: bool = False
    source: str | None = None
    operator_id: str | None = None

    def as_json(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "sender_type": self.sender_type.value,
            "has_attachment": self.has_attachment,
        }
        if self.source:
            payload["source"] = self.source
        if self.operator_id:
            payload["operator_id"] = self.operator_id
        return payload


@dataclass(frozen=True, slots=True)
class RunbookEventPayload:
    runbook_code: str
    step_key: str | None = None
    selected_option: str | None = None
    runbook_version: int | None = None
    extra: dict[str, object] = field(default_factory=dict)

    def as_json(self) -> dict[str, object]:
        payload: dict[str, object] = {"runbook_code": self.runbook_code, **self.extra}
        if self.step_key:
            payload["step_key"] = self.step_key
        if self.selected_option:
            payload["selected_option"] = self.selected_option
        if self.runbook_version is not None:
            payload["runbook_version"] = self.runbook_version
        return payload


@dataclass(frozen=True, slots=True)
class TicketTimestampPayload:
    timestamp: datetime
    actor_id: str | None = None

    def as_json(self) -> dict[str, object]:
        payload: dict[str, object] = {"timestamp": self.timestamp.isoformat()}
        if self.actor_id:
            payload["actor_id"] = self.actor_id
        return payload


async def record_ticket_event(
    writer: TicketEventWriter,
    *,
    ticket_id: str,
    event_type: TicketEventType,
    payload: dict[str, Any] | None = None,
) -> object:
    return await writer.create(
        TicketEventCreate(
            ticket_id=ticket_id,
            event_type=event_type,
            payload_json=payload or {},
        )
    )
