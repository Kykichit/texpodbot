from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from texpod_bot.domain.enums import (
    DeviceStatus,
    IssueType,
    MessageSenderType,
    TicketEventType,
    TicketPriority,
    TicketSource,
    TicketStatus,
)


class Schema(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class ClientCreate(Schema):
    name: str
    contact_name: str | None = None
    phone: str | None = None
    telegram_user_id: str | None = None


class ClientRead(ClientCreate):
    id: str
    created_at: datetime
    updated_at: datetime


class DeviceCreate(Schema):
    client_id: str
    device_id: str
    name: str | None = None
    app_version: str | None = None
    android_version: str | None = None
    status: DeviceStatus = DeviceStatus.UNKNOWN


class DeviceRead(DeviceCreate):
    id: str
    last_seen_at: datetime | None = None
    last_sync_at: datetime | None = None
    created_at: datetime
    updated_at: datetime


class TicketCreate(Schema):
    client_id: str
    public_id: str
    telegram_chat_id: str
    device_id: str | None = None
    issue_type: IssueType = IssueType.UNKNOWN
    status: TicketStatus = TicketStatus.NEW
    priority: TicketPriority = TicketPriority.P4
    assigned_to: str | None = None
    source: TicketSource = TicketSource.TELEGRAM


class TicketRead(TicketCreate):
    id: str
    closed_at: datetime | None = None
    first_response_at: datetime | None = None
    resolved_at: datetime | None = None
    reopened_at: datetime | None = None
    created_at: datetime
    updated_at: datetime


class TicketMessageCreate(Schema):
    ticket_id: str
    sender_type: MessageSenderType
    sender_id: str | None = None
    text: str | None = None
    attachment_url: str | None = None
    telegram_message_id: str | None = None


class TicketMessageRead(TicketMessageCreate):
    id: str
    created_at: datetime


class RunbookCreate(Schema):
    code: str
    title: str
    description: str | None = None
    active: bool = True
    version: int = 1


class RunbookRead(RunbookCreate):
    id: str
    created_at: datetime
    updated_at: datetime


class RunbookStepCreate(Schema):
    runbook_id: str
    step_key: str
    text: str
    options_json: dict[str, Any] = Field(default_factory=dict)
    next_rules_json: dict[str, Any] = Field(default_factory=dict)
    action: str | None = None


class RunbookStepRead(RunbookStepCreate):
    id: str


class TicketEventCreate(Schema):
    ticket_id: str
    event_type: TicketEventType
    payload_json: dict[str, Any] = Field(default_factory=dict)


class TicketEventRead(TicketEventCreate):
    id: str
    created_at: datetime


class SupportOperatorCreate(Schema):
    telegram_user_id: str
    display_name: str
    active: bool = True


class SupportOperatorRead(SupportOperatorCreate):
    id: str
    created_at: datetime


class MessageRoutingCreate(Schema):
    ticket_id: str
    client_chat_id: str
    support_group_message_id: str
    support_thread_id: str | None = None


class MessageRoutingRead(MessageRoutingCreate):
    id: str
    created_at: datetime
    updated_at: datetime


class TicketExternalRefCreate(Schema):
    ticket_id: str
    external_system: str
    external_contact_id: str | None = None
    external_conversation_id: str | None = None
    external_url: str | None = None
    metadata_json: dict[str, Any] = Field(default_factory=dict)


class TicketExternalRefRead(TicketExternalRefCreate):
    id: str
    created_at: datetime
    updated_at: datetime
