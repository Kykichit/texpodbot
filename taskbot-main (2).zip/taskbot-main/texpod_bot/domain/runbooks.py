from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Any

import yaml


class RunbookAction(StrEnum):
    RESOLVED = "resolved"
    ESCALATE = "escalate"
    CREATE_TICKET = "create_ticket"
    COLLECT_MEDIA = "collect_media"


class RunbookError(ValueError):
    """Base error for invalid runbook definitions or transitions."""


class RunbookValidationError(RunbookError):
    """Raised when a runbook file is malformed."""


class UnknownRunbookOptionError(RunbookError):
    """Raised when a selected option is not available on the current step."""


@dataclass(frozen=True, slots=True)
class RunbookOption:
    label: str
    next_step: str


@dataclass(frozen=True, slots=True)
class RunbookStep:
    step_key: str
    text: str
    options: tuple[RunbookOption, ...] = field(default_factory=tuple)
    next_step: str | None = None
    action: RunbookAction | None = None


@dataclass(frozen=True, slots=True)
class RunbookDefinition:
    code: str
    title: str
    steps: dict[str, RunbookStep]
    description: str | None = None
    start_step: str = "start"

    def step(self, step_key: str) -> RunbookStep:
        try:
            return self.steps[step_key]
        except KeyError as exc:
            msg = f"Runbook {self.code} references unknown step {step_key!r}"
            raise RunbookValidationError(msg) from exc


@dataclass(frozen=True, slots=True)
class RunbookHistoryItem:
    step_key: str
    selected_option: str | None
    next_step: str | None
    action: RunbookAction | None


@dataclass(frozen=True, slots=True)
class RunbookSession:
    runbook_code: str
    current_step_key: str
    history: tuple[RunbookHistoryItem, ...] = field(default_factory=tuple)
    finished: bool = False
    action: RunbookAction | None = None


class RunbookEngine:
    def __init__(self, runbooks: dict[str, RunbookDefinition]) -> None:
        self._runbooks = runbooks

    def start(self, code: str) -> RunbookSession:
        runbook = self._get_runbook(code)
        step = runbook.step(runbook.start_step)
        return RunbookSession(
            runbook_code=runbook.code,
            current_step_key=step.step_key,
            finished=step.action in _TERMINAL_ACTIONS,
            action=step.action if step.action in _TERMINAL_ACTIONS else None,
        )

    def current_step(self, session: RunbookSession) -> RunbookStep:
        return self._get_runbook(session.runbook_code).step(session.current_step_key)

    def choose_option(self, session: RunbookSession, selected_option: str) -> RunbookSession:
        if session.finished:
            return session

        current = self.current_step(session)
        option = _match_option(current, selected_option)
        next_step = self._get_runbook(session.runbook_code).step(option.next_step)
        action = next_step.action
        history_item = RunbookHistoryItem(
            step_key=current.step_key,
            selected_option=option.label,
            next_step=next_step.step_key,
            action=action,
        )
        return RunbookSession(
            runbook_code=session.runbook_code,
            current_step_key=next_step.step_key,
            history=(*session.history, history_item),
            finished=action in _TERMINAL_ACTIONS,
            action=action if action in _TERMINAL_ACTIONS else None,
        )

    def advance_action_step(self, session: RunbookSession) -> RunbookSession:
        if session.finished:
            return session

        current = self.current_step(session)
        if current.next_step is None:
            return RunbookSession(
                runbook_code=session.runbook_code,
                current_step_key=session.current_step_key,
                history=session.history,
                finished=current.action in _TERMINAL_ACTIONS,
                action=current.action if current.action in _TERMINAL_ACTIONS else None,
            )

        next_step = self._get_runbook(session.runbook_code).step(current.next_step)
        history_item = RunbookHistoryItem(
            step_key=current.step_key,
            selected_option=None,
            next_step=next_step.step_key,
            action=next_step.action,
        )
        return RunbookSession(
            runbook_code=session.runbook_code,
            current_step_key=next_step.step_key,
            history=(*session.history, history_item),
            finished=next_step.action in _TERMINAL_ACTIONS,
            action=next_step.action if next_step.action in _TERMINAL_ACTIONS else None,
        )

    def _get_runbook(self, code: str) -> RunbookDefinition:
        try:
            return self._runbooks[code]
        except KeyError as exc:
            msg = f"Unknown runbook code {code!r}"
            raise RunbookValidationError(msg) from exc


def load_runbooks_from_dir(path: Path) -> dict[str, RunbookDefinition]:
    runbooks: dict[str, RunbookDefinition] = {}
    for file_path in sorted((*path.glob("*.yaml"), *path.glob("*.yml"))):
        runbook = load_runbook_from_yaml(file_path)
        if runbook.code in runbooks:
            msg = f"Duplicate runbook code {runbook.code!r}"
            raise RunbookValidationError(msg)
        runbooks[runbook.code] = runbook
    return runbooks


def load_runbook_from_yaml(path: Path) -> RunbookDefinition:
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        msg = f"Runbook {path} must contain a YAML object"
        raise RunbookValidationError(msg)
    return parse_runbook(raw, source=str(path))


def parse_runbook(raw: dict[str, Any], source: str = "<memory>") -> RunbookDefinition:
    code = _required_str(raw, "code", source)
    title = _required_str(raw, "title", source)
    description = raw.get("description")
    if description is not None and not isinstance(description, str):
        msg = f"{source}: description must be a string"
        raise RunbookValidationError(msg)

    raw_steps = raw.get("steps")
    if not isinstance(raw_steps, dict) or not raw_steps:
        msg = f"{source}: steps must be a non-empty object"
        raise RunbookValidationError(msg)

    steps = {
        step_key: _parse_step(step_key, raw_step, source)
        for step_key, raw_step in raw_steps.items()
        if isinstance(step_key, str)
    }
    if len(steps) != len(raw_steps):
        msg = f"{source}: every step key must be a string"
        raise RunbookValidationError(msg)

    runbook = RunbookDefinition(
        code=code,
        title=title,
        description=description,
        steps=steps,
    )
    _validate_graph(runbook, source)
    return runbook


def _parse_step(step_key: str, raw_step: Any, source: str) -> RunbookStep:
    if not isinstance(raw_step, dict):
        msg = f"{source}: step {step_key!r} must be an object"
        raise RunbookValidationError(msg)

    text = _required_str(raw_step, "text", f"{source}:{step_key}")
    action = _parse_action(raw_step.get("action"), source, step_key)
    next_step = raw_step.get("next")
    if next_step is not None and not isinstance(next_step, str):
        msg = f"{source}: step {step_key!r} next must be a string"
        raise RunbookValidationError(msg)

    options = tuple(_parse_options(raw_step.get("options", []), source, step_key))
    if options and next_step is not None:
        msg = f"{source}: step {step_key!r} cannot define both options and next"
        raise RunbookValidationError(msg)

    return RunbookStep(
        step_key=step_key,
        text=text,
        options=options,
        next_step=next_step,
        action=action,
    )


def _parse_options(raw_options: Any, source: str, step_key: str) -> list[RunbookOption]:
    if raw_options is None:
        return []
    if not isinstance(raw_options, list):
        msg = f"{source}: step {step_key!r} options must be a list"
        raise RunbookValidationError(msg)

    options: list[RunbookOption] = []
    seen: set[str] = set()
    for raw_option in raw_options:
        if not isinstance(raw_option, dict):
            msg = f"{source}: step {step_key!r} option must be an object"
            raise RunbookValidationError(msg)
        label = _required_str(raw_option, "label", f"{source}:{step_key}")
        next_step = _required_str(raw_option, "next", f"{source}:{step_key}:{label}")
        normalized = _normalize_option(label)
        if normalized in seen:
            msg = f"{source}: step {step_key!r} has duplicate option {label!r}"
            raise RunbookValidationError(msg)
        seen.add(normalized)
        options.append(RunbookOption(label=label, next_step=next_step))
    return options


def _parse_action(raw_action: Any, source: str, step_key: str) -> RunbookAction | None:
    if raw_action is None:
        return None
    if not isinstance(raw_action, str):
        msg = f"{source}: step {step_key!r} action must be a string"
        raise RunbookValidationError(msg)
    try:
        return RunbookAction(raw_action)
    except ValueError as exc:
        msg = f"{source}: step {step_key!r} has unknown action {raw_action!r}"
        raise RunbookValidationError(msg) from exc


def _validate_graph(runbook: RunbookDefinition, source: str) -> None:
    if runbook.start_step not in runbook.steps:
        msg = f"{source}: runbook must define a start step"
        raise RunbookValidationError(msg)

    for step in runbook.steps.values():
        for option in step.options:
            if option.next_step not in runbook.steps:
                msg = (
                    f"{source}: step {step.step_key!r} option {option.label!r} "
                    f"references unknown step {option.next_step!r}"
                )
                raise RunbookValidationError(msg)
        if step.next_step is not None and step.next_step not in runbook.steps:
            msg = f"{source}: step {step.step_key!r} references unknown step {step.next_step!r}"
            raise RunbookValidationError(msg)


def _required_str(raw: dict[str, Any], field_name: str, source: str) -> str:
    value = raw.get(field_name)
    if not isinstance(value, str) or not value.strip():
        msg = f"{source}: {field_name} must be a non-empty string"
        raise RunbookValidationError(msg)
    return value


def _match_option(step: RunbookStep, selected_option: str) -> RunbookOption:
    normalized = _normalize_option(selected_option)
    for option in step.options:
        if _normalize_option(option.label) == normalized:
            return option
    msg = f"Unknown option {selected_option!r} for step {step.step_key!r}"
    raise UnknownRunbookOptionError(msg)


def _normalize_option(label: str) -> str:
    return label.strip().casefold()


_TERMINAL_ACTIONS = {
    RunbookAction.RESOLVED,
    RunbookAction.ESCALATE,
    RunbookAction.CREATE_TICKET,
}
