from dataclasses import dataclass
from typing import Protocol

from texpod_bot.domain.enums import MessageSenderType, TicketEventType, TicketStatus
from texpod_bot.domain.schemas import MessageRoutingCreate
from texpod_bot.infrastructure.database.models import MessageRouting, Ticket
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.tickets import TicketService

ACCESS_DENIED_MESSAGE = "Нет доступа. Попросите администратора добавить вас оператором."


class TelegramSupportApi(Protocol):
    async def send_message(
        self,
        *,
        chat_id: str,
        text: str,
        reply_to_message_id: str | None = None,
        message_thread_id: str | None = None,
    ) -> "SentTelegramMessage":
        """Send a Telegram message without exposing live API details to services."""


@dataclass(frozen=True, slots=True)
class SentTelegramMessage:
    message_id: str
    message_thread_id: str | None = None


@dataclass(frozen=True, slots=True)
class SupportGroupReply:
    operator_telegram_user_id: str
    support_group_message_id: str | None
    support_thread_id: str | None
    text: str | None
    telegram_message_id: str


@dataclass(frozen=True, slots=True)
class ClientReply:
    ticket_id: str
    client_id: str | None
    text: str | None
    attachment_url: str | None = None
    telegram_message_id: str | None = None


@dataclass(frozen=True, slots=True)
class RoutingResult:
    routed: bool
    reason: str | None = None


class TelegramEscalationService:
    def __init__(
        self,
        *,
        uow: SupportUnitOfWork,
        ticket_service: TicketService,
        telegram_api: TelegramSupportApi,
        support_group_id: str,
    ) -> None:
        self._uow = uow
        self._tickets = ticket_service
        self._telegram = telegram_api
        self._support_group_id = support_group_id

    async def escalate_to_support_group(self, ticket_id: str) -> MessageRouting:
        existing = await self._uow.message_routings.get_by_ticket_id(ticket_id)
        if existing is not None:
            return existing

        ticket = await self._tickets.escalate_ticket(ticket_id)
        summary = await self._build_ticket_summary(ticket)
        sent = await self._telegram.send_message(chat_id=self._support_group_id, text=summary)
        routing = await self._uow.message_routings.create(
            MessageRoutingCreate(
                ticket_id=ticket.id,
                client_chat_id=ticket.telegram_chat_id,
                support_group_message_id=sent.message_id,
                support_thread_id=sent.message_thread_id,
            )
        )
        await self._tickets.add_message(
            ticket.id,
            sender_type=MessageSenderType.BOT,
            text=summary,
            telegram_message_id=sent.message_id,
        )
        await self._tickets.add_event(
            ticket.id,
            TicketEventType.ESCALATED,
            {
                "support_group_message_id": sent.message_id,
                "support_thread_id": sent.message_thread_id,
            },
        )
        await self._uow.commit()
        return routing

    async def route_operator_reply(self, reply: SupportGroupReply) -> RoutingResult:
        operator = await self._uow.operators.get_active_by_telegram_user_id(
            reply.operator_telegram_user_id
        )
        if operator is None:
            await self._telegram.send_message(
                chat_id=self._support_group_id,
                text=ACCESS_DENIED_MESSAGE,
                reply_to_message_id=reply.telegram_message_id,
                message_thread_id=reply.support_thread_id,
            )
            return RoutingResult(routed=False, reason="operator_not_allowed")

        routing = await self._uow.message_routings.get_by_support_context(
            support_group_message_id=reply.support_group_message_id,
            support_thread_id=reply.support_thread_id,
        )
        if routing is None:
            return RoutingResult(routed=False, reason="routing_not_found")

        await self._telegram.send_message(
            chat_id=routing.client_chat_id,
            text=reply.text or "",
        )
        await self._tickets.add_message(
            routing.ticket_id,
            sender_type=MessageSenderType.SUPPORT,
            sender_id=operator.id,
            text=reply.text,
            telegram_message_id=reply.telegram_message_id,
        )
        await self._tickets.add_event(
            routing.ticket_id,
            TicketEventType.MESSAGE_ADDED,
            {"source": "support_group", "operator_id": operator.id},
        )
        await self._uow.commit()
        return RoutingResult(routed=True)

    async def route_client_reply(self, reply: ClientReply) -> RoutingResult:
        routing = await self._uow.message_routings.get_by_ticket_id(reply.ticket_id)
        if routing is None:
            return RoutingResult(routed=False, reason="routing_not_found")

        await self._tickets.add_message(
            reply.ticket_id,
            sender_type=MessageSenderType.CLIENT,
            sender_id=reply.client_id,
            text=reply.text,
            attachment_url=reply.attachment_url,
            telegram_message_id=reply.telegram_message_id,
        )
        await self._telegram.send_message(
            chat_id=self._support_group_id,
            text=reply.text or "[attachment]",
            reply_to_message_id=routing.support_group_message_id,
            message_thread_id=routing.support_thread_id,
        )
        await self._uow.commit()
        return RoutingResult(routed=True)

    async def _build_ticket_summary(self, ticket: Ticket) -> str:
        client = await self._uow.clients.get(ticket.client_id)
        timeline = await self._tickets.get_ticket_timeline(ticket.id)
        checked = _checked_steps_from_events([event.payload_json for event in timeline.events])
        collection = _collection_from_events([event.payload_json for event in timeline.events])
        checked_text = "\n".join(f"- {item}" for item in checked) if checked else "- Нет данных"
        collection_text = _format_collection(collection)
        client_name = client.name if client is not None else ticket.client_id
        return (
            f"Ticket: {ticket.public_id}\n"
            f"Client: {client_name}\n"
            f"Issue: {ticket.issue_type}\n"
            f"Priority: {ticket.priority}\n"
            f"Status: {TicketStatus(ticket.status).value}\n"
            "Checked:\n"
            f"{checked_text}\n"
            "Collected:\n"
            f"{collection_text}"
        )


def _checked_steps_from_events(payloads: list[dict[str, object]]) -> list[str]:
    checked: list[str] = []
    for payload in payloads:
        history = payload.get("history")
        if not isinstance(history, list):
            continue
        for item in history:
            if not isinstance(item, dict):
                continue
            step_key = item.get("step_key")
            selected_option = item.get("selected_option")
            if isinstance(step_key, str) and isinstance(selected_option, str):
                checked.append(f"{step_key}: {selected_option}")
    return checked


def _collection_from_events(payloads: list[dict[str, object]]) -> dict[str, object]:
    for payload in reversed(payloads):
        collection = payload.get("collection")
        if isinstance(collection, dict):
            return collection
    return {}


def _format_collection(collection: dict[str, object]) -> str:
    if not collection:
        return "- Нет данных"
    lines: list[str] = []
    for key in (
        "client_name",
        "location",
        "problem_started_at",
        "affected_scope",
        "business_blocked",
        "device_id",
        "app_version",
        "free_text_description",
    ):
        value = collection.get(key)
        lines.append(f"- {key}: {value if value else 'unknown'}")
    media = collection.get("screenshot_or_video")
    if isinstance(media, dict):
        lines.append(f"- screenshot_or_video: {media.get('file_id', 'unknown')}")
    else:
        lines.append("- screenshot_or_video: unknown")
    return "\n".join(lines)
