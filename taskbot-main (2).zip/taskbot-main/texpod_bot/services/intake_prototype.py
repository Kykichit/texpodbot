from dataclasses import dataclass
from enum import StrEnum
from typing import Any, Protocol
from uuid import uuid4

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from texpod_bot.domain.enums import (
    IssueType,
    MessageSenderType,
    TicketEventType,
    TicketPriority,
    TicketSource,
    TicketStatus,
)
from texpod_bot.domain.schemas import (
    ClientCreate,
    MessageRoutingCreate,
    TicketCreate,
    TicketEventCreate,
    TicketExternalRefCreate,
    TicketMessageCreate,
)
from texpod_bot.infrastructure.chatwoot import ChatwootApiError
from texpod_bot.infrastructure.database.models import SupportSession, Ticket
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.issue_classifier import IssueClassification, RuleBasedIssueClassifier
from texpod_bot.services.support_desk import SupportDeskAdapter
from texpod_bot.services.support_sessions import SupportFlowState, SupportSessionService
from texpod_bot.services.telegram_escalation import SentTelegramMessage

SessionMaker = async_sessionmaker[AsyncSession]

INTAKE_HISTORY_KIND = "prototype_intake"
CHATWOOT_EXTERNAL_SYSTEM = "chatwoot"


class IntakeState(StrEnum):
    AWAITING_PROBLEM = "awaiting_problem"
    ASKING_CLARIFICATION = "asking_clarification"
    ASKING_LOCATION = "asking_location"
    WAITING_SUPPORT = "waiting_support"
    CANCELLED = "cancelled"


class SupportNotifier(Protocol):
    async def notify_ticket_created(
        self,
        ticket_id: str,
        summary: str,
    ) -> SentTelegramMessage | None:
        """Notify support team about a newly created ticket."""

    async def notify_client_reply(
        self,
        *,
        public_id: str,
        text: str,
        reply_to_message_id: str,
        message_thread_id: str | None = None,
    ) -> SentTelegramMessage | None:
        """Notify support team about a client follow-up message."""


@dataclass(frozen=True, slots=True)
class IntakeContext:
    telegram_user_id: str
    telegram_chat_id: str
    display_name: str | None = None


@dataclass(frozen=True, slots=True)
class IntakeResponse:
    text: str
    ticket_public_id: str | None = None
    should_reply: bool = True


class IntakePrototypeService:
    def __init__(
        self,
        *,
        sessionmaker: SessionMaker,
        classifier: RuleBasedIssueClassifier | None = None,
        notifier: SupportNotifier | None = None,
        support_desk: SupportDeskAdapter | None = None,
    ) -> None:
        self._sessionmaker = sessionmaker
        self._classifier = classifier or RuleBasedIssueClassifier()
        self._notifier = notifier
        self._support_desk = support_desk

    async def start(self, context: IntakeContext) -> IntakeResponse:
        async with self._sessionmaker() as db_session:
            uow = SupportUnitOfWork(db_session)
            sessions = SupportSessionService(uow)
            support_session = await sessions.get_or_create_session(
                telegram_user_id=context.telegram_user_id,
                telegram_chat_id=context.telegram_chat_id,
            )
            sessions.reset_session(support_session)
            _store_intake_payload(support_session, {"state": IntakeState.AWAITING_PROBLEM.value})
            await uow.commit()
        return IntakeResponse(
            text=(
                "Здравствуйте! Опишите проблему одним сообщением. "
                "Я уточню детали и создам обращение."
            )
        )

    async def handle_text(self, context: IntakeContext, text: str) -> IntakeResponse:
        async with self._sessionmaker() as db_session:
            uow = SupportUnitOfWork(db_session)
            sessions = SupportSessionService(uow)
            support_session = await sessions.get_or_create_session(
                telegram_user_id=context.telegram_user_id,
                telegram_chat_id=context.telegram_chat_id,
            )
            payload = _load_intake_payload(support_session)
            state = IntakeState(str(payload.get("state", IntakeState.AWAITING_PROBLEM.value)))

            if state == IntakeState.AWAITING_PROBLEM:
                response = await self._handle_problem_text(uow, support_session, payload, text)
            elif state == IntakeState.ASKING_CLARIFICATION:
                response = await self._handle_clarification(support_session, payload, text)
            elif state == IntakeState.ASKING_LOCATION:
                response = await self._handle_location(
                    uow,
                    sessions,
                    support_session,
                    context,
                    payload,
                    text,
                )
            elif state == IntakeState.WAITING_SUPPORT:
                response = await self._handle_waiting_support(uow, support_session, context, text)
            else:
                sessions.reset_session(support_session)
                _store_intake_payload(
                    support_session,
                    {"state": IntakeState.AWAITING_PROBLEM.value},
                )
                response = IntakeResponse(
                    text="Опишите проблему одним сообщением. Я уточню детали и создам обращение."
                )

            await uow.commit()
            return response

    async def cancel(self, context: IntakeContext) -> IntakeResponse:
        async with self._sessionmaker() as db_session:
            uow = SupportUnitOfWork(db_session)
            sessions = SupportSessionService(uow)
            support_session = await sessions.get_or_create_session(
                telegram_user_id=context.telegram_user_id,
                telegram_chat_id=context.telegram_chat_id,
            )
            sessions.reset_session(support_session)
            sessions.set_state(support_session, SupportFlowState.CANCELLED)
            _store_intake_payload(support_session, {"state": IntakeState.CANCELLED.value})
            await uow.commit()
        return IntakeResponse(text="Обращение отменено. Чтобы начать заново, нажмите /start.")

    async def _handle_problem_text(
        self,
        uow: SupportUnitOfWork,
        session: SupportSession,
        payload: dict[str, Any],
        text: str,
    ) -> IntakeResponse:
        classification = self._classifier.classify(text)
        payload.update(
            {
                "state": IntakeState.ASKING_CLARIFICATION.value,
                "original_problem_text": text,
                "issue_type": classification.issue_type.value,
                "classification": _classification_payload(classification),
            }
        )
        _store_intake_payload(session, payload)
        session.state = IntakeState.ASKING_CLARIFICATION.value
        await uow.session.flush()
        return IntakeResponse(text=_clarification_question(classification.issue_type))

    async def _handle_clarification(
        self,
        session: SupportSession,
        payload: dict[str, Any],
        text: str,
    ) -> IntakeResponse:
        payload.update(
            {
                "state": IntakeState.ASKING_LOCATION.value,
                "clarification_answer": text,
            }
        )
        _store_intake_payload(session, payload)
        session.state = IntakeState.ASKING_LOCATION.value
        return IntakeResponse(text="Укажите филиал или точку. Если не знаете, напишите: не знаю.")

    async def _handle_location(
        self,
        uow: SupportUnitOfWork,
        sessions: SupportSessionService,
        session: SupportSession,
        context: IntakeContext,
        payload: dict[str, Any],
        text: str,
    ) -> IntakeResponse:
        location = _optional_text(text)
        payload.update({"state": IntakeState.WAITING_SUPPORT.value, "location": location})
        client_id = await _ensure_client(uow, context, location)
        ticket = await _create_ticket(uow, client_id, context.telegram_chat_id, payload)
        sessions.bind_client(session, client_id)
        sessions.bind_ticket(session, ticket.id)
        session.state = IntakeState.WAITING_SUPPORT.value
        payload["ticket_id"] = ticket.id
        payload["ticket_public_id"] = ticket.public_id
        _store_intake_payload(session, payload)

        summary = _format_ticket_summary(ticket.public_id, context, payload)
        await uow.messages.create(
            TicketMessageCreate(
                ticket_id=ticket.id,
                sender_type=MessageSenderType.CLIENT,
                sender_id=client_id,
                text=summary,
            )
        )
        await uow.events.create(
            TicketEventCreate(
                ticket_id=ticket.id,
                event_type=TicketEventType.RUNBOOK_STEP_COMPLETED,
                payload_json={"intake": payload},
            )
        )
        if self._support_desk is not None:
            await self._create_support_desk_thread(
                uow,
                ticket=ticket,
                context=context,
                payload=payload,
                summary=summary,
            )
        else:
            await self._notify_support_group(
                uow,
                ticket_id=ticket.id,
                client_chat_id=context.telegram_chat_id,
                summary=summary,
            )
        return IntakeResponse(
            text=_format_created_ticket_response(ticket.public_id, payload),
            ticket_public_id=ticket.public_id,
        )

    async def _handle_waiting_support(
        self,
        uow: SupportUnitOfWork,
        session: SupportSession,
        context: IntakeContext,
        text: str,
    ) -> IntakeResponse:
        if session.ticket_id is None:
            return IntakeResponse(text="Обращение уже передано специалисту.")
        ticket = await uow.tickets.get(session.ticket_id)
        public_id = ticket.public_id if ticket is not None else session.ticket_id
        if ticket is not None and ticket.status in {
            TicketStatus.CLOSED.value,
            TicketStatus.RESOLVED.value,
        }:
            return IntakeResponse(
                text=f"Обращение {public_id} уже закрыто. Чтобы создать новое, нажмите /start.",
                ticket_public_id=public_id,
            )
        await uow.messages.create(
            TicketMessageCreate(
                ticket_id=session.ticket_id,
                sender_type=MessageSenderType.CLIENT,
                sender_id=session.client_id,
                text=text,
            )
        )
        if self._support_desk is not None:
            await self._send_customer_reply_to_support_desk(
                uow,
                ticket_id=session.ticket_id,
                public_id=public_id,
                text=text,
            )
        else:
            await self._notify_support_group_about_client_reply(
                uow,
                ticket_id=session.ticket_id,
                public_id=public_id,
                text=text,
            )
        return IntakeResponse(
            text="",
            ticket_public_id=public_id,
            should_reply=False,
        )

    async def _notify_support_group(
        self,
        uow: SupportUnitOfWork,
        *,
        ticket_id: str,
        client_chat_id: str,
        summary: str,
    ) -> None:
        if self._notifier is None:
            return
        try:
            sent = await self._notifier.notify_ticket_created(ticket_id, summary)
            if sent is not None:
                await uow.message_routings.create(
                    MessageRoutingCreate(
                        ticket_id=ticket_id,
                        client_chat_id=client_chat_id,
                        support_group_message_id=sent.message_id,
                        support_thread_id=sent.message_thread_id,
                    )
                )
        except Exception as exc:
            await uow.events.create(
                TicketEventCreate(
                    ticket_id=ticket_id,
                    event_type=TicketEventType.SUPPORT_GROUP_SEND_FAILED,
                    payload_json={"error": exc.__class__.__name__},
                )
            )

    async def _create_support_desk_thread(
        self,
        uow: SupportUnitOfWork,
        *,
        ticket: Ticket,
        context: IntakeContext,
        payload: dict[str, Any],
        summary: str,
    ) -> None:
        if self._support_desk is None:
            return
        metadata = _support_desk_metadata(ticket, context, payload)
        try:
            ref_payload = await self._support_desk.create_ticket_thread(
                ticket_public_id=ticket.public_id,
                customer_name=context.display_name,
                customer_channel="telegram",
                summary=summary,
                metadata=metadata,
            )
            external_system = str(ref_payload.get("external_system", "chatwoot"))
            await uow.external_refs.create_or_update_external_ref(
                TicketExternalRefCreate(
                    ticket_id=ticket.id,
                    external_system=external_system,
                    external_contact_id=_optional_ref(ref_payload.get("external_contact_id")),
                    external_conversation_id=_optional_ref(
                        ref_payload.get("external_conversation_id")
                    ),
                    external_url=_optional_ref(ref_payload.get("external_url")),
                    metadata_json=_metadata_ref(ref_payload.get("metadata")),
                )
            )
            await uow.events.create(
                TicketEventCreate(
                    ticket_id=ticket.id,
                    event_type=TicketEventType.CHATWOOT_THREAD_CREATED,
                    payload_json={
                        "external_system": external_system,
                        "external_conversation_id": _optional_ref(
                            ref_payload.get("external_conversation_id")
                        ),
                    },
                )
            )
        except Exception as exc:
            await uow.events.create(
                TicketEventCreate(
                    ticket_id=ticket.id,
                    event_type=TicketEventType.CHATWOOT_THREAD_CREATE_FAILED,
                    payload_json=_support_desk_failure_payload(
                        exc,
                        ticket_public_id=ticket.public_id,
                    ),
                )
            )

    async def _notify_support_group_about_client_reply(
        self,
        uow: SupportUnitOfWork,
        *,
        ticket_id: str,
        public_id: str,
        text: str,
    ) -> None:
        if self._notifier is None:
            return
        routing = await uow.message_routings.get_by_ticket_id(ticket_id)
        if routing is None:
            return
        try:
            await self._notifier.notify_client_reply(
                public_id=public_id,
                text=text,
                reply_to_message_id=routing.support_group_message_id,
                message_thread_id=routing.support_thread_id,
            )
        except Exception as exc:
            await uow.events.create(
                TicketEventCreate(
                    ticket_id=ticket_id,
                    event_type=TicketEventType.SUPPORT_GROUP_SEND_FAILED,
                    payload_json={"error": exc.__class__.__name__, "phase": "client_reply"},
                )
            )

    async def _send_customer_reply_to_support_desk(
        self,
        uow: SupportUnitOfWork,
        *,
        ticket_id: str,
        public_id: str,
        text: str,
    ) -> None:
        if self._support_desk is None:
            return
        ref = await uow.external_refs.get_by_ticket_and_system(ticket_id, CHATWOOT_EXTERNAL_SYSTEM)
        if ref is None or not ref.external_conversation_id:
            return
        try:
            await self._support_desk.send_customer_message(
                external_conversation_id=ref.external_conversation_id,
                text=text,
                metadata={
                    "ticket_id": ticket_id,
                    "ticket_public_id": public_id,
                },
            )
            await uow.events.create(
                TicketEventCreate(
                    ticket_id=ticket_id,
                    event_type=TicketEventType.CHATWOOT_CUSTOMER_MESSAGE_SENT,
                    payload_json={
                        "external_conversation_id": ref.external_conversation_id,
                    },
                )
            )
        except Exception as exc:
            await uow.events.create(
                TicketEventCreate(
                    ticket_id=ticket_id,
                    event_type=TicketEventType.CHATWOOT_CUSTOMER_MESSAGE_SEND_FAILED,
                    payload_json={
                        "error": exc.__class__.__name__,
                        "external_conversation_id": ref.external_conversation_id,
                    },
                )
            )


def _classification_payload(classification: IssueClassification) -> dict[str, object]:
    return {
        "issue_type": classification.issue_type.value,
        "confidence": classification.confidence.value,
        "matched_keywords": list(classification.matched_keywords),
    }


def issue_type_human_title(issue_type: IssueType | str) -> str:
    try:
        normalized = IssueType(str(issue_type))
    except ValueError:
        normalized = IssueType.OTHER
    titles = {
        IssueType.SCANNER_NOT_WORKING: "Не работает сканер",
        IssueType.RELEASE_NOT_DISPLAYED: "Не отображается выпуск",
        IssueType.TIMESHEET_SHIFT_OPEN_FAILED: "Не могу открыть табельную смену",
        IssueType.CASH_SHIFT_OPEN_FAILED: "Не могу открыть кассовую смену",
        IssueType.RECEIPTS_NOT_PRINTING: "Не выходят чеки",
        IssueType.TERMINAL_NOT_WORKING: "Не работает терминал",
        IssueType.OTHER: "Другая проблема",
    }
    return titles.get(normalized, titles[IssueType.OTHER])


def _load_intake_payload(session: SupportSession) -> dict[str, Any]:
    for item in reversed(session.history_json):
        if isinstance(item, dict) and item.get("kind") == INTAKE_HISTORY_KIND:
            return dict(item)
    return {"kind": INTAKE_HISTORY_KIND, "state": IntakeState.AWAITING_PROBLEM.value}


def _store_intake_payload(session: SupportSession, payload: dict[str, Any]) -> None:
    stored = {"kind": INTAKE_HISTORY_KIND, **payload}
    session.history_json = [
        item
        for item in session.history_json
        if not (isinstance(item, dict) and item.get("kind") == INTAKE_HISTORY_KIND)
    ]
    session.history_json.append(stored)


def _clarification_question(issue_type: IssueType) -> str:
    questions = {
        IssueType.SCANNER_NOT_WORKING: (
            "Сканер совсем не реагирует или сканирует, но данные не появляются?"
        ),
        IssueType.RELEASE_NOT_DISPLAYED: (
            "Выпуск не отображается полностью или отображается не весь список?"
        ),
        IssueType.TIMESHEET_SHIFT_OPEN_FAILED: (
            "При открытии табельной смены появляется ошибка? Если да — напишите текст ошибки."
        ),
        IssueType.CASH_SHIFT_OPEN_FAILED: (
            "При открытии кассовой смены появляется ошибка? Если да — напишите текст ошибки."
        ),
        IssueType.RECEIPTS_NOT_PRINTING: "Чеки не выходят совсем или печатаются с ошибкой/пустые?",
        IssueType.TERMINAL_NOT_WORKING: "Терминал не включается, нет связи или не проходит оплата?",
        IssueType.OTHER: "Опишите, что происходит, и на каком шаге возникает проблема.",
    }
    return questions.get(issue_type, questions[IssueType.OTHER])


async def _ensure_client(
    uow: SupportUnitOfWork,
    context: IntakeContext,
    location: str | None,
) -> str:
    client = await uow.clients.get_by_telegram_user_id(context.telegram_user_id)
    if client is not None:
        return client.id
    name = context.display_name or location or f"Telegram user {context.telegram_user_id}"
    client = await uow.clients.create(
        ClientCreate(
            name=name,
            telegram_user_id=context.telegram_user_id,
        )
    )
    return client.id


async def _create_ticket(
    uow: SupportUnitOfWork,
    client_id: str,
    telegram_chat_id: str,
    payload: dict[str, Any],
) -> Ticket:
    issue_type = IssueType(str(payload.get("issue_type", IssueType.OTHER.value)))
    return await uow.tickets.create(
        TicketCreate(
            public_id=_new_public_id(),
            client_id=client_id,
            telegram_chat_id=telegram_chat_id,
            issue_type=issue_type,
            status=TicketStatus.WAITING_SUPPORT,
            priority=_priority_for_issue(issue_type),
            source=TicketSource.TELEGRAM,
        )
    )


def _format_ticket_summary(
    public_id: str,
    context: IntakeContext,
    payload: dict[str, Any],
) -> str:
    classification = payload.get("classification")
    classification_payload = classification if isinstance(classification, dict) else {}
    matched_keywords = classification_payload.get("matched_keywords", [])
    issue_type = str(payload.get("issue_type", IssueType.OTHER.value))
    confidence = classification_payload.get("confidence", "low")
    keywords = ", ".join(str(item) for item in matched_keywords) or "нет"
    return (
        f"Новое обращение {public_id}\n\n"
        f"Категория: {issue_type_human_title(issue_type)}\n"
        "Канал: Telegram\n"
        f"Клиент: {_format_optional(context.display_name)}\n"
        f"Telegram user id: {context.telegram_user_id}\n"
        f"Telegram chat id: {context.telegram_chat_id}\n"
        f"Точка: {_format_optional(payload.get('location'))}\n"
        f"Описание: {payload.get('original_problem_text', '')}\n"
        f"Уточнение: {payload.get('clarification_answer', '')}\n"
        f"Классификация: {issue_type}, confidence={confidence}\n"
        f"Ключевые слова: {keywords}"
    )


def _format_created_ticket_response(public_id: str, payload: dict[str, Any]) -> str:
    issue_type = str(payload.get("issue_type", IssueType.OTHER.value))
    location = _format_optional(payload.get("location"))
    return (
        "Обращение создано.\n"
        f"Номер: {public_id}\n"
        f"Категория: {issue_type_human_title(issue_type)}\n"
        f"Точка: {location}\n\n"
        "Специалист скоро подключится."
    )


def _priority_for_issue(issue_type: IssueType) -> TicketPriority:
    mapping = {
        IssueType.TERMINAL_NOT_WORKING: TicketPriority.P2,
        IssueType.CASH_SHIFT_OPEN_FAILED: TicketPriority.P2,
        IssueType.RECEIPTS_NOT_PRINTING: TicketPriority.P2,
        IssueType.SCANNER_NOT_WORKING: TicketPriority.P3,
        IssueType.RELEASE_NOT_DISPLAYED: TicketPriority.P3,
        IssueType.TIMESHEET_SHIFT_OPEN_FAILED: TicketPriority.P3,
        IssueType.OTHER: TicketPriority.P4,
    }
    return mapping.get(issue_type, TicketPriority.P4)


def _optional_text(value: str) -> str | None:
    clean = value.strip()
    if clean.casefold() in {"", "не знаю", "skip", "пропустить"}:
        return None
    return clean


def _format_optional(value: object) -> str:
    return str(value) if value else "unknown"


def _support_desk_metadata(
    ticket: Ticket,
    context: IntakeContext,
    payload: dict[str, Any],
) -> dict[str, object]:
    return {
        "ticket_id": ticket.id,
        "ticket_public_id": ticket.public_id,
        "issue_type": ticket.issue_type,
        "priority": ticket.priority,
        "location": _format_optional(payload.get("location")),
        "telegram_user_id": context.telegram_user_id,
        "telegram_chat_id": context.telegram_chat_id,
        "customer_display_name": context.display_name or "",
        "customer_channel": "telegram",
    }


def _support_desk_failure_payload(exc: Exception, *, ticket_public_id: str) -> dict[str, object]:
    if isinstance(exc, ChatwootApiError):
        return exc.event_payload(ticket_public_id=ticket_public_id)
    return {"error": exc.__class__.__name__, "ticket_public_id": ticket_public_id}


def _optional_ref(value: object) -> str | None:
    return value if isinstance(value, str) and value else None


def _metadata_ref(value: object) -> dict[str, object]:
    if not isinstance(value, dict):
        return {}
    return {str(key): item for key, item in value.items()}


def _new_public_id() -> str:
    return f"SUP-{uuid4().hex[:8].upper()}"
