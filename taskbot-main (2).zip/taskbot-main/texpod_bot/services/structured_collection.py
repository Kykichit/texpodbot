from dataclasses import dataclass, field, replace
from enum import StrEnum
from typing import Any, TypeGuard

from texpod_bot.domain.enums import IssueType
from texpod_bot.services.tickets import PriorityDecisionInput

UNKNOWN_ANSWER = "Не знаю"
SKIP_ANSWERS = frozenset({"", "-", "skip", "пропустить", UNKNOWN_ANSWER.casefold()})


class CollectionValidationError(ValueError):
    """Raised when a collection answer cannot be accepted."""


class CollectionField(StrEnum):
    CLIENT_NAME = "client_name"
    LOCATION = "location"
    PROBLEM_STARTED_AT = "problem_started_at"
    AFFECTED_SCOPE = "affected_scope"
    BUSINESS_BLOCKED = "business_blocked"
    DEVICE_ID = "device_id"
    APP_VERSION = "app_version"
    MEDIA = "screenshot_or_video"
    DESCRIPTION = "free_text_description"
    COMPLETE = "complete"


class AffectedScope(StrEnum):
    ONE_DEVICE = "one_device"
    ALL_DEVICES = "all_devices"
    UNKNOWN = "unknown"


class BusinessBlocked(StrEnum):
    YES = "yes"
    NO = "no"
    UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class MediaAttachment:
    file_id: str
    file_unique_id: str | None = None
    mime_type: str | None = None
    file_size: int | None = None
    metadata: dict[str, str] = field(default_factory=dict)

    def to_payload(self) -> dict[str, object]:
        return {
            "file_id": self.file_id,
            "file_unique_id": self.file_unique_id,
            "mime_type": self.mime_type,
            "file_size": self.file_size,
            "metadata": self.metadata,
        }


@dataclass(frozen=True, slots=True)
class CollectedTicketData:
    client_name: str | None = None
    location: str | None = None
    issue_type: IssueType = IssueType.UNKNOWN
    problem_started_at: str | None = None
    affected_scope: AffectedScope = AffectedScope.UNKNOWN
    business_blocked: BusinessBlocked = BusinessBlocked.UNKNOWN
    device_id: str | None = None
    app_version: str | None = None
    screenshot_or_video: MediaAttachment | None = None
    free_text_description: str | None = None


@dataclass(frozen=True, slots=True)
class CollectionSession:
    data: CollectedTicketData
    current_field: CollectionField = CollectionField.CLIENT_NAME

    @property
    def complete(self) -> bool:
        return self.current_field == CollectionField.COMPLETE


@dataclass(frozen=True, slots=True)
class CollectionAnswer:
    text: str | None = None
    attachment: MediaAttachment | None = None


@dataclass(frozen=True, slots=True)
class CollectionResult:
    session: CollectionSession
    prompt: str
    complete: bool = False


def start_collection(issue_type: IssueType) -> CollectionResult:
    session = CollectionSession(
        data=CollectedTicketData(issue_type=issue_type),
        current_field=CollectionField.CLIENT_NAME,
    )
    return CollectionResult(session=session, prompt=prompt_for_field(session.current_field))


def start_collection_with_media(
    issue_type: IssueType,
    attachment: MediaAttachment,
) -> CollectionResult:
    session = CollectionSession(
        data=CollectedTicketData(issue_type=issue_type, screenshot_or_video=attachment),
        current_field=CollectionField.CLIENT_NAME,
    )
    return CollectionResult(session=session, prompt=prompt_for_field(session.current_field))


def current_question(session: CollectionSession) -> str:
    return prompt_for_field(session.current_field)


def answer_collection(session: CollectionSession, answer: CollectionAnswer) -> CollectionResult:
    if session.complete:
        return CollectionResult(
            session=session,
            prompt=prompt_for_field(CollectionField.COMPLETE),
            complete=True,
        )

    data = _apply_answer(session.data, session.current_field, answer)
    next_field = _next_field(session.current_field)
    next_session = CollectionSession(data=data, current_field=next_field)
    if next_field == CollectionField.COMPLETE:
        return CollectionResult(
            session=next_session,
            prompt=prompt_for_field(CollectionField.COMPLETE),
            complete=True,
        )
    return CollectionResult(
        session=next_session,
        prompt=prompt_for_field(next_field),
        complete=False,
    )


def prompt_for_field(field: CollectionField) -> str:
    prompts = {
        CollectionField.CLIENT_NAME: "Укажите название компании или клиента.",
        CollectionField.LOCATION: ("Укажите филиал или точку. Можно ответить: не знаю."),
        CollectionField.PROBLEM_STARTED_AT: "Когда началась проблема?",
        CollectionField.AFFECTED_SCOPE: ("Проблема на одном устройстве или на всех?"),
        CollectionField.BUSINESS_BLOCKED: (
            "Работа точки сейчас остановлена? Ответьте: да, нет или не знаю."
        ),
        CollectionField.DEVICE_ID: ("Укажите device_id. Если не знаете, ответьте: не знаю."),
        CollectionField.APP_VERSION: (
            "Укажите версию приложения. Если не знаете, ответьте: не знаю."
        ),
        CollectionField.MEDIA: "Пришлите фото или видео ошибки. Если нет, напишите: не знаю.",
        CollectionField.DESCRIPTION: "Опишите проблему своими словами.",
        CollectionField.COMPLETE: "Данные собраны. Передаю обращение оператору.",
    }
    return prompts[field]


def format_client_summary(data: CollectedTicketData) -> str:
    return (
        "Данные собраны. Передаю обращение оператору.\n\n"
        f"Клиент: {_format_optional(data.client_name)}\n"
        f"Проблема: {data.issue_type.value}\n"
        f"Когда началась: {_format_optional(data.problem_started_at)}\n"
        f"Масштаб: {data.affected_scope.value}\n"
        f"Работа остановлена: {data.business_blocked.value}"
    )


def format_support_summary(data: CollectedTicketData) -> str:
    media = data.screenshot_or_video.file_id if data.screenshot_or_video else "not provided"
    return (
        "Structured data:\n"
        f"- client_name: {_format_optional(data.client_name)}\n"
        f"- location: {_format_optional(data.location)}\n"
        f"- issue_type: {data.issue_type.value}\n"
        f"- problem_started_at: {_format_optional(data.problem_started_at)}\n"
        f"- affected_scope: {data.affected_scope.value}\n"
        f"- business_blocked: {data.business_blocked.value}\n"
        f"- device_id: {_format_optional(data.device_id)}\n"
        f"- app_version: {_format_optional(data.app_version)}\n"
        f"- screenshot_or_video: {media}\n"
        f"- free_text_description: {_format_optional(data.free_text_description)}"
    )


def format_collection_summary(data: CollectedTicketData) -> str:
    return format_support_summary(data)


def priority_input_from_collection(data: CollectedTicketData) -> PriorityDecisionInput:
    affected_scope = (
        "multiple_devices" if data.affected_scope == AffectedScope.ALL_DEVICES else "single_device"
    )
    return PriorityDecisionInput(
        affected_scope=affected_scope,
        business_blocked=data.business_blocked == BusinessBlocked.YES,
    )


def collection_event_payload(session: CollectionSession) -> dict[str, object]:
    if not session.complete:
        msg = "Collection is incomplete and cannot produce a final event payload"
        raise CollectionValidationError(msg)
    raw_data = collection_to_json(session)["data"]
    if not _is_object_dict(raw_data):
        msg = "Collection payload data must be an object"
        raise CollectionValidationError(msg)
    return raw_data


def collection_to_json(session: CollectionSession) -> dict[str, Any]:
    media = session.data.screenshot_or_video
    return {
        "kind": "collection",
        "current_field": session.current_field.value,
        "data": {
            "client_name": session.data.client_name,
            "location": session.data.location,
            "issue_type": session.data.issue_type.value,
            "problem_started_at": session.data.problem_started_at,
            "affected_scope": session.data.affected_scope.value,
            "business_blocked": session.data.business_blocked.value,
            "device_id": session.data.device_id,
            "app_version": session.data.app_version,
            "screenshot_or_video": media.to_payload() if media else None,
            "free_text_description": session.data.free_text_description,
        },
    }


def collection_from_json(raw: dict[str, Any]) -> CollectionSession:
    raw_data = raw.get("data")
    if not isinstance(raw_data, dict):
        msg = "collection data must be an object"
        raise ValueError(msg)
    raw_media = raw_data.get("screenshot_or_video")
    media = _media_from_raw(raw_media)
    return CollectionSession(
        data=CollectedTicketData(
            client_name=_optional_str(raw_data.get("client_name")),
            location=_optional_str(raw_data.get("location")),
            issue_type=IssueType(str(raw_data.get("issue_type", IssueType.UNKNOWN.value))),
            problem_started_at=_optional_str(raw_data.get("problem_started_at")),
            affected_scope=AffectedScope(str(raw_data.get("affected_scope", "unknown"))),
            business_blocked=BusinessBlocked(str(raw_data.get("business_blocked", "unknown"))),
            device_id=_optional_str(raw_data.get("device_id")),
            app_version=_optional_str(raw_data.get("app_version")),
            screenshot_or_video=media,
            free_text_description=_optional_str(raw_data.get("free_text_description")),
        ),
        current_field=CollectionField(str(raw.get("current_field", CollectionField.CLIENT_NAME))),
    )


def _apply_answer(
    data: CollectedTicketData,
    field: CollectionField,
    answer: CollectionAnswer,
) -> CollectedTicketData:
    value = _clean_optional(answer.text)
    media = answer.attachment
    if field == CollectionField.CLIENT_NAME:
        return replace(data, client_name=_require_text(value, field))
    if field == CollectionField.LOCATION:
        return replace(data, location=value)
    if field == CollectionField.PROBLEM_STARTED_AT:
        return replace(data, problem_started_at=_require_text(value, field))
    if field == CollectionField.AFFECTED_SCOPE:
        return replace(data, affected_scope=_normalize_affected_scope(answer.text))
    if field == CollectionField.BUSINESS_BLOCKED:
        return replace(data, business_blocked=_normalize_business_blocked(answer.text))
    if field == CollectionField.DEVICE_ID:
        return replace(data, device_id=value)
    if field == CollectionField.APP_VERSION:
        return replace(data, app_version=value)
    if field == CollectionField.MEDIA:
        if media is None:
            _ensure_skip(answer.text, field)
            return data
        return replace(data, screenshot_or_video=media)
    if field == CollectionField.DESCRIPTION:
        return replace(data, free_text_description=_require_text(value, field))
    return data


def _next_field(field: CollectionField) -> CollectionField:
    fields = list(CollectionField)
    index = fields.index(field)
    return fields[index + 1]


def _clean_optional(value: str | None) -> str | None:
    if value is None:
        return None
    clean = value.strip()
    if clean.casefold() in SKIP_ANSWERS:
        return None
    return clean


def _require_text(value: str | None, field: CollectionField) -> str:
    if value is None:
        msg = f"{field.value} is required"
        raise CollectionValidationError(msg)
    return value


def _ensure_skip(value: str | None, field: CollectionField) -> None:
    clean = (value or "").strip().casefold()
    if clean in SKIP_ANSWERS:
        return
    msg = f"{field.value} expects media attachment or skip answer"
    raise CollectionValidationError(msg)


def _normalize_affected_scope(value: str | None) -> AffectedScope:
    clean = (value or "").strip().casefold()
    if clean in {
        "one_device",
        "single_device",
        "one",
        "один",
        "одно",
        "одно устройство",
        "на одном",
        "1",
    }:
        return AffectedScope.ONE_DEVICE
    if clean in {
        "all_devices",
        "all",
        "все",
        "все устройства",
        "на всех",
        "all devices",
    }:
        return AffectedScope.ALL_DEVICES
    if clean in {"unknown", "неизвестно", "не знаю", UNKNOWN_ANSWER.casefold()}:
        return AffectedScope.UNKNOWN
    msg = "affected_scope must be one_device, all_devices, or unknown"
    raise CollectionValidationError(msg)


def _normalize_business_blocked(value: str | None) -> BusinessBlocked:
    clean = (value or "").strip().casefold()
    if clean in {"yes", "y", "да", "true"}:
        return BusinessBlocked.YES
    if clean in {"no", "n", "нет", "false"}:
        return BusinessBlocked.NO
    if clean in {"unknown", "неизвестно", "не знаю", UNKNOWN_ANSWER.casefold()}:
        return BusinessBlocked.UNKNOWN
    msg = "business_blocked must be yes, no, or unknown"
    raise CollectionValidationError(msg)


def _format_optional(value: str | None) -> str:
    return value if value else "unknown"


def _optional_str(value: object) -> str | None:
    return value if isinstance(value, str) else None


def _optional_int(value: object) -> int | None:
    return value if isinstance(value, int) else None


def _media_from_raw(value: object) -> MediaAttachment | None:
    if not isinstance(value, dict) or not isinstance(value.get("file_id"), str):
        return None
    metadata = value.get("metadata")
    return MediaAttachment(
        file_id=value["file_id"],
        file_unique_id=_optional_str(value.get("file_unique_id")),
        mime_type=_optional_str(value.get("mime_type")),
        file_size=_optional_int(value.get("file_size")),
        metadata=metadata if _is_str_dict(metadata) else {},
    )


def _is_str_dict(value: object) -> TypeGuard[dict[str, str]]:
    return isinstance(value, dict) and all(
        isinstance(key, str) and isinstance(item, str) for key, item in value.items()
    )


def _is_object_dict(value: object) -> TypeGuard[dict[str, object]]:
    return isinstance(value, dict) and all(isinstance(key, str) for key in value)
