from dataclasses import dataclass
from datetime import UTC, datetime
from uuid import uuid4

from texpod_bot.domain.enums import (
    IssueType,
    MessageSenderType,
    TicketEventType,
    TicketPriority,
    TicketSource,
    TicketStatus,
)
from texpod_bot.domain.events import (
    MessageAddedPayload,
    TicketStatusChangedPayload,
    TicketTimestampPayload,
)
from texpod_bot.domain.runbooks import RunbookSession
from texpod_bot.domain.schemas import TicketCreate, TicketEventCreate, TicketMessageCreate
from texpod_bot.infrastructure.database.models import Ticket, TicketEvent, TicketMessage
from texpod_bot.infrastructure.repositories import SupportUnitOfWork


class TicketServiceError(RuntimeError):
    """Base ticket service error."""


class TicketNotFoundError(TicketServiceError):
    """Raised when a ticket does not exist."""


class TicketTransitionError(TicketServiceError):
    """Raised when a status transition is not allowed."""


@dataclass(frozen=True, slots=True)
class PriorityDecisionInput:
    affected_scope: str
    business_blocked: bool = False
    has_workaround: bool = False
    is_question: bool = False


@dataclass(frozen=True, slots=True)
class TicketTimeline:
    ticket: Ticket
    messages: list[TicketMessage]
    events: list[TicketEvent]


class TicketService:
    def __init__(self, uow: SupportUnitOfWork) -> None:
        self._uow = uow

    async def create_ticket_from_runbook_session(
        self,
        *,
        client_id: str,
        telegram_chat_id: str,
        runbook_session: RunbookSession,
        priority_input: PriorityDecisionInput,
        device_id: str | None = None,
        issue_type: IssueType = IssueType.UNKNOWN,
        source: TicketSource = TicketSource.TELEGRAM,
    ) -> Ticket:
        ticket = await self._uow.tickets.create(
            TicketCreate(
                public_id=_new_public_id(),
                client_id=client_id,
                device_id=device_id,
                telegram_chat_id=telegram_chat_id,
                issue_type=issue_type,
                status=TicketStatus.RUNBOOK_IN_PROGRESS,
                priority=decide_priority(priority_input),
                source=source,
            )
        )
        await self.add_event(
            ticket.id,
            TicketEventType.CREATED,
            {
                "runbook_code": runbook_session.runbook_code,
                "current_step_key": runbook_session.current_step_key,
                "runbook_action": runbook_session.action,
            },
        )
        await self.add_event(
            ticket.id,
            TicketEventType.RUNBOOK_STARTED,
            {
                "runbook_code": runbook_session.runbook_code,
                "history": [
                    {
                        "step_key": item.step_key,
                        "selected_option": item.selected_option,
                        "next_step": item.next_step,
                        "action": item.action,
                    }
                    for item in runbook_session.history
                ],
            },
        )
        await self._uow.commit()
        return ticket

    async def add_message(
        self,
        ticket_id: str,
        *,
        sender_type: MessageSenderType,
        sender_id: str | None = None,
        text: str | None = None,
        attachment_url: str | None = None,
        telegram_message_id: str | None = None,
    ) -> TicketMessage:
        ticket = await self._require_ticket(ticket_id)
        message = await self._uow.messages.create(
            TicketMessageCreate(
                ticket_id=ticket_id,
                sender_type=sender_type,
                sender_id=sender_id,
                text=text,
                attachment_url=attachment_url,
                telegram_message_id=telegram_message_id,
            )
        )
        await self.add_event(
            ticket_id,
            TicketEventType.MESSAGE_ADDED,
            MessageAddedPayload(
                sender_type=sender_type,
                has_attachment=attachment_url is not None,
            ).as_json(),
        )
        if sender_type == MessageSenderType.SUPPORT:
            await self._record_first_response(ticket, sender_id)
        await self._uow.commit()
        return message

    async def add_event(
        self,
        ticket_id: str,
        event_type: TicketEventType,
        payload: dict[str, object] | None = None,
    ) -> TicketEvent:
        await self._require_ticket(ticket_id)
        event = await self._uow.events.create(
            TicketEventCreate(
                ticket_id=ticket_id,
                event_type=event_type,
                payload_json=payload or {},
            )
        )
        await self._uow.session.flush()
        return event

    async def assign_operator(self, ticket_id: str, operator_id: str) -> Ticket:
        ticket = await self.change_status(ticket_id, TicketStatus.ASSIGNED)
        ticket.assigned_to = operator_id
        await self.add_event(ticket.id, TicketEventType.ASSIGNED, {"operator_id": operator_id})
        await self._uow.commit()
        return ticket

    async def change_status(
        self,
        ticket_id: str,
        status: TicketStatus,
        *,
        reason: str | None = None,
    ) -> Ticket:
        ticket = await self._require_ticket(ticket_id)
        current = TicketStatus(ticket.status)
        _validate_transition(current, status)
        now = datetime.now(UTC)
        ticket.status = status.value
        if status == TicketStatus.RESOLVED:
            ticket.resolved_at = now
        elif status == TicketStatus.CLOSED:
            ticket.closed_at = now
        elif status == TicketStatus.REOPENED:
            ticket.reopened_at = now
        if status == TicketStatus.RESOLVED:
            await self.add_event(
                ticket.id,
                TicketEventType.RESOLVED,
                TicketStatusChangedPayload(current, status, reason).as_json(),
            )
        elif status == TicketStatus.REOPENED:
            await self.add_event(
                ticket.id,
                TicketEventType.REOPENED,
                TicketStatusChangedPayload(current, status, reason).as_json(),
            )
        elif status == TicketStatus.CANCELLED:
            await self.add_event(
                ticket.id,
                TicketEventType.CANCELLED,
                TicketStatusChangedPayload(current, status, reason).as_json(),
            )
        elif status == TicketStatus.DEV_NEEDED:
            await self.add_event(
                ticket.id,
                TicketEventType.DEV_NEEDED,
                TicketStatusChangedPayload(current, status, reason).as_json(),
            )
        else:
            await self.add_event(
                ticket.id,
                TicketEventType.STATUS_CHANGED,
                TicketStatusChangedPayload(current, status, reason).as_json(),
            )
        await self._uow.commit()
        return ticket

    async def close_ticket(self, ticket_id: str, *, reason: str | None = None) -> Ticket:
        ticket = await self.change_status(ticket_id, TicketStatus.CLOSED, reason=reason)
        await self.add_event(
            ticket.id,
            TicketEventType.CLOSED,
            {
                "closed_at": ticket.closed_at.isoformat() if ticket.closed_at else None,
                "reason": reason,
            },
        )
        await self._uow.commit()
        return ticket

    async def escalate_ticket(self, ticket_id: str) -> Ticket:
        ticket = await self.change_status(ticket_id, TicketStatus.WAITING_SUPPORT)
        await self.add_event(ticket.id, TicketEventType.ESCALATED, {"status": ticket.status})
        await self._uow.commit()
        return ticket

    async def list_open_tickets(self, client_id: str | None = None) -> list[Ticket]:
        if client_id is None:
            return await self._uow.tickets.list_open()
        return await self._uow.tickets.list_open_for_client(client_id)

    async def get_ticket_timeline(self, ticket_id: str) -> TicketTimeline:
        ticket = await self._require_ticket(ticket_id)
        messages = await self._uow.messages.list_for_ticket(ticket_id)
        events = await self._uow.events.list_for_ticket(ticket_id)
        return TicketTimeline(ticket=ticket, messages=messages, events=events)

    async def reopen_ticket(self, ticket_id: str, *, reason: str | None = None) -> Ticket:
        return await self.change_status(ticket_id, TicketStatus.REOPENED, reason=reason)

    async def cancel_ticket(self, ticket_id: str, *, reason: str | None = None) -> Ticket:
        return await self.change_status(ticket_id, TicketStatus.CANCELLED, reason=reason)

    async def _require_ticket(self, ticket_id: str) -> Ticket:
        ticket = await self._uow.tickets.get(ticket_id)
        if ticket is None:
            msg = f"Ticket {ticket_id!r} was not found"
            raise TicketNotFoundError(msg)
        return ticket

    async def _record_first_response(self, ticket: Ticket, actor_id: str | None) -> None:
        if ticket.first_response_at is not None:
            return
        ticket.first_response_at = datetime.now(UTC)
        await self.add_event(
            ticket.id,
            TicketEventType.FIRST_RESPONSE_RECORDED,
            TicketTimestampPayload(ticket.first_response_at, actor_id=actor_id).as_json(),
        )


def decide_priority(data: PriorityDecisionInput) -> TicketPriority:
    if data.affected_scope in {"multiple_devices", "multiple_clients"}:
        return TicketPriority.P1
    if data.business_blocked:
        return TicketPriority.P2
    if data.has_workaround:
        return TicketPriority.P3
    if data.is_question:
        return TicketPriority.P4
    return TicketPriority.P3


def _validate_transition(current: TicketStatus, target: TicketStatus) -> None:
    if current == target:
        return
    allowed = _ALLOWED_TRANSITIONS.get(current, set())
    if target not in allowed:
        msg = f"Cannot transition ticket from {current.value!r} to {target.value!r}"
        raise TicketTransitionError(msg)


def _new_public_id() -> str:
    return f"SUP-{uuid4().hex[:8].upper()}"


_ALLOWED_TRANSITIONS: dict[TicketStatus, set[TicketStatus]] = {
    TicketStatus.NEW: {
        TicketStatus.COLLECTING_DATA,
        TicketStatus.OPEN,
        TicketStatus.RUNBOOK_IN_PROGRESS,
        TicketStatus.WAITING_CLIENT,
        TicketStatus.WAITING_CUSTOMER,
        TicketStatus.WAITING_SUPPORT,
        TicketStatus.ASSIGNED,
        TicketStatus.CANCELLED,
        TicketStatus.CLOSED,
    },
    TicketStatus.COLLECTING_DATA: {
        TicketStatus.OPEN,
        TicketStatus.WAITING_CLIENT,
        TicketStatus.WAITING_CUSTOMER,
        TicketStatus.WAITING_SUPPORT,
        TicketStatus.ASSIGNED,
        TicketStatus.RESOLVED,
        TicketStatus.CANCELLED,
        TicketStatus.CLOSED,
    },
    TicketStatus.OPEN: {
        TicketStatus.WAITING_CLIENT,
        TicketStatus.WAITING_CUSTOMER,
        TicketStatus.WAITING_SUPPORT,
        TicketStatus.ASSIGNED,
        TicketStatus.DEV_NEEDED,
        TicketStatus.RESOLVED,
        TicketStatus.CANCELLED,
        TicketStatus.CLOSED,
    },
    TicketStatus.RUNBOOK_IN_PROGRESS: {
        TicketStatus.COLLECTING_DATA,
        TicketStatus.OPEN,
        TicketStatus.WAITING_CLIENT,
        TicketStatus.WAITING_CUSTOMER,
        TicketStatus.WAITING_SUPPORT,
        TicketStatus.ASSIGNED,
        TicketStatus.DEV_NEEDED,
        TicketStatus.RESOLVED,
        TicketStatus.CANCELLED,
        TicketStatus.CLOSED,
    },
    TicketStatus.WAITING_CLIENT: {
        TicketStatus.RUNBOOK_IN_PROGRESS,
        TicketStatus.OPEN,
        TicketStatus.WAITING_SUPPORT,
        TicketStatus.ASSIGNED,
        TicketStatus.CANCELLED,
        TicketStatus.CLOSED,
    },
    TicketStatus.WAITING_CUSTOMER: {
        TicketStatus.OPEN,
        TicketStatus.WAITING_SUPPORT,
        TicketStatus.ASSIGNED,
        TicketStatus.CANCELLED,
        TicketStatus.CLOSED,
    },
    TicketStatus.WAITING_SUPPORT: {
        TicketStatus.OPEN,
        TicketStatus.ASSIGNED,
        TicketStatus.WAITING_CLIENT,
        TicketStatus.WAITING_CUSTOMER,
        TicketStatus.DEV_NEEDED,
        TicketStatus.RESOLVED,
        TicketStatus.CANCELLED,
        TicketStatus.CLOSED,
    },
    TicketStatus.ASSIGNED: {
        TicketStatus.OPEN,
        TicketStatus.WAITING_CLIENT,
        TicketStatus.WAITING_CUSTOMER,
        TicketStatus.WAITING_SUPPORT,
        TicketStatus.DEV_NEEDED,
        TicketStatus.RESOLVED,
        TicketStatus.CANCELLED,
        TicketStatus.CLOSED,
    },
    TicketStatus.DEV_NEEDED: {
        TicketStatus.OPEN,
        TicketStatus.WAITING_SUPPORT,
        TicketStatus.RESOLVED,
        TicketStatus.CANCELLED,
        TicketStatus.CLOSED,
    },
    TicketStatus.RESOLVED: {
        TicketStatus.CLOSED,
        TicketStatus.REOPENED,
    },
    TicketStatus.REOPENED: {
        TicketStatus.OPEN,
        TicketStatus.WAITING_SUPPORT,
        TicketStatus.ASSIGNED,
        TicketStatus.RESOLVED,
        TicketStatus.CANCELLED,
        TicketStatus.CLOSED,
    },
    TicketStatus.CANCELLED: set(),
    TicketStatus.CLOSED: set(),
}
