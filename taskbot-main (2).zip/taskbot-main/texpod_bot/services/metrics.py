from collections import Counter
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta

from sqlalchemy import select

from texpod_bot.domain.enums import MessageSenderType, TicketEventType, TicketStatus
from texpod_bot.infrastructure.database.models import Ticket, TicketEvent, TicketMessage
from texpod_bot.infrastructure.repositories import SupportUnitOfWork


@dataclass(frozen=True, slots=True)
class MetricsFilter:
    date_from: datetime
    date_to: datetime
    channel: str | None = None
    category: str | None = None
    operator_id: str | None = None
    status: str | None = None

    @classmethod
    def last_days(cls, days: int, *, now: datetime | None = None) -> "MetricsFilter":
        end_at = now or datetime.now(UTC)
        return cls(date_from=end_at - timedelta(days=days), date_to=end_at)


@dataclass(frozen=True, slots=True)
class SupportMetrics:
    tickets_total: int
    tickets_by_status: dict[str, int] = field(default_factory=dict)
    tickets_by_category: dict[str, int] = field(default_factory=dict)
    tickets_by_priority: dict[str, int] = field(default_factory=dict)
    tickets_by_channel: dict[str, int] = field(default_factory=dict)
    new_tickets: int = 0
    open_tickets: int = 0
    closed_tickets: int = 0
    reopened_tickets: int = 0
    escalation_rate: float = 0.0
    runbook_self_resolution_rate: float = 0.0
    average_first_response_seconds: float | None = None
    average_resolution_seconds: float | None = None
    reopen_rate: float = 0.0
    cancelled_or_abandoned: int = 0
    tickets_with_attachments: int = 0
    operator_replies: int = 0
    operator_workload: dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class RunbookMetrics:
    starts: int
    completions: int
    resolved_without_operator: int
    escalated: int
    abandoned: int
    failed: int
    drop_off_by_step: dict[str, int]
    most_selected_options: dict[str, int]


@dataclass(frozen=True, slots=True)
class MetricsSnapshot:
    filters: MetricsFilter
    support: SupportMetrics
    runbooks: RunbookMetrics


class MetricsService:
    def __init__(self, uow: SupportUnitOfWork) -> None:
        self._uow = uow

    async def build_snapshot(self, filters: MetricsFilter) -> MetricsSnapshot:
        tickets = await self._tickets(filters)
        ticket_ids = [ticket.id for ticket in tickets]
        events = await self._events(ticket_ids)
        messages = await self._messages(ticket_ids)
        return MetricsSnapshot(
            filters=filters,
            support=_support_metrics(tickets, events, messages),
            runbooks=_runbook_metrics(events, tickets, messages),
        )

    def format_support_summary(self, snapshot: MetricsSnapshot) -> str:
        support = snapshot.support
        if support.tickets_total == 0:
            return (
                "Статистика поддержки\n"
                f"Период: {_format_period(snapshot.filters)}\n\n"
                "За выбранный период обращений нет."
            )
        return (
            "Статистика поддержки\n"
            f"Период: {_format_period(snapshot.filters)}\n\n"
            f"Всего обращений: {support.tickets_total}\n"
            f"Новые: {support.new_tickets}\n"
            f"Открытые: {support.open_tickets}\n"
            f"Закрытые: {support.closed_tickets}\n"
            f"Переоткрытые: {support.reopened_tickets}\n\n"
            f"По статусам: {_format_counts_inline(support.tickets_by_status)}\n"
            f"По категориям: {_format_counts_inline(support.tickets_by_category)}\n"
            f"По приоритетам: {_format_counts_inline(support.tickets_by_priority)}\n\n"
            f"Эскалации: {_format_percent(support.escalation_rate)}\n"
            f"Решено runbook-ом: {_format_percent(support.runbook_self_resolution_rate)}\n"
            f"Первый ответ: {_format_duration(support.average_first_response_seconds)}\n"
            f"Решение: {_format_duration(support.average_resolution_seconds)}\n"
            f"С вложениями: {support.tickets_with_attachments}\n"
            f"Ответы операторов: {support.operator_replies}\n"
            f"Нагрузка: {_format_counts_inline(support.operator_workload)}"
        )

    async def _tickets(self, filters: MetricsFilter) -> list[Ticket]:
        conditions = [
            Ticket.created_at >= filters.date_from,
            Ticket.created_at < filters.date_to,
        ]
        if filters.channel:
            conditions.append(Ticket.source == filters.channel)
        if filters.category:
            conditions.append(Ticket.issue_type == filters.category)
        if filters.status:
            conditions.append(Ticket.status == filters.status)
        if filters.operator_id:
            conditions.append(Ticket.assigned_to == filters.operator_id)
        result = await self._uow.session.execute(
            select(Ticket).where(*conditions).order_by(Ticket.created_at)
        )
        return list(result.scalars().all())

    async def _events(self, ticket_ids: list[str]) -> list[TicketEvent]:
        if not ticket_ids:
            return []
        result = await self._uow.session.execute(
            select(TicketEvent)
            .where(TicketEvent.ticket_id.in_(ticket_ids))
            .order_by(TicketEvent.created_at)
        )
        return list(result.scalars().all())

    async def _messages(self, ticket_ids: list[str]) -> list[TicketMessage]:
        if not ticket_ids:
            return []
        result = await self._uow.session.execute(
            select(TicketMessage)
            .where(TicketMessage.ticket_id.in_(ticket_ids))
            .order_by(TicketMessage.created_at)
        )
        return list(result.scalars().all())


def _support_metrics(
    tickets: list[Ticket],
    events: list[TicketEvent],
    messages: list[TicketMessage],
) -> SupportMetrics:
    ticket_ids = {ticket.id for ticket in tickets}
    escalated_ids = _ticket_ids_with_event(events, TicketEventType.ESCALATED.value)
    reopened_ids = _ticket_ids_with_event(events, TicketEventType.REOPENED.value)
    resolved_by_runbook_ids = _resolved_without_operator(tickets, events, messages)
    attachment_ticket_ids = {
        message.ticket_id for message in messages if message.attachment_url is not None
    }
    operator_messages = [
        message for message in messages if message.sender_type == MessageSenderType.SUPPORT.value
    ]
    closed_statuses = {TicketStatus.RESOLVED.value, TicketStatus.CLOSED.value}
    open_statuses = {
        TicketStatus.NEW.value,
        TicketStatus.COLLECTING_DATA.value,
        TicketStatus.OPEN.value,
        TicketStatus.RUNBOOK_IN_PROGRESS.value,
        TicketStatus.WAITING_CLIENT.value,
        TicketStatus.WAITING_CUSTOMER.value,
        TicketStatus.WAITING_SUPPORT.value,
        TicketStatus.ASSIGNED.value,
        TicketStatus.DEV_NEEDED.value,
        TicketStatus.REOPENED.value,
    }
    return SupportMetrics(
        tickets_total=len(tickets),
        tickets_by_status=dict(Counter(ticket.status for ticket in tickets)),
        tickets_by_category=dict(Counter(ticket.issue_type for ticket in tickets)),
        tickets_by_priority=dict(Counter(ticket.priority for ticket in tickets)),
        tickets_by_channel=dict(Counter(ticket.source for ticket in tickets)),
        new_tickets=sum(1 for ticket in tickets if ticket.status == TicketStatus.NEW.value),
        open_tickets=sum(1 for ticket in tickets if ticket.status in open_statuses),
        closed_tickets=sum(1 for ticket in tickets if ticket.status in closed_statuses),
        reopened_tickets=len(reopened_ids),
        escalation_rate=_ratio(len(escalated_ids), len(ticket_ids)),
        runbook_self_resolution_rate=_ratio(len(resolved_by_runbook_ids), len(ticket_ids)),
        average_first_response_seconds=_average_first_response_seconds(tickets, messages),
        average_resolution_seconds=_average_resolution_seconds(tickets),
        reopen_rate=_ratio(len(reopened_ids), len(ticket_ids)),
        cancelled_or_abandoned=_cancelled_or_abandoned(tickets, events),
        tickets_with_attachments=len(attachment_ticket_ids),
        operator_replies=len(operator_messages),
        operator_workload=dict(
            Counter(_message_sender_id(message) for message in operator_messages)
        ),
    )


def _runbook_metrics(
    events: list[TicketEvent],
    tickets: list[Ticket],
    messages: list[TicketMessage],
) -> RunbookMetrics:
    starts = [
        event for event in events if event.event_type == TicketEventType.RUNBOOK_STARTED.value
    ]
    resolved = _resolved_without_operator(tickets, events, messages)
    escalated = _ticket_ids_with_event(events, TicketEventType.ESCALATED.value)
    abandoned = [
        event for event in events if event.event_type == TicketEventType.RUNBOOK_ABANDONED.value
    ]
    failed = [event for event in events if event.event_type == TicketEventType.RUNBOOK_FAILED.value]
    return RunbookMetrics(
        starts=len(starts),
        completions=len(resolved) + len(escalated),
        resolved_without_operator=len(resolved),
        escalated=len(escalated),
        abandoned=len(abandoned),
        failed=len(failed),
        drop_off_by_step=_drop_off_by_step(events),
        most_selected_options=_selected_options(events),
    )


def _resolved_without_operator(
    tickets: list[Ticket],
    events: list[TicketEvent],
    messages: list[TicketMessage],
) -> set[str]:
    escalated_ids = _ticket_ids_with_event(events, TicketEventType.ESCALATED.value)
    support_message_ids = {
        message.ticket_id
        for message in messages
        if message.sender_type == MessageSenderType.SUPPORT.value
    }
    return {
        ticket.id
        for ticket in tickets
        if ticket.status in {TicketStatus.RESOLVED.value, TicketStatus.CLOSED.value}
        and ticket.id not in escalated_ids
        and ticket.id not in support_message_ids
    }


def _average_first_response_seconds(
    tickets: list[Ticket],
    messages: list[TicketMessage],
) -> float | None:
    messages_by_ticket = _messages_by_ticket(messages)
    values: list[float] = []
    for ticket in tickets:
        if ticket.first_response_at is not None:
            values.append(_seconds_between(ticket.created_at, ticket.first_response_at))
            continue
        first_support = next(
            (
                message
                for message in messages_by_ticket.get(ticket.id, [])
                if message.sender_type == MessageSenderType.SUPPORT.value
            ),
            None,
        )
        if first_support is not None:
            values.append(_seconds_between(ticket.created_at, first_support.created_at))
    return _average(values)


def _average_resolution_seconds(tickets: list[Ticket]) -> float | None:
    values = []
    for ticket in tickets:
        end_at = ticket.resolved_at or ticket.closed_at
        if end_at is not None:
            values.append(_seconds_between(ticket.created_at, end_at))
    return _average(values)


def _cancelled_or_abandoned(tickets: list[Ticket], events: list[TicketEvent]) -> int:
    cancelled = {ticket.id for ticket in tickets if ticket.status == TicketStatus.CANCELLED.value}
    abandoned = _ticket_ids_with_event(events, TicketEventType.RUNBOOK_ABANDONED.value)
    return len(cancelled | abandoned)


def _drop_off_by_step(events: list[TicketEvent]) -> dict[str, int]:
    counts: Counter[str] = Counter()
    for event in events:
        if event.event_type != TicketEventType.RUNBOOK_ABANDONED.value:
            continue
        step_key = event.payload_json.get("step_key")
        if isinstance(step_key, str):
            counts[step_key] += 1
    return dict(counts)


def _selected_options(events: list[TicketEvent]) -> dict[str, int]:
    counts: Counter[str] = Counter()
    for event in events:
        if event.event_type not in {
            TicketEventType.RUNBOOK_OPTION_SELECTED.value,
            TicketEventType.RUNBOOK_STEP_COMPLETED.value,
        }:
            continue
        selected_option = event.payload_json.get("selected_option")
        if isinstance(selected_option, str):
            counts[selected_option] += 1
    return dict(counts)


def _messages_by_ticket(messages: list[TicketMessage]) -> dict[str, list[TicketMessage]]:
    grouped: dict[str, list[TicketMessage]] = {}
    for message in messages:
        grouped.setdefault(message.ticket_id, []).append(message)
    return grouped


def _ticket_ids_with_event(events: list[TicketEvent], event_type: str) -> set[str]:
    return {event.ticket_id for event in events if event.event_type == event_type}


def _message_sender_id(message: TicketMessage) -> str:
    return message.sender_id or "unknown"


def _seconds_between(start: datetime, end: datetime) -> float:
    return (end - start).total_seconds()


def _average(values: list[float]) -> float | None:
    if not values:
        return None
    return sum(values) / len(values)


def _ratio(numerator: int, denominator: int) -> float:
    if denominator == 0:
        return 0.0
    return numerator / denominator


def _format_percent(value: float) -> str:
    return f"{value * 100:.1f}%"


def _format_period(filters: MetricsFilter) -> str:
    return f"{filters.date_from.date().isoformat()} - {filters.date_to.date().isoformat()}"


def _format_counts_inline(counts: dict[str, int]) -> str:
    if not counts:
        return "нет данных"
    return ", ".join(f"{key}: {value}" for key, value in sorted(counts.items()))


def _format_duration(seconds: float | None) -> str:
    if seconds is None:
        return "нет данных"
    minutes = seconds / 60
    if minutes < 60:
        return f"{minutes:.1f} мин"
    return f"{minutes / 60:.1f} ч"
