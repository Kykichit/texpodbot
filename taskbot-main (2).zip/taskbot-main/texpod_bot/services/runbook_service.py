from pathlib import Path

from texpod_bot.domain.runbooks import (
    RunbookDefinition,
    RunbookEngine,
    RunbookHistoryItem,
    RunbookSession,
    RunbookStep,
    load_runbooks_from_dir,
)


class RunbookService:
    def __init__(self, runbooks: dict[str, RunbookDefinition]) -> None:
        self._engine = RunbookEngine(runbooks)
        self._runbooks = runbooks

    @classmethod
    def from_yaml_dir(cls, path: Path) -> "RunbookService":
        return cls(load_runbooks_from_dir(path))

    def issue_types(self) -> list[RunbookDefinition]:
        return list(self._runbooks.values())

    def start(self, code: str) -> RunbookSession:
        return self._engine.start(code)

    def current_step(self, session: RunbookSession) -> RunbookStep:
        return self._engine.current_step(session)

    def choose_option(self, session: RunbookSession, selected_option: str) -> RunbookSession:
        return self._engine.choose_option(session, selected_option)

    def advance_action_step(self, session: RunbookSession) -> RunbookSession:
        return self._engine.advance_action_step(session)


def session_to_json(session: RunbookSession) -> dict[str, object]:
    return {
        "runbook_code": session.runbook_code,
        "current_step_key": session.current_step_key,
        "finished": session.finished,
        "action": session.action.value if session.action else None,
        "history": [
            {
                "step_key": item.step_key,
                "selected_option": item.selected_option,
                "next_step": item.next_step,
                "action": item.action.value if item.action else None,
            }
            for item in session.history
        ],
    }


def session_from_json(payload: dict[str, object]) -> RunbookSession:
    from texpod_bot.domain.runbooks import RunbookAction

    raw_history = payload.get("history", [])
    if not isinstance(raw_history, list):
        raw_history = []
    history: list[RunbookHistoryItem] = []
    for item in raw_history:
        if not isinstance(item, dict):
            continue
        action = item.get("action")
        history.append(
            RunbookHistoryItem(
                step_key=str(item.get("step_key", "")),
                selected_option=_optional_str(item.get("selected_option")),
                next_step=_optional_str(item.get("next_step")),
                action=RunbookAction(str(action)) if action else None,
            )
        )

    action = payload.get("action")
    return RunbookSession(
        runbook_code=str(payload["runbook_code"]),
        current_step_key=str(payload["current_step_key"]),
        history=tuple(history),
        finished=bool(payload.get("finished", False)),
        action=RunbookAction(str(action)) if action else None,
    )


def _optional_str(value: object) -> str | None:
    return str(value) if value is not None else None
