from dataclasses import dataclass

from texpod_bot.domain.enums import IssueType, MessageSenderType, TicketEventType
from texpod_bot.domain.runbooks import RunbookAction, RunbookSession
from texpod_bot.domain.schemas import ClientCreate, DeviceCreate
from texpod_bot.infrastructure.database.models import SupportSession
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.runbook_service import RunbookService, session_from_json, session_to_json
from texpod_bot.services.structured_collection import (
    CollectionAnswer,
    CollectionSession,
    MediaAttachment,
    answer_collection,
    collection_from_json,
    collection_to_json,
    format_collection_summary,
    priority_input_from_collection,
    start_collection,
    start_collection_with_media,
)
from texpod_bot.services.telegram_escalation import (
    ClientReply,
    SupportGroupReply,
    TelegramEscalationService,
)
from texpod_bot.services.tickets import PriorityDecisionInput, TicketService


@dataclass(frozen=True, slots=True)
class TelegramUserContext:
    telegram_user_id: str
    telegram_chat_id: str
    display_name: str | None = None


@dataclass(frozen=True, slots=True)
class IncomingClientMessage:
    text: str | None = None
    attachment_url: str | None = None
    attachment_metadata: dict[str, str] | None = None
    telegram_message_id: str | None = None


@dataclass(frozen=True, slots=True)
class TelegramSupportResponse:
    text: str
    keyboard: str
    options: tuple[str, ...] = ()
    should_reply: bool = True


class TelegramSupportHandlers:
    def __init__(
        self,
        *,
        uow: SupportUnitOfWork,
        runbook_service: RunbookService,
        ticket_service: TicketService,
        escalation_service: TelegramEscalationService | None = None,
    ) -> None:
        self._uow = uow
        self._runbooks = runbook_service
        self._tickets = ticket_service
        self._escalation = escalation_service

    async def handle_start(self, context: TelegramUserContext) -> TelegramSupportResponse:
        await self._get_or_create_session(context)
        await self._uow.commit()
        return TelegramSupportResponse(
            text="Здравствуйте! Выберите проблему, и я проведу короткую диагностику.",
            keyboard="issue_type_menu",
        )

    async def handle_help(self, context: TelegramUserContext) -> TelegramSupportResponse:
        await self._get_or_create_session(context)
        await self._uow.commit()
        return TelegramSupportResponse(
            text="Я помогу проверить проблему, собрать данные и передать обращение оператору.",
            keyboard="main_menu",
        )

    async def handle_main_menu(self, context: TelegramUserContext) -> TelegramSupportResponse:
        session = await self._get_or_create_session(context)
        _reset_session(session)
        await self._uow.commit()
        return TelegramSupportResponse(text="Выберите проблему.", keyboard="issue_type_menu")

    async def handle_issue_type(
        self,
        context: TelegramUserContext,
        runbook_code: str,
    ) -> TelegramSupportResponse:
        session = await self._get_or_create_session(context)
        runbook_session = self._runbooks.start(runbook_code)
        _store_runbook_session(session, runbook_session, state="runbook")
        step = self._runbooks.current_step(runbook_session)
        await self._uow.commit()
        return TelegramSupportResponse(
            text=step.text,
            keyboard="runbook_options",
            options=tuple(option.label for option in step.options),
        )

    async def handle_runbook_option(
        self,
        context: TelegramUserContext,
        selected_option: str,
    ) -> TelegramSupportResponse:
        session = await self._get_or_create_session(context)
        runbook_session = _load_runbook_session(session)
        runbook_session = self._runbooks.choose_option(runbook_session, selected_option)
        _store_runbook_session(session, runbook_session, state="runbook")
        step = self._runbooks.current_step(runbook_session)

        if runbook_session.action == RunbookAction.RESOLVED:
            session.state = "resolved"
            await self._uow.commit()
            return TelegramSupportResponse(text=step.text, keyboard="main_menu")

        if runbook_session.action in {RunbookAction.ESCALATE, RunbookAction.CREATE_TICKET}:
            collection_result = start_collection(
                _issue_type_from_runbook(runbook_session.runbook_code)
            )
            _store_collection_session(session, collection_result.session)
            await self._uow.commit()
            return TelegramSupportResponse(text=collection_result.prompt, keyboard="main_menu")

        await self._uow.commit()
        return TelegramSupportResponse(
            text=step.text,
            keyboard="runbook_options",
            options=tuple(option.label for option in step.options),
        )

    async def handle_call_operator(self, context: TelegramUserContext) -> TelegramSupportResponse:
        session = await self._get_or_create_session(context)
        issue_type = IssueType.UNKNOWN
        if session.runbook_code is not None:
            issue_type = _issue_type_from_runbook(session.runbook_code)
        result = start_collection(issue_type)
        _store_collection_session(session, result.session)
        await self._uow.commit()
        return TelegramSupportResponse(text=result.prompt, keyboard="main_menu")

    async def handle_client_message(
        self,
        context: TelegramUserContext,
        message: IncomingClientMessage,
    ) -> TelegramSupportResponse:
        session = await self._get_or_create_session(context)
        if session.state == "collecting_data":
            response = await self._handle_collection_answer(context, session, message)
            await self._uow.commit()
            return response

        if session.ticket_id is not None:
            if self._escalation is not None:
                result = await self._escalation.route_client_reply(
                    ClientReply(
                        ticket_id=session.ticket_id,
                        client_id=session.client_id,
                        text=message.text,
                        attachment_url=message.attachment_url,
                        telegram_message_id=message.telegram_message_id,
                    )
                )
                if result.routed:
                    return TelegramSupportResponse(
                        text="",
                        keyboard="operator",
                        should_reply=False,
                    )
            await self._tickets.add_message(
                session.ticket_id,
                sender_type=MessageSenderType.CLIENT,
                sender_id=session.client_id,
                text=message.text,
                attachment_url=message.attachment_url,
                telegram_message_id=message.telegram_message_id,
            )
            await self._uow.commit()
            return TelegramSupportResponse(
                text="",
                keyboard="operator",
                should_reply=False,
            )

        if session.current_step_key is not None:
            runbook_session = _load_runbook_session(session)
            step = self._runbooks.current_step(runbook_session)
            if step.action == RunbookAction.COLLECT_MEDIA:
                runbook_session = self._runbooks.advance_action_step(runbook_session)
                _store_runbook_session(session, runbook_session, state="waiting_support")
                issue_type = _issue_type_from_runbook(runbook_session.runbook_code)
                if message.attachment_url is not None:
                    collection_result = start_collection_with_media(
                        issue_type,
                        MediaAttachment(
                            file_id=message.attachment_url,
                            metadata=message.attachment_metadata or {},
                        ),
                    )
                else:
                    collection_result = start_collection(issue_type)
                _store_collection_session(session, collection_result.session)
                await self._uow.commit()
                return TelegramSupportResponse(text=collection_result.prompt, keyboard="main_menu")

        await self._uow.commit()
        return TelegramSupportResponse(
            text="Выберите тип проблемы, чтобы начать диагностику.",
            keyboard="issue_type_menu",
        )

    async def handle_cancel(self, context: TelegramUserContext) -> TelegramSupportResponse:
        session = await self._get_or_create_session(context)
        _reset_session(session)
        await self._uow.commit()
        return TelegramSupportResponse(text="Диагностика отменена.", keyboard="main_menu")

    async def handle_support_group_reply(
        self,
        *,
        operator_telegram_user_id: str,
        support_group_message_id: str | None,
        support_thread_id: str | None,
        text: str | None,
        telegram_message_id: str,
    ) -> TelegramSupportResponse:
        if self._escalation is None:
            return TelegramSupportResponse(
                text="Маршрутизация поддержки не настроена.",
                keyboard="main_menu",
            )
        result = await self._escalation.route_operator_reply(
            SupportGroupReply(
                operator_telegram_user_id=operator_telegram_user_id,
                support_group_message_id=support_group_message_id,
                support_thread_id=support_thread_id,
                text=text,
                telegram_message_id=telegram_message_id,
            )
        )
        if not result.routed and result.reason == "operator_not_allowed":
            return TelegramSupportResponse(
                text="Нет доступа. Попросите администратора добавить вас оператором.",
                keyboard="main_menu",
            )
        if not result.routed:
            return TelegramSupportResponse(
                text="Тикет для ответа не найден.",
                keyboard="main_menu",
            )
        return TelegramSupportResponse(text="Ответ отправлен клиенту.", keyboard="main_menu")

    async def _ensure_ticket(
        self,
        context: TelegramUserContext,
        session: SupportSession,
        *,
        business_blocked: bool = False,
        has_workaround: bool = False,
    ) -> None:
        if session.ticket_id is not None:
            return
        runbook_session = _load_runbook_session(session)
        client_id = await self._ensure_client(context, session)
        ticket = await self._tickets.create_ticket_from_runbook_session(
            client_id=client_id,
            telegram_chat_id=context.telegram_chat_id,
            runbook_session=runbook_session,
            issue_type=_issue_type_from_runbook(runbook_session.runbook_code),
            priority_input=PriorityDecisionInput(
                affected_scope="single_device",
                business_blocked=business_blocked,
                has_workaround=has_workaround,
            ),
        )
        session.ticket_id = ticket.id
        await self._tickets.add_event(ticket.id, TicketEventType.ESCALATED, {"source": "telegram"})
        if self._escalation is not None:
            await self._escalation.escalate_to_support_group(ticket.id)

    async def _handle_collection_answer(
        self,
        context: TelegramUserContext,
        session: SupportSession,
        message: IncomingClientMessage,
    ) -> TelegramSupportResponse:
        collection = _load_collection_session(session)
        result = answer_collection(
            collection,
            CollectionAnswer(
                text=message.text,
                attachment=(
                    MediaAttachment(
                        file_id=message.attachment_url,
                        metadata=message.attachment_metadata or {},
                    )
                    if message.attachment_url
                    else None
                ),
            ),
        )
        _store_collection_session(session, result.session)
        if result.complete:
            await self._create_ticket_from_collection(context, session, result.session)
            session.state = "waiting_support"
            return TelegramSupportResponse(text=result.prompt, keyboard="operator")
        return TelegramSupportResponse(text=result.prompt, keyboard="main_menu")

    async def _create_ticket_from_collection(
        self,
        context: TelegramUserContext,
        session: SupportSession,
        collection: CollectionSession,
    ) -> None:
        if session.ticket_id is not None:
            return
        client_id = await self._ensure_client(context, session, name=collection.data.client_name)
        device_db_id = await self._ensure_device(client_id, collection)
        runbook_session = _load_runbook_session(session)
        ticket = await self._tickets.create_ticket_from_runbook_session(
            client_id=client_id,
            telegram_chat_id=context.telegram_chat_id,
            runbook_session=runbook_session,
            issue_type=collection.data.issue_type,
            device_id=device_db_id,
            priority_input=priority_input_from_collection(collection.data),
        )
        session.ticket_id = ticket.id
        summary = format_collection_summary(collection.data)
        await self._tickets.add_message(
            ticket.id,
            sender_type=MessageSenderType.CLIENT,
            sender_id=client_id,
            text=summary,
            attachment_url=(
                collection.data.screenshot_or_video.file_id
                if collection.data.screenshot_or_video
                else None
            ),
        )
        await self._tickets.add_event(
            ticket.id,
            TicketEventType.RUNBOOK_STEP_COMPLETED,
            {"collection": collection_to_json(collection)["data"]},
        )
        await self._tickets.add_event(ticket.id, TicketEventType.ESCALATED, {"source": "telegram"})
        if self._escalation is not None:
            await self._escalation.escalate_to_support_group(ticket.id)

    async def _ensure_client(
        self,
        context: TelegramUserContext,
        session: SupportSession,
        name: str | None = None,
    ) -> str:
        if session.client_id is not None:
            if name:
                client = await self._uow.clients.get(session.client_id)
                if client is not None:
                    client.name = name
            return session.client_id
        client = await self._uow.clients.get_by_telegram_user_id(context.telegram_user_id)
        if client is None:
            fallback_name = (
                name or context.display_name or f"Telegram user {context.telegram_user_id}"
            )
            client = await self._uow.clients.create(
                ClientCreate(
                    name=fallback_name,
                    telegram_user_id=context.telegram_user_id,
                )
            )
        elif name:
            client.name = name
        session.client_id = client.id
        return client.id

    async def _ensure_device(
        self,
        client_id: str,
        collection: CollectionSession,
    ) -> str | None:
        if collection.data.device_id is None:
            return None
        device = await self._uow.devices.get_by_device_id(client_id, collection.data.device_id)
        if device is not None:
            return device.id
        device = await self._uow.devices.create(
            DeviceCreate(
                client_id=client_id,
                device_id=collection.data.device_id,
                app_version=collection.data.app_version,
            )
        )
        return device.id

    async def _get_or_create_session(self, context: TelegramUserContext) -> SupportSession:
        client = await self._uow.clients.get_by_telegram_user_id(context.telegram_user_id)
        return await self._uow.sessions.get_or_create(
            telegram_user_id=context.telegram_user_id,
            telegram_chat_id=context.telegram_chat_id,
            client_id=client.id if client else None,
        )


def _store_runbook_session(
    session: SupportSession,
    runbook_session: object,
    *,
    state: str,
) -> None:
    typed_session = runbook_session
    if not isinstance(typed_session, RunbookSession):
        msg = "runbook_session must be a RunbookSession"
        raise TypeError(msg)
    session.runbook_code = typed_session.runbook_code
    session.current_step_key = typed_session.current_step_key
    session.history_json = [
        item
        for item in session.history_json
        if isinstance(item, dict) and "runbook_code" not in item
    ]
    session.history_json.insert(0, session_to_json(typed_session))
    session.state = state


def _store_collection_session(session: SupportSession, collection: CollectionSession) -> None:
    session.history_json = [
        item
        for item in session.history_json
        if isinstance(item, dict) and item.get("kind") != "collection"
    ]
    session.history_json.append(collection_to_json(collection))
    session.state = "collecting_data"


def _load_runbook_session(session: SupportSession) -> RunbookSession:
    for item in session.history_json:
        if isinstance(item, dict) and "runbook_code" in item:
            return session_from_json(item)
    msg = "Support session does not have active runbook state"
    raise RuntimeError(msg)


def _load_collection_session(session: SupportSession) -> CollectionSession:
    for item in reversed(session.history_json):
        if isinstance(item, dict) and item.get("kind") == "collection":
            return collection_from_json(item)
    msg = "Support session does not have active collection state"
    raise RuntimeError(msg)


def _reset_session(session: SupportSession) -> None:
    session.ticket_id = None
    session.runbook_code = None
    session.current_step_key = None
    session.history_json = []
    session.state = "main_menu"


def _issue_type_from_runbook(runbook_code: str) -> IssueType:
    mapping = {
        "KIOSK_OFFLINE": IssueType.DEVICE_OFFLINE,
        "SYNC_FAILED": IssueType.MENU_SYNC,
        "APP_FREEZE": IssueType.SOFTWARE,
    }
    return mapping.get(runbook_code, IssueType.UNKNOWN)
