from dataclasses import dataclass
from datetime import UTC, datetime, time, timedelta

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from texpod_bot.domain.enums import MessageSenderType, TicketEventType, TicketStatus
from texpod_bot.domain.schemas import TicketEventCreate, TicketMessageCreate
from texpod_bot.infrastructure.database.models import MessageRouting, Ticket
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.metrics import MetricsFilter, MetricsService
from texpod_bot.services.telegram_escalation import TelegramSupportApi
from texpod_bot.services.tickets import TicketService

SessionMaker = async_sessionmaker[AsyncSession]

SUPPORT_GROUP_READY_MESSAGE = (
    "Группа поддержки подключена.\n"
    "Отвечайте reply на карточку обращения или используйте команды:\n"
    "/status SUP-XXXX\n"
    "/close SUP-XXXX причина\n"
    "/stats today"
)


@dataclass(frozen=True, slots=True)
class SupportBridgeResponse:
    text: str | None = None


class SupportGroupBridgeService:
    def __init__(
        self,
        *,
        sessionmaker: SessionMaker,
        telegram_api: TelegramSupportApi,
        support_group_id: str,
    ) -> None:
        self._sessionmaker = sessionmaker
        self._telegram = telegram_api
        self._support_group_id = support_group_id

    async def handle_support_group_start(self) -> SupportBridgeResponse:
        return SupportBridgeResponse(text=SUPPORT_GROUP_READY_MESSAGE)

    async def handle_operator_reply(
        self,
        *,
        operator_telegram_user_id: str,
        replied_message_id: str | None,
        support_thread_id: str | None,
        text: str | None,
        telegram_message_id: str,
    ) -> SupportBridgeResponse:
        if not text or text.startswith("/"):
            return SupportBridgeResponse()

        async with self._sessionmaker() as db_session:
            uow = SupportUnitOfWork(db_session)
            routing = await _find_routing(
                uow,
                replied_message_id=replied_message_id,
                support_thread_id=support_thread_id,
            )
            if routing is None:
                return SupportBridgeResponse(text="Тикет для ответа не найден.")
            ticket = await uow.tickets.get(routing.ticket_id)
            if ticket is None:
                return SupportBridgeResponse(text="Тикет для ответа не найден.")

            await self._telegram.send_message(chat_id=routing.client_chat_id, text=text)
            await uow.messages.create(
                TicketMessageCreate(
                    ticket_id=ticket.id,
                    sender_type=MessageSenderType.SUPPORT,
                    sender_id=operator_telegram_user_id,
                    text=text,
                    telegram_message_id=telegram_message_id,
                )
            )
            await uow.events.create(
                TicketEventCreate(
                    ticket_id=ticket.id,
                    event_type=TicketEventType.MESSAGE_ADDED,
                    payload_json={
                        "source": "support_group",
                        "operator_id": operator_telegram_user_id,
                    },
                )
            )
            if ticket.first_response_at is None:
                ticket.first_response_at = datetime.now(UTC)
                await uow.events.create(
                    TicketEventCreate(
                        ticket_id=ticket.id,
                        event_type=TicketEventType.FIRST_RESPONSE_RECORDED,
                        payload_json={
                            "timestamp": ticket.first_response_at.isoformat(),
                            "actor_id": operator_telegram_user_id,
                        },
                    )
                )
            await uow.commit()
            return SupportBridgeResponse(text=f"Ответ отправлен клиенту по {ticket.public_id}.")

    async def handle_close_command(
        self,
        *,
        command_text: str,
        replied_message_id: str | None = None,
        support_thread_id: str | None = None,
    ) -> SupportBridgeResponse:
        public_id, reason = _parse_close_command(command_text)

        async with self._sessionmaker() as db_session:
            uow = SupportUnitOfWork(db_session)
            ticket: Ticket | None = None
            routing: MessageRouting | None = None
            if public_id is not None:
                ticket = await uow.tickets.get_by_public_id(public_id)
                if ticket is not None:
                    routing = await uow.message_routings.get_by_ticket_id(ticket.id)
            else:
                routing = await _find_routing(
                    uow,
                    replied_message_id=replied_message_id,
                    support_thread_id=support_thread_id,
                )
                if routing is not None:
                    ticket = await uow.tickets.get(routing.ticket_id)

            requested_id = public_id or "в reply"
            if ticket is None:
                return SupportBridgeResponse(text=f"Обращение {requested_id} не найдено.")
            if ticket.status == TicketStatus.CLOSED.value:
                return SupportBridgeResponse(text=f"Обращение {ticket.public_id} уже закрыто.")

            ticket_service = TicketService(uow)
            closed = await ticket_service.close_ticket(ticket.id)
            if reason:
                await uow.events.create(
                    TicketEventCreate(
                        ticket_id=ticket.id,
                        event_type=TicketEventType.CLOSED,
                        payload_json={
                            "reason": reason,
                            "closed_at": datetime.now(UTC).isoformat(),
                        },
                    )
                )
            client_chat_id = (
                routing.client_chat_id if routing is not None else closed.telegram_chat_id
            )
            await self._telegram.send_message(
                chat_id=client_chat_id,
                text=f"Обращение {closed.public_id} закрыто. Спасибо!",
            )
            await uow.commit()
            return SupportBridgeResponse(text=f"Обращение {closed.public_id} закрыто.")

    async def handle_status_command(self, *, command_text: str) -> SupportBridgeResponse:
        public_id = _parse_public_id_command(command_text)
        if public_id is None:
            return SupportBridgeResponse(text="Использование: /status SUP-XXXX")

        async with self._sessionmaker() as db_session:
            uow = SupportUnitOfWork(db_session)
            ticket = await uow.tickets.get_by_public_id(public_id)
            if ticket is None:
                return SupportBridgeResponse(text=f"Обращение {public_id} не найдено.")
            messages = await uow.messages.list_for_ticket(ticket.id)
            support_messages = [
                message
                for message in messages
                if message.sender_type == MessageSenderType.SUPPORT.value
            ]
            return SupportBridgeResponse(
                text=(
                    f"Обращение {ticket.public_id}\n"
                    f"Статус: {ticket.status}\n"
                    f"Приоритет: {ticket.priority}\n"
                    f"Категория: {ticket.issue_type}\n"
                    f"Канал: {ticket.source}\n"
                    f"Создано: {ticket.created_at.isoformat()}\n"
                    f"Первый ответ: {_format_optional_dt(ticket.first_response_at)}\n"
                    f"Решено: {_format_optional_dt(ticket.resolved_at)}\n"
                    f"Закрыто: {_format_optional_dt(ticket.closed_at)}\n"
                    f"Ответы операторов: {len(support_messages)}"
                )
            )

    async def handle_stats_command(self, *, command_text: str) -> SupportBridgeResponse:
        filters = _stats_filter(command_text, now=datetime.now(UTC))
        async with self._sessionmaker() as db_session:
            uow = SupportUnitOfWork(db_session)
            metrics = MetricsService(uow)
            snapshot = await metrics.build_snapshot(filters)
            return SupportBridgeResponse(text=metrics.format_support_summary(snapshot))


async def _find_routing(
    uow: SupportUnitOfWork,
    *,
    replied_message_id: str | None,
    support_thread_id: str | None,
) -> MessageRouting | None:
    return await uow.message_routings.get_by_support_context(
        support_group_message_id=replied_message_id,
        support_thread_id=support_thread_id,
    )


def _parse_close_command(command_text: str) -> tuple[str | None, str | None]:
    parts = command_text.strip().split(maxsplit=2)
    if len(parts) == 1:
        return None, None
    public_id = parts[1].upper()
    if not public_id.startswith("SUP-"):
        return None, " ".join(parts[1:])
    reason = parts[2].strip() if len(parts) > 2 else None
    return public_id, reason or None


def _parse_public_id_command(command_text: str) -> str | None:
    parts = command_text.strip().split(maxsplit=1)
    if len(parts) != 2:
        return None
    public_id = parts[1].strip().upper()
    if not public_id.startswith("SUP-"):
        return None
    return public_id


def _stats_filter(command_text: str, *, now: datetime) -> MetricsFilter:
    parts = command_text.strip().split(maxsplit=1)
    period = parts[1].strip().casefold() if len(parts) > 1 else "today"
    today_start = datetime.combine(now.date(), time.min, tzinfo=UTC)
    if period == "week":
        return MetricsFilter(date_from=today_start - timedelta(days=6), date_to=now)
    return MetricsFilter(date_from=today_start, date_to=now)


def _format_optional_dt(value: datetime | None) -> str:
    return value.isoformat() if value is not None else "нет данных"
