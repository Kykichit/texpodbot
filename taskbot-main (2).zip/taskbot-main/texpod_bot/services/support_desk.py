from dataclasses import dataclass, field
from typing import Protocol


@dataclass(frozen=True, slots=True)
class SupportDeskContact:
    id: str
    external_id: str
    name: str
    source_id: str | None = None
    phone: str | None = None
    email: str | None = None
    custom_attributes: dict[str, object] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class SupportDeskConversation:
    id: str
    contact_id: str


@dataclass(frozen=True, slots=True)
class SupportDeskMessage:
    id: str
    conversation_id: str


@dataclass(frozen=True, slots=True)
class SupportDeskTicketThread:
    external_system: str
    external_contact_id: str
    external_conversation_id: str
    external_url: str | None = None
    metadata: dict[str, object] = field(default_factory=dict)

    def as_external_ref_payload(self) -> dict[str, object]:
        payload: dict[str, object] = {
            "external_system": self.external_system,
            "external_contact_id": self.external_contact_id,
            "external_conversation_id": self.external_conversation_id,
            "metadata": self.metadata,
        }
        if self.external_url:
            payload["external_url"] = self.external_url
        return payload


class SupportDeskAdapter(Protocol):
    async def create_ticket_thread(
        self,
        *,
        ticket_public_id: str,
        customer_name: str | None,
        customer_channel: str,
        summary: str,
        metadata: dict[str, object],
    ) -> dict[str, object]:
        """Create a support desk thread for a newly created ticket."""

    async def send_customer_message(
        self,
        *,
        external_conversation_id: str,
        text: str,
        metadata: dict[str, object] | None = None,
    ) -> None:
        """Send a customer follow-up message to an existing support desk thread."""


class SupportDeskClient(Protocol):
    async def upsert_contact(self, contact: SupportDeskContact) -> SupportDeskContact:
        """Create or update a support desk contact and return external identifiers."""

    async def create_conversation(
        self,
        *,
        contact_id: str,
        source_id: str,
        custom_attributes: dict[str, object] | None = None,
    ) -> SupportDeskConversation:
        """Create a support desk conversation for an existing contact."""

    async def send_customer_message(
        self,
        *,
        conversation_id: str,
        content: str,
        source_id: str | None = None,
    ) -> SupportDeskMessage:
        """Append a customer-visible incoming message to the support desk conversation."""
