from dataclasses import dataclass
from enum import StrEnum

from texpod_bot.domain.enums import IssueType


class ClassificationConfidence(StrEnum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


@dataclass(frozen=True, slots=True)
class IssueClassification:
    issue_type: IssueType
    confidence: ClassificationConfidence
    matched_keywords: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class _IssueRule:
    issue_type: IssueType
    keywords: tuple[str, ...]


class RuleBasedIssueClassifier:
    def classify(self, text: str) -> IssueClassification:
        normalized = text.casefold()
        matches: list[tuple[_IssueRule, tuple[str, ...]]] = []
        for rule in _RULES:
            matched = tuple(keyword for keyword in rule.keywords if keyword in normalized)
            if matched:
                matches.append((rule, matched))

        if not matches:
            return IssueClassification(
                issue_type=IssueType.OTHER,
                confidence=ClassificationConfidence.LOW,
            )

        rule, matched_keywords = max(matches, key=_match_score)
        return IssueClassification(
            issue_type=rule.issue_type,
            confidence=_confidence_for_match(matched_keywords),
            matched_keywords=matched_keywords,
        )


def _match_score(match: tuple[_IssueRule, tuple[str, ...]]) -> tuple[int, int, int]:
    rule, keywords = match
    max_keyword_len = max(len(keyword) for keyword in keywords)
    return (max_keyword_len, len(keywords), _RULE_PRIORITY[rule.issue_type])


def _confidence_for_match(keywords: tuple[str, ...]) -> ClassificationConfidence:
    if any(" " in keyword for keyword in keywords):
        return ClassificationConfidence.HIGH
    if len(keywords) >= 2:
        return ClassificationConfidence.HIGH
    return ClassificationConfidence.MEDIUM


_RULES = (
    _IssueRule(
        issue_type=IssueType.SCANNER_NOT_WORKING,
        keywords=("сканер", "сканирует", "сканирование", "штрихкод", "barcode"),
    ),
    _IssueRule(
        issue_type=IssueType.RELEASE_NOT_DISPLAYED,
        keywords=("не отображается выпуск", "не вижу выпуск", "нет выпуска", "выпуск"),
    ),
    _IssueRule(
        issue_type=IssueType.TIMESHEET_SHIFT_OPEN_FAILED,
        keywords=("табельная смена", "смена сотрудников", "табель"),
    ),
    _IssueRule(
        issue_type=IssueType.CASH_SHIFT_OPEN_FAILED,
        keywords=("кассовая смена", "кассовую смену", "открыть смену", "касса"),
    ),
    _IssueRule(
        issue_type=IssueType.RECEIPTS_NOT_PRINTING,
        keywords=("не выходят чеки", "не печатает", "фискальный", "принтер", "чеки", "чек"),
    ),
    _IssueRule(
        issue_type=IssueType.TERMINAL_NOT_WORKING,
        keywords=("не проходит оплата", "банковский", "терминал", "эквайринг", "оплата", "карта"),
    ),
)

_RULE_PRIORITY = {
    IssueType.SCANNER_NOT_WORKING: 10,
    IssueType.RELEASE_NOT_DISPLAYED: 20,
    IssueType.TIMESHEET_SHIFT_OPEN_FAILED: 30,
    IssueType.CASH_SHIFT_OPEN_FAILED: 40,
    IssueType.RECEIPTS_NOT_PRINTING: 50,
    IssueType.TERMINAL_NOT_WORKING: 60,
}
