from dataclasses import dataclass
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, Protocol

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from texpod_bot.domain.enums import MessageSenderType, TicketEventType, TicketStatus
from texpod_bot.domain.schemas import TicketEventCreate, TicketMessageCreate
from texpod_bot.infrastructure.chatwoot import CHATWOOT_EXTERNAL_SYSTEM
from texpod_bot.infrastructure.repositories import SupportUnitOfWork

SessionMaker = async_sessionmaker[AsyncSession]


class CustomerMessenger(Protocol):
    async def send_text(self, *, chat_id: str, text: str) -> None:
        """Send a plain-text message to a customer channel."""


class WebhookHandleStatus(StrEnum):
    SENT = "sent"
    IGNORED = "ignored"
    NOT_FOUND = "not_found"
    SEND_FAILED = "send_failed"
    CLOSED = "closed"
    ALREADY_CLOSED = "already_closed"
    CLOSE_NOTIFY_FAILED = "close_notify_failed"


@dataclass(frozen=True, slots=True)
class WebhookHandleResult:
    status: WebhookHandleStatus
    reason: str | None = None
    ticket_id: str | None = None


@dataclass(frozen=True, slots=True)
class ChatwootMessageEvent:
    event_type: str | None
    conversation_id: str | None
    content: str | None
    message_type: str | None
    private: bool
    message_id: str | None
    sender_id: str | None
    sender_name: str | None

    @property
    def should_route_to_customer(self) -> bool:
        if self.event_type != "message_created":
            return False
        if self.private:
            return False
        if self.message_type != "outgoing":
            return False
        return bool(self.conversation_id and self.content and self.content.strip())


@dataclass(frozen=True, slots=True)
class ChatwootConversationStatusEvent:
    event_type: str | None
    conversation_id: str | None
    conversation_status: str | None
    previous_status: str | None

    @property
    def should_close_ticket(self) -> bool:
        return bool(
            self.conversation_id
            and self.conversation_status in {TicketStatus.RESOLVED.value, TicketStatus.CLOSED.value}
            and self.event_type != "message_created"
        )


class ChatwootWebhookService:
    def __init__(
        self,
        *,
        sessionmaker: SessionMaker,
        messenger: CustomerMessenger,
    ) -> None:
        self._sessionmaker = sessionmaker
        self._messenger = messenger

    async def handle_webhook(self, payload: dict[str, Any]) -> WebhookHandleResult:
        event = parse_chatwoot_message_event(payload)
        if event.should_route_to_customer:
            return await self._handle_operator_message(event)

        status_event = parse_chatwoot_conversation_status_event(payload)
        if status_event.should_close_ticket:
            return await self._handle_conversation_closed(status_event)

        return WebhookHandleResult(
            status=WebhookHandleStatus.IGNORED,
            reason=_ignored_reason(event),
        )

    async def _handle_operator_message(
        self,
        event: ChatwootMessageEvent,
    ) -> WebhookHandleResult:
        if event.conversation_id is None or event.content is None:
            return WebhookHandleResult(status=WebhookHandleStatus.IGNORED, reason="missing_data")
        async with self._sessionmaker() as db_session:
            uow = SupportUnitOfWork(db_session)
            ref = await uow.external_refs.get_by_external_conversation_id(
                CHATWOOT_EXTERNAL_SYSTEM,
                event.conversation_id,
            )
            if ref is None:
                return WebhookHandleResult(
                    status=WebhookHandleStatus.NOT_FOUND,
                    reason="external_ref_not_found",
                )
            ticket = await uow.tickets.get(ref.ticket_id)
            if ticket is None:
                return WebhookHandleResult(
                    status=WebhookHandleStatus.NOT_FOUND,
                    reason="ticket_not_found",
                )

            sender_id = event.sender_id or event.sender_name or "chatwoot"
            try:
                await self._messenger.send_text(
                    chat_id=ticket.telegram_chat_id,
                    text=event.content,
                )
            except Exception as exc:
                await uow.events.create(
                    TicketEventCreate(
                        ticket_id=ticket.id,
                        event_type=TicketEventType.CHATWOOT_OPERATOR_REPLY_SEND_FAILED,
                        payload_json={
                            "error": exc.__class__.__name__,
                            "external_conversation_id": event.conversation_id,
                            "external_message_id": event.message_id,
                        },
                    )
                )
                await uow.commit()
                return WebhookHandleResult(
                    status=WebhookHandleStatus.SEND_FAILED,
                    reason="customer_send_failed",
                    ticket_id=ticket.id,
                )

            await uow.messages.create(
                TicketMessageCreate(
                    ticket_id=ticket.id,
                    sender_type=MessageSenderType.SUPPORT,
                    sender_id=sender_id,
                    text=event.content,
                )
            )
            await uow.events.create(
                TicketEventCreate(
                    ticket_id=ticket.id,
                    event_type=TicketEventType.CHATWOOT_OPERATOR_REPLY_SENT,
                    payload_json={
                        "external_conversation_id": event.conversation_id,
                        "external_message_id": event.message_id,
                        "sender_id": sender_id,
                    },
                )
            )
            if ticket.first_response_at is None:
                ticket.first_response_at = datetime.now(UTC)
                await uow.events.create(
                    TicketEventCreate(
                        ticket_id=ticket.id,
                        event_type=TicketEventType.FIRST_RESPONSE_RECORDED,
                        payload_json={
                            "timestamp": ticket.first_response_at.isoformat(),
                            "actor_id": sender_id,
                            "source": "chatwoot",
                        },
                    )
                )
            await uow.commit()
            return WebhookHandleResult(status=WebhookHandleStatus.SENT, ticket_id=ticket.id)

    async def _handle_conversation_closed(
        self,
        event: ChatwootConversationStatusEvent,
    ) -> WebhookHandleResult:
        if event.conversation_id is None:
            return WebhookHandleResult(status=WebhookHandleStatus.IGNORED, reason="missing_data")
        async with self._sessionmaker() as db_session:
            uow = SupportUnitOfWork(db_session)
            ref = await uow.external_refs.get_by_external_conversation_id(
                CHATWOOT_EXTERNAL_SYSTEM,
                event.conversation_id,
            )
            if ref is None:
                return WebhookHandleResult(
                    status=WebhookHandleStatus.NOT_FOUND,
                    reason="external_ref_not_found",
                )
            ticket = await uow.tickets.get(ref.ticket_id)
            if ticket is None:
                return WebhookHandleResult(
                    status=WebhookHandleStatus.NOT_FOUND,
                    reason="ticket_not_found",
                )
            if ticket.status in {TicketStatus.CLOSED.value, TicketStatus.RESOLVED.value}:
                return WebhookHandleResult(
                    status=WebhookHandleStatus.ALREADY_CLOSED,
                    reason="ticket_already_closed",
                    ticket_id=ticket.id,
                )

            closed_at = datetime.now(UTC)
            ticket.status = TicketStatus.CLOSED.value
            ticket.closed_at = closed_at
            await uow.events.create(
                TicketEventCreate(
                    ticket_id=ticket.id,
                    event_type=TicketEventType.CHATWOOT_CONVERSATION_RESOLVED,
                    payload_json={
                        "external_conversation_id": event.conversation_id,
                        "conversation_status": event.conversation_status,
                        "previous_status": event.previous_status,
                        "closed_at": closed_at.isoformat(),
                    },
                )
            )
            await uow.commit()

            try:
                await self._messenger.send_text(
                    chat_id=ticket.telegram_chat_id,
                    text=f"Обращение {ticket.public_id} закрыто. Спасибо!",
                )
            except Exception as exc:
                await uow.events.create(
                    TicketEventCreate(
                        ticket_id=ticket.id,
                        event_type=TicketEventType.CHATWOOT_TICKET_CLOSE_NOTIFY_FAILED,
                        payload_json={
                            "error": exc.__class__.__name__,
                            "external_conversation_id": event.conversation_id,
                        },
                    )
                )
                await uow.commit()
                return WebhookHandleResult(
                    status=WebhookHandleStatus.CLOSE_NOTIFY_FAILED,
                    reason="customer_close_notify_failed",
                    ticket_id=ticket.id,
                )

            return WebhookHandleResult(status=WebhookHandleStatus.CLOSED, ticket_id=ticket.id)


def parse_chatwoot_message_event(payload: dict[str, Any]) -> ChatwootMessageEvent:
    message = _dict_value(payload.get("message"))
    conversation = _dict_value(payload.get("conversation")) or _dict_value(
        message.get("conversation") if message else None
    )
    sender = _dict_value(payload.get("sender")) or _dict_value(
        message.get("sender") if message else None
    )
    return ChatwootMessageEvent(
        event_type=_optional_str(payload.get("event") or payload.get("event_type")),
        conversation_id=_first_str(
            conversation.get("id") if conversation else None,
            payload.get("conversation_id"),
            message.get("conversation_id") if message else None,
        ),
        content=_first_str(
            payload.get("content"),
            message.get("content") if message else None,
        ),
        message_type=_first_str(
            payload.get("message_type"),
            message.get("message_type") if message else None,
        ),
        private=_first_bool(
            payload.get("private"),
            message.get("private") if message else None,
        ),
        message_id=_first_str(
            payload.get("id"),
            payload.get("message_id"),
            message.get("id") if message else None,
        ),
        sender_id=_first_str(sender.get("id") if sender else None),
        sender_name=_first_str(sender.get("name") if sender else None),
    )


def parse_chatwoot_conversation_status_event(
    payload: dict[str, Any],
) -> ChatwootConversationStatusEvent:
    conversation = _conversation_value(payload)
    event_type = _optional_str(payload.get("event") or payload.get("event_type"))
    status = _first_str(
        conversation.get("status") if conversation else None,
        payload.get("status"),
    )
    return ChatwootConversationStatusEvent(
        event_type=event_type,
        conversation_id=_first_str(
            conversation.get("id") if conversation else None,
            payload.get("conversation_id"),
            payload.get("id") if _is_conversation_event(event_type) else None,
        ),
        conversation_status=status.lower() if status is not None else None,
        previous_status=_first_str(
            payload.get("previous_status"),
            payload.get("changed_from"),
            conversation.get("previous_status") if conversation else None,
        ),
    )


def _ignored_reason(event: ChatwootMessageEvent) -> str:
    if event.event_type != "message_created":
        return "unsupported_event"
    if event.private:
        return "private_note"
    if event.message_type != "outgoing":
        return "non_operator_message"
    if not event.conversation_id:
        return "missing_conversation_id"
    return "empty_content"


def _conversation_value(payload: dict[str, Any]) -> dict[str, Any] | None:
    message = _dict_value(payload.get("message"))
    return _dict_value(payload.get("conversation")) or _dict_value(
        message.get("conversation") if message else None
    )


def _is_conversation_event(event_type: str | None) -> bool:
    return event_type in {
        "conversation_status_changed",
        "conversation_updated",
        "conversation_resolved",
        "conversation_closed",
    }


def _dict_value(value: object) -> dict[str, Any] | None:
    return value if isinstance(value, dict) else None


def _first_str(*values: object) -> str | None:
    for value in values:
        normalized = _optional_str(value)
        if normalized is not None:
            return normalized
    return None


def _optional_str(value: object) -> str | None:
    if isinstance(value, str) and value:
        return value
    if isinstance(value, int):
        return str(value)
    return None


def _first_bool(*values: object) -> bool:
    for value in values:
        if isinstance(value, bool):
            return value
    return False
