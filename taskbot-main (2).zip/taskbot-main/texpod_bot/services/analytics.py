from collections import Counter
from dataclasses import dataclass
from datetime import UTC, date, datetime, time, timedelta

from sqlalchemy import select

from texpod_bot.domain.enums import MessageSenderType, TicketEventType, TicketStatus
from texpod_bot.infrastructure.database.models import (
    Client,
    Device,
    Ticket,
    TicketEvent,
    TicketMessage,
)
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.telegram_escalation import TelegramSupportApi


@dataclass(frozen=True, slots=True)
class DailySupportReport:
    report_date: date
    tickets_total: int
    tickets_by_issue_type: dict[str, int]
    tickets_by_priority: dict[str, int]
    resolved_by_runbook: int
    escalated_to_operator: int
    average_first_response_seconds: float | None
    average_close_seconds: float | None
    top_clients: list[tuple[str, int]]
    top_problems: list[tuple[str, int]]
    tickets_missing_app_version_or_device_id: int


class AnalyticsService:
    def __init__(self, uow: SupportUnitOfWork) -> None:
        self._uow = uow

    async def build_daily_report(self, report_date: date) -> DailySupportReport:
        start_at = datetime.combine(report_date, time.min, tzinfo=UTC)
        end_at = start_at + timedelta(days=1)
        tickets = await self._tickets_for_period(start_at, end_at)
        ticket_ids = [ticket.id for ticket in tickets]
        events = await self._events_for_tickets(ticket_ids)
        messages = await self._messages_for_tickets(ticket_ids)

        clients = await self._clients_by_id({ticket.client_id for ticket in tickets})
        devices = await self._devices_by_id(
            {ticket.device_id for ticket in tickets if ticket.device_id is not None}
        )
        return DailySupportReport(
            report_date=report_date,
            tickets_total=len(tickets),
            tickets_by_issue_type=dict(Counter(ticket.issue_type for ticket in tickets)),
            tickets_by_priority=dict(Counter(ticket.priority for ticket in tickets)),
            resolved_by_runbook=_count_resolved_by_runbook(tickets, events, messages),
            escalated_to_operator=_count_escalated_to_operator(tickets, events),
            average_first_response_seconds=_average_first_response_seconds(tickets, messages),
            average_close_seconds=_average_close_seconds(tickets),
            top_clients=_top_clients(tickets, clients),
            top_problems=_top_problems(tickets),
            tickets_missing_app_version_or_device_id=_count_missing_device_data(tickets, devices),
        )

    def format_daily_report(self, report: DailySupportReport) -> str:
        return (
            f"*Daily support report — {report.report_date.isoformat()}*\n\n"
            f"*Tickets total:* {report.tickets_total}\n\n"
            "*By issue type:*\n"
            f"{_format_counts(report.tickets_by_issue_type)}\n\n"
            "*By priority:*\n"
            f"{_format_counts(report.tickets_by_priority)}\n\n"
            f"*Resolved by runbook:* {report.resolved_by_runbook}\n"
            f"*Escalated to operator:* {report.escalated_to_operator}\n"
            f"*Avg first response:* {_format_duration(report.average_first_response_seconds)}\n"
            f"*Avg close time:* {_format_duration(report.average_close_seconds)}\n\n"
            "*Top clients:*\n"
            f"{_format_ranked(report.top_clients)}\n\n"
            "*Top problems:*\n"
            f"{_format_ranked(report.top_problems)}\n\n"
            "*Missing app_version/device_id:* "
            f"{report.tickets_missing_app_version_or_device_id}"
        )

    async def send_daily_report(
        self,
        *,
        report_date: date,
        telegram_api: TelegramSupportApi,
        support_group_id: str,
    ) -> str:
        report = await self.build_daily_report(report_date)
        text = self.format_daily_report(report)
        await telegram_api.send_message(chat_id=support_group_id, text=text)
        return text

    async def _tickets_for_period(self, start_at: datetime, end_at: datetime) -> list[Ticket]:
        result = await self._uow.session.execute(
            select(Ticket)
            .where(Ticket.created_at >= start_at, Ticket.created_at < end_at)
            .order_by(Ticket.created_at)
        )
        return list(result.scalars().all())

    async def _events_for_tickets(self, ticket_ids: list[str]) -> list[TicketEvent]:
        if not ticket_ids:
            return []
        result = await self._uow.session.execute(
            select(TicketEvent)
            .where(TicketEvent.ticket_id.in_(ticket_ids))
            .order_by(TicketEvent.created_at)
        )
        return list(result.scalars().all())

    async def _messages_for_tickets(self, ticket_ids: list[str]) -> list[TicketMessage]:
        if not ticket_ids:
            return []
        result = await self._uow.session.execute(
            select(TicketMessage)
            .where(TicketMessage.ticket_id.in_(ticket_ids))
            .order_by(TicketMessage.created_at)
        )
        return list(result.scalars().all())

    async def _clients_by_id(self, client_ids: set[str]) -> dict[str, Client]:
        if not client_ids:
            return {}
        result = await self._uow.session.execute(select(Client).where(Client.id.in_(client_ids)))
        return {client.id: client for client in result.scalars().all()}

    async def _devices_by_id(self, device_ids: set[str]) -> dict[str, Device]:
        if not device_ids:
            return {}
        result = await self._uow.session.execute(select(Device).where(Device.id.in_(device_ids)))
        return {device.id: device for device in result.scalars().all()}


def _count_resolved_by_runbook(
    tickets: list[Ticket],
    events: list[TicketEvent],
    messages: list[TicketMessage],
) -> int:
    escalated_ids = _ticket_ids_with_event(events, TicketEventType.ESCALATED.value)
    support_message_ids = {
        message.ticket_id
        for message in messages
        if message.sender_type == MessageSenderType.SUPPORT.value
    }
    return sum(
        1
        for ticket in tickets
        if ticket.status in {TicketStatus.RESOLVED.value, TicketStatus.CLOSED.value}
        and ticket.id not in escalated_ids
        and ticket.id not in support_message_ids
    )


def _count_escalated_to_operator(tickets: list[Ticket], events: list[TicketEvent]) -> int:
    escalated_ids = _ticket_ids_with_event(events, TicketEventType.ESCALATED.value)
    operator_statuses = {
        TicketStatus.WAITING_SUPPORT.value,
        TicketStatus.ASSIGNED.value,
        TicketStatus.DEV_NEEDED.value,
    }
    return sum(
        1 for ticket in tickets if ticket.id in escalated_ids or ticket.status in operator_statuses
    )


def _average_first_response_seconds(
    tickets: list[Ticket],
    messages: list[TicketMessage],
) -> float | None:
    response_times: list[float] = []
    messages_by_ticket = _messages_by_ticket(messages)
    for ticket in tickets:
        first_response = next(
            (
                message
                for message in messages_by_ticket.get(ticket.id, [])
                if message.sender_type
                in {MessageSenderType.SUPPORT.value, MessageSenderType.BOT.value}
            ),
            None,
        )
        if first_response is not None:
            response_times.append(_seconds_between(ticket.created_at, first_response.created_at))
    return _average(response_times)


def _average_close_seconds(tickets: list[Ticket]) -> float | None:
    values = [
        _seconds_between(ticket.created_at, ticket.closed_at)
        for ticket in tickets
        if ticket.closed_at is not None
    ]
    return _average(values)


def _top_clients(tickets: list[Ticket], clients: dict[str, Client]) -> list[tuple[str, int]]:
    counts = Counter(ticket.client_id for ticket in tickets)
    ranked = counts.most_common(5)
    return [(clients[item].name if item in clients else item, count) for item, count in ranked]


def _top_problems(tickets: list[Ticket]) -> list[tuple[str, int]]:
    return Counter(ticket.issue_type for ticket in tickets).most_common(5)


def _count_missing_device_data(tickets: list[Ticket], devices: dict[str, Device]) -> int:
    total = 0
    for ticket in tickets:
        if ticket.device_id is None:
            total += 1
            continue
        device = devices.get(ticket.device_id)
        if device is None or not device.app_version:
            total += 1
    return total


def _ticket_ids_with_event(events: list[TicketEvent], event_type: str) -> set[str]:
    return {event.ticket_id for event in events if event.event_type == event_type}


def _messages_by_ticket(messages: list[TicketMessage]) -> dict[str, list[TicketMessage]]:
    grouped: dict[str, list[TicketMessage]] = {}
    for message in messages:
        grouped.setdefault(message.ticket_id, []).append(message)
    return grouped


def _seconds_between(start: datetime, end: datetime) -> float:
    return (end - start).total_seconds()


def _average(values: list[float]) -> float | None:
    if not values:
        return None
    return sum(values) / len(values)


def _format_counts(counts: dict[str, int]) -> str:
    if not counts:
        return "- none"
    return "\n".join(f"- {key}: {value}" for key, value in sorted(counts.items()))


def _format_ranked(items: list[tuple[str, int]]) -> str:
    if not items:
        return "- none"
    return "\n".join(f"- {name}: {count}" for name, count in items)


def _format_duration(seconds: float | None) -> str:
    if seconds is None:
        return "n/a"
    minutes = seconds / 60
    if minutes < 60:
        return f"{minutes:.1f} min"
    return f"{minutes / 60:.1f} h"
