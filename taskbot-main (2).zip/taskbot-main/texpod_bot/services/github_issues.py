from dataclasses import dataclass
from typing import Protocol

import httpx

from texpod_bot.domain.enums import TicketEventType
from texpod_bot.infrastructure.database.models import Client, Device, Ticket, TicketMessage
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.tickets import TicketService


class GitHubIssueClient(Protocol):
    async def create_issue(self, *, repo: str, title: str, body: str) -> "CreatedGitHubIssue":
        """Create an issue without exposing token handling to the service."""


@dataclass(frozen=True, slots=True)
class CreatedGitHubIssue:
    html_url: str
    number: int


@dataclass(frozen=True, slots=True)
class GitHubIssueSettings:
    token: str | None = None
    repo: str | None = None
    api_base_url: str = "https://api.github.com"

    @property
    def enabled(self) -> bool:
        return bool(self.token and self.repo)


class HttpxGitHubIssueClient:
    def __init__(
        self,
        *,
        token: str,
        api_base_url: str = "https://api.github.com",
        timeout_seconds: float = 10,
    ) -> None:
        self._token = token
        self._api_base_url = api_base_url.rstrip("/")
        self._timeout_seconds = timeout_seconds

    async def create_issue(self, *, repo: str, title: str, body: str) -> CreatedGitHubIssue:
        async with httpx.AsyncClient(timeout=self._timeout_seconds) as client:
            response = await client.post(
                f"{self._api_base_url}/repos/{repo}/issues",
                headers={
                    "Accept": "application/vnd.github+json",
                    "Authorization": f"Bearer {self._token}",
                    "X-GitHub-Api-Version": "2022-11-28",
                },
                json={"title": title, "body": body},
            )
            response.raise_for_status()
            payload = response.json()
        html_url = payload.get("html_url")
        number = payload.get("number")
        if not isinstance(html_url, str) or not isinstance(number, int):
            msg = "GitHub issue response is missing html_url or number"
            raise RuntimeError(msg)
        return CreatedGitHubIssue(html_url=html_url, number=number)


class GitHubIssueService:
    def __init__(
        self,
        *,
        uow: SupportUnitOfWork,
        ticket_service: TicketService,
        settings: GitHubIssueSettings,
        client: GitHubIssueClient | None = None,
    ) -> None:
        self._uow = uow
        self._tickets = ticket_service
        self._settings = settings
        self._client = client

    async def create_issue_from_ticket(self, ticket_id: str) -> CreatedGitHubIssue | None:
        if not self._settings.enabled:
            return None
        if self._settings.repo is None:
            return None

        ticket = await self._require_ticket(ticket_id)
        body = await self.format_issue_body(ticket)
        title = await self._format_issue_title(ticket)
        client = self._client or HttpxGitHubIssueClient(
            token=self._settings.token or "",
            api_base_url=self._settings.api_base_url,
        )
        try:
            issue = await client.create_issue(repo=self._settings.repo, title=title, body=body)
        except Exception as exc:
            await self._tickets.add_event(
                ticket.id,
                TicketEventType.GITHUB_ISSUE_CREATE_FAILED,
                {"error": exc.__class__.__name__},
            )
            await self._uow.commit()
            return None

        await self._tickets.add_event(
            ticket.id,
            TicketEventType.GITHUB_ISSUE_CREATED,
            {"url": issue.html_url, "number": issue.number, "repo": self._settings.repo},
        )
        await self._uow.commit()
        return issue

    async def format_issue_body(self, ticket: Ticket) -> str:
        timeline = await self._tickets.get_ticket_timeline(ticket.id)
        client = await self._uow.clients.get(ticket.client_id)
        device = await self._uow.devices.get(ticket.device_id) if ticket.device_id else None
        runbook_path = _format_runbook_path([event.payload_json for event in timeline.events])
        attachments = _format_attachments(timeline.messages)
        return (
            f"## Internal ticket\n{ticket.public_id} ({ticket.id})\n\n"
            f"## Client\n{_format_client(client)}\n\n"
            f"## Device\n{_format_device(device)}\n\n"
            f"## Issue\n"
            f"- issue_type: {ticket.issue_type}\n"
            f"- priority: {ticket.priority}\n"
            f"- status: {ticket.status}\n\n"
            f"## Timeline\n{_format_timeline(timeline.messages)}\n\n"
            f"## Runbook path\n{runbook_path}\n\n"
            f"## Attachments\n{attachments}"
        )

    async def _format_issue_title(self, ticket: Ticket) -> str:
        client = await self._uow.clients.get(ticket.client_id)
        client_name = client.name if client is not None else ticket.client_id
        issue_code = _issue_code(ticket.issue_type)
        return f"[{ticket.priority.upper()}] {issue_code} — {client_name}"

    async def _require_ticket(self, ticket_id: str) -> Ticket:
        ticket = await self._uow.tickets.get(ticket_id)
        if ticket is None:
            msg = f"Ticket {ticket_id!r} was not found"
            raise RuntimeError(msg)
        return ticket


def _issue_code(issue_type: str) -> str:
    mapping = {
        "device_offline": "KIOSK_OFFLINE",
        "menu_sync": "SYNC_FAILED",
        "software": "APP_FREEZE",
    }
    return mapping.get(issue_type, issue_type.upper())


def _format_client(client: Client | None) -> str:
    if client is None:
        return "unknown"
    return (
        f"- id: {client.id}\n"
        f"- name: {client.name}\n"
        f"- contact_name: {client.contact_name or 'unknown'}\n"
        f"- phone: {client.phone or 'unknown'}\n"
        f"- telegram_user_id: {client.telegram_user_id or 'unknown'}"
    )


def _format_device(device: Device | None) -> str:
    if device is None:
        return "unknown"
    return (
        f"- id: {device.id}\n"
        f"- device_id: {device.device_id}\n"
        f"- name: {device.name or 'unknown'}\n"
        f"- app_version: {device.app_version or 'unknown'}\n"
        f"- android_version: {device.android_version or 'unknown'}\n"
        f"- status: {device.status}"
    )


def _format_timeline(messages: list[TicketMessage]) -> str:
    if not messages:
        return "No messages"
    lines: list[str] = []
    for message in messages:
        text = message.text or "[attachment]"
        lines.append(
            f"- {message.created_at.isoformat()} {message.sender_type}"
            f"({message.sender_id or 'unknown'}): {text}"
        )
    return "\n".join(lines)


def _format_runbook_path(payloads: list[dict[str, object]]) -> str:
    lines: list[str] = []
    for payload in payloads:
        history = payload.get("history")
        if not isinstance(history, list):
            continue
        for item in history:
            if not isinstance(item, dict):
                continue
            step_key = item.get("step_key")
            selected_option = item.get("selected_option")
            next_step = item.get("next_step")
            if isinstance(step_key, str):
                lines.append(
                    f"- {step_key}"
                    f" -> {next_step if isinstance(next_step, str) else 'unknown'}"
                    f" via {selected_option if isinstance(selected_option, str) else 'n/a'}"
                )
    return "\n".join(lines) if lines else "No runbook path"


def _format_attachments(messages: list[TicketMessage]) -> str:
    attachments = [
        f"- {message.attachment_url} (message_id={message.telegram_message_id or 'unknown'})"
        for message in messages
        if message.attachment_url
    ]
    return "\n".join(attachments) if attachments else "No attachments"
