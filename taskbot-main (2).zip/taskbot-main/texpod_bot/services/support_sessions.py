from enum import StrEnum

from texpod_bot.domain.runbooks import RunbookSession
from texpod_bot.infrastructure.database.models import SupportSession
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.runbook_service import session_from_json, session_to_json
from texpod_bot.services.structured_collection import (
    CollectionSession,
    collection_from_json,
    collection_to_json,
)


class SupportSessionError(RuntimeError):
    """Base support session service error."""


class SupportSessionStateMissingError(SupportSessionError):
    """Raised when requested flow state is not present in persisted session history."""


class SupportFlowState(StrEnum):
    MAIN_MENU = "main_menu"
    CHOOSING_ISSUE = "choosing_issue"
    RUNBOOK_IN_PROGRESS = "runbook_in_progress"
    COLLECTING_DATA = "collecting_data"
    WAITING_SUPPORT = "waiting_support"
    RESOLVED = "resolved"
    CANCELLED = "cancelled"


_RUNBOOK_HISTORY_KEY = "runbook_code"
_COLLECTION_HISTORY_KIND = "collection"
_LEGACY_STATE_ALIASES = {
    "runbook": SupportFlowState.RUNBOOK_IN_PROGRESS.value,
}


class SupportSessionService:
    def __init__(self, uow: SupportUnitOfWork) -> None:
        self._uow = uow

    async def get_or_create_session(
        self,
        *,
        telegram_user_id: str,
        telegram_chat_id: str,
        client_id: str | None = None,
    ) -> SupportSession:
        return await self._uow.sessions.get_or_create(
            telegram_user_id=telegram_user_id,
            telegram_chat_id=telegram_chat_id,
            client_id=client_id,
        )

    def reset_session(self, session: SupportSession) -> SupportSession:
        session.ticket_id = None
        session.runbook_code = None
        session.current_step_key = None
        session.history_json = []
        session.state = SupportFlowState.MAIN_MENU.value
        return session

    def set_state(self, session: SupportSession, state: str | SupportFlowState) -> SupportSession:
        session.state = _normalize_state(state)
        return session

    def start_runbook(
        self,
        session: SupportSession,
        runbook_session: RunbookSession,
    ) -> SupportSession:
        return self.update_runbook_session(session, runbook_session)

    def update_runbook_session(
        self,
        session: SupportSession,
        runbook_session: RunbookSession,
    ) -> SupportSession:
        session.runbook_code = runbook_session.runbook_code
        session.current_step_key = runbook_session.current_step_key
        session.history_json = [
            item
            for item in session.history_json
            if not (isinstance(item, dict) and _RUNBOOK_HISTORY_KEY in item)
        ]
        session.history_json.insert(0, session_to_json(runbook_session))
        session.state = SupportFlowState.RUNBOOK_IN_PROGRESS.value
        return session

    def load_runbook_session(self, session: SupportSession) -> RunbookSession:
        for item in session.history_json:
            if isinstance(item, dict) and _RUNBOOK_HISTORY_KEY in item:
                return session_from_json(item)
        msg = "Support session does not have active runbook state"
        raise SupportSessionStateMissingError(msg)

    def start_collection(
        self,
        session: SupportSession,
        collection_session: CollectionSession,
    ) -> SupportSession:
        return self.update_collection_session(session, collection_session)

    def update_collection_session(
        self,
        session: SupportSession,
        collection_session: CollectionSession,
    ) -> SupportSession:
        session.history_json = [
            item
            for item in session.history_json
            if not (isinstance(item, dict) and item.get("kind") == _COLLECTION_HISTORY_KIND)
        ]
        session.history_json.append(collection_to_json(collection_session))
        session.state = SupportFlowState.COLLECTING_DATA.value
        return session

    def load_collection_session(self, session: SupportSession) -> CollectionSession:
        for item in reversed(session.history_json):
            if isinstance(item, dict) and item.get("kind") == _COLLECTION_HISTORY_KIND:
                return collection_from_json(item)
        msg = "Support session does not have active collection state"
        raise SupportSessionStateMissingError(msg)

    def bind_client(self, session: SupportSession, client_id: str) -> SupportSession:
        session.client_id = client_id
        return session

    def bind_ticket(self, session: SupportSession, ticket_id: str) -> SupportSession:
        session.ticket_id = ticket_id
        return session


def _normalize_state(state: str | SupportFlowState) -> str:
    raw = state.value if isinstance(state, SupportFlowState) else state
    return _LEGACY_STATE_ALIASES.get(raw, raw)
