## Summary

What changed?

## Related Issue

Closes #

## Type Of Change

- [ ] Bug fix
- [ ] Feature
- [ ] Bot command/task
- [ ] Refactor
- [ ] Tests
- [ ] Documentation
- [ ] Docker/deploy
- [ ] CI

## Architecture Checklist

- [ ] Domain logic remains platform-neutral.
- [ ] Telegram-specific code is only in `src/bot/telegram`.
- [ ] MAX-specific code is only in `src/bot/max`.
- [ ] Infrastructure code is only in `src/infrastructure`.
- [ ] Domain does not import Telegram/MAX SDKs, `aiogram`, `httpx`, or database drivers.
- [ ] FSM/dialog state is abstracted behind storage interfaces when used.

## Security Checklist

- [ ] No secrets committed.
- [ ] No tokens or credentials in logs, tests, README, or examples.
- [ ] `.env.example` contains only placeholders.
- [ ] Config changes are handled through `src/app/config.py`.
- [ ] Webhook secret validation is considered for production webhook behavior.

## Tests

Commands run:

```bash
ruff check .
ruff format --check .
mypy src
pytest
```

Additional deploy checks, if relevant:

```bash
docker build .
python -m app.main config-check
```

## Live Tests

- [ ] Not required
- [ ] Opt-in Telegram smoke test performed
- [ ] Opt-in MAX smoke test performed

Notes:

## Risks And Rollback

Known risks:

Rollback plan:
