---
name: Feature request
about: Propose a new feature
title: "[Feature]: "
labels: enhancement
assignees: ""
---

## Summary

What should be added?

## User Value

Who needs this and why?

## Scope

- [ ] Domain use case
- [ ] Telegram adapter
- [ ] MAX adapter
- [ ] External API integration
- [ ] Storage/FSM
- [ ] Docker/deploy
- [ ] Documentation
- [ ] Tests

## Expected Behavior

Describe the desired behavior.

## Platform Notes

Telegram-specific behavior:

MAX-specific behavior:

Do not assume MAX behaves like Telegram.

## Configuration

List new environment variables if needed.

Do not include real values.

## Acceptance Criteria

- [ ]
- [ ]
- [ ]

## Test Plan

How should this be tested without live tokens or network access?
