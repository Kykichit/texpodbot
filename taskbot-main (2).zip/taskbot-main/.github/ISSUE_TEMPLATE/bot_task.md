---
name: Bot command/task
about: Add or change a bot command, menu action, callback, or text flow
title: "[Bot Task]: "
labels: bot, task
assignees: ""
---

## Command Or Action

Examples: `/start`, `/help`, `main_menu`, `create_order`.

## Platforms

- [ ] Telegram
- [ ] MAX
- [ ] Both

## Domain Behavior

Describe the platform-neutral business behavior.

## Telegram Mapping

Describe message, command, callback, or keyboard behavior.

## MAX Mapping

Describe update, message, callback, or keyboard behavior.

MAX behavior must be verified against current MAX API docs when uncertain.

## State/FSM

Does this require dialog state?

- [ ] No
- [ ] Yes, storage interface required
- [ ] Yes, existing storage interface can be reused

## Acceptance Criteria

- [ ]
- [ ]
- [ ]

## Tests Required

- [ ] Domain unit tests
- [ ] Telegram adapter tests
- [ ] MAX adapter tests
- [ ] Integration tests with mocked external APIs
- [ ] Opt-in live smoke test
