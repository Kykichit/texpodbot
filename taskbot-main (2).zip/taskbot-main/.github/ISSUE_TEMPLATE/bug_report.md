---
name: Bug report
about: Report a bug or regression
title: "[Bug]: "
labels: bug
assignees: ""
---

## Summary

Describe the bug clearly.

## Affected Platform

- [ ] Telegram
- [ ] MAX
- [ ] Both
- [ ] Domain logic
- [ ] Infrastructure
- [ ] CI/CD
- [ ] Docker/deploy

## Current Behavior

What happens now?

## Expected Behavior

What should happen?

## Steps To Reproduce

1.
2.
3.

## Environment

- `APP_ENV`:
- `BOT_MODE`:
- Python version:
- Deployment target:

Do not paste secrets.

## Logs Or Errors

Paste sanitized logs only. Remove tokens, webhook secrets, database URLs, and credentials.

## Checks

- [ ] Reproduced locally
- [ ] Does not require real secrets to reproduce
- [ ] Added failing test or described why not possible
