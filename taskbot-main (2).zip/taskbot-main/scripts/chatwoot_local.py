from __future__ import annotations

import argparse
import os
import shutil
import socket
import subprocess
import sys
import urllib.error
import urllib.request
import webbrowser
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

DEFAULT_CHATWOOT_LOCAL_DIR = r"C:\chatwoot-local"
DEFAULT_CHATWOOT_LOCAL_COMPOSE_FILE = "docker-compose.chatwoot.yml"
DEFAULT_CHATWOOT_LOCAL_BASE_URL = "http://localhost:3000"
DEFAULT_CHATWOOT_WEBHOOK_URL = "http://host.docker.internal:18080/chatwoot/webhook"
DEMO_ENV_PATH = Path(".env.demo")
DEMO_ENV_EXAMPLE_PATH = Path(".env.demo.example")
SECRET_KEYS = ("TOKEN", "SECRET", "PASSWORD", "KEY")
CHATWOOT_ENV_KEYS = (
    "CHATWOOT_ENABLED",
    "CHATWOOT_BASE_URL",
    "CHATWOOT_ACCOUNT_ID",
    "CHATWOOT_INBOX_ID",
    "CHATWOOT_API_TOKEN",
    "CHATWOOT_WEBHOOK_SECRET",
)


@dataclass(frozen=True)
class UrlCheckResult:
    ok: bool
    status_code: int | None = None
    error: str | None = None


@dataclass(frozen=True)
class ComposeValidationResult:
    ok: bool
    message: str


@dataclass(frozen=True)
class DoctorCheck:
    level: str
    label: str
    detail: str


def load_env_file(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}

    values: dict[str, str] = {}
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip("\"'")
    return values


def load_demo_env() -> dict[str, str]:
    values = load_env_file(DEMO_ENV_EXAMPLE_PATH)
    values.update(load_env_file(DEMO_ENV_PATH))
    values.update({key: value for key, value in os.environ.items() if key.startswith("CHATWOOT_")})
    return values


def default_chatwoot_dir() -> Path:
    return Path(DEFAULT_CHATWOOT_LOCAL_DIR)


def resolve_chatwoot_dir(env: Mapping[str, str] | None = None) -> Path:
    values = env or {}
    return Path(values.get("CHATWOOT_LOCAL_DIR") or str(default_chatwoot_dir()))


def resolve_compose_file_name(env: Mapping[str, str] | None = None) -> str:
    values = env or {}
    return values.get("CHATWOOT_LOCAL_COMPOSE_FILE") or DEFAULT_CHATWOOT_LOCAL_COMPOSE_FILE


def resolve_compose_file(env: Mapping[str, str] | None = None) -> Path:
    values = env or {}
    compose_file = Path(resolve_compose_file_name(values))
    if compose_file.is_absolute():
        return compose_file
    return resolve_chatwoot_dir(values) / compose_file


def build_compose_cmd(
    chatwoot_dir: Path,
    compose_file: str | Path,
    compose_args: Sequence[str],
) -> list[str]:
    compose_path = Path(compose_file)
    if not compose_path.is_absolute():
        compose_path = chatwoot_dir / compose_path
    return ["docker", "compose", "-f", str(compose_path), *compose_args]


build_compose_command = build_compose_cmd


def validate_compose_file(compose_path: Path) -> ComposeValidationResult:
    if not compose_path.exists():
        return ComposeValidationResult(False, f"compose file not found: {compose_path}")

    text = compose_path.read_text(encoding="utf-8")
    if "pgvector/pgvector:pg16" not in text:
        return ComposeValidationResult(
            False,
            "compose file should use pgvector/pgvector:pg16 for Chatwoot PostgreSQL",
        )
    return ComposeValidationResult(True, "compose file uses pgvector/pgvector:pg16")


def redact(name: str, value: str | None) -> str:
    if not value:
        return "missing"
    if any(marker in name.upper() for marker in SECRET_KEYS):
        return "configured"
    return value


redact_env_value = redact


def read_env_keys_status(path: Path, keys: Sequence[str]) -> dict[str, str]:
    values = load_env_file(path)
    return {key: "yes" if values.get(key) else "no" for key in keys}


def check_url(
    url: str,
    *,
    timeout: float = 2.0,
    opener: Callable[..., Any] | None = None,
) -> UrlCheckResult:
    open_url = opener or urllib.request.urlopen
    try:
        with open_url(url, timeout=timeout) as response:
            status_code = int(getattr(response, "status", response.getcode()))
    except urllib.error.HTTPError as exc:
        return UrlCheckResult(ok=False, status_code=exc.code, error=f"HTTP {exc.code}")
    except OSError as exc:
        return UrlCheckResult(ok=False, error=str(exc))
    return UrlCheckResult(ok=200 <= status_code < 500, status_code=status_code)


def require_confirm(confirm: bool) -> None:
    if not confirm:
        raise RuntimeError(
            "Refusing reset: pass --confirm to delete local Chatwoot DB/Redis volumes."
        )


require_reset_confirmation = require_confirm


def _is_port_open(host: str, port: int, timeout: float = 1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def _docker_available() -> bool:
    return shutil.which("docker") is not None


def _docker_compose_available() -> bool:
    docker_path = shutil.which("docker")
    if docker_path is None:
        return False
    result = subprocess.run(  # noqa: S603
        [docker_path, "compose", "version"],
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    return result.returncode == 0


def check_inbox_account_consistency(
    env: Mapping[str, str],
    *,
    runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
) -> DoctorCheck:
    account_id = env.get("CHATWOOT_ACCOUNT_ID", "")
    inbox_id = env.get("CHATWOOT_INBOX_ID", "")
    if not account_id or not inbox_id:
        return DoctorCheck("WARN", "Chatwoot inbox/account", "missing account_id or inbox_id")
    if not account_id.isdigit() or not inbox_id.isdigit():
        return DoctorCheck("WARN", "Chatwoot inbox/account", "ids must be numeric")

    command = build_compose_cmd(
        resolve_chatwoot_dir(env),
        resolve_compose_file_name(env),
        [
            "exec",
            "-T",
            "chatwoot-postgres",
            "psql",
            "-U",
            "chatwoot",
            "-d",
            "chatwoot",
            "-t",
            "-A",
            "-F",
            ",",
            "-c",
            f"select id, account_id, channel_type from inboxes where id = {int(inbox_id)};",  # noqa: S608
        ],
    )
    result = runner(command, check=False, capture_output=True, text=True)
    if result.returncode != 0:
        return DoctorCheck("WARN", "Chatwoot inbox/account", "local DB check unavailable")

    row = result.stdout.strip().splitlines()[0] if result.stdout.strip() else ""
    parts = [part.strip() for part in row.split(",")]
    if len(parts) != 3:
        return DoctorCheck("FAIL", "Chatwoot inbox/account", f"inbox {inbox_id} not found")
    _, actual_account_id, channel_type = parts
    if actual_account_id != account_id:
        return DoctorCheck(
            "FAIL",
            "Chatwoot inbox/account",
            f"inbox {inbox_id} belongs to account {actual_account_id}, expected {account_id}",
        )
    if channel_type != "Channel::Api":
        return DoctorCheck(
            "FAIL",
            "Chatwoot inbox/account",
            f"inbox {inbox_id} channel_type is {channel_type}, expected Channel::Api",
        )
    return DoctorCheck("OK", "Chatwoot inbox/account", "inbox matches account and Channel::Api")


def _print_check(check: DoctorCheck) -> None:
    print(f"[{check.level}] {check.label}: {check.detail}")


def command_doctor(env: Mapping[str, str] | None = None) -> int:
    values = dict(env or load_demo_env())
    chatwoot_dir = resolve_chatwoot_dir(values)
    compose_path = resolve_compose_file(values)
    local_base_url = values.get("CHATWOOT_LOCAL_BASE_URL", DEFAULT_CHATWOOT_LOCAL_BASE_URL)
    checks: list[DoctorCheck] = []

    checks.append(
        DoctorCheck(
            "OK" if chatwoot_dir.exists() else "FAIL",
            "CHATWOOT_LOCAL_DIR",
            str(chatwoot_dir),
        )
    )
    checks.append(
        DoctorCheck(
            "OK" if compose_path.exists() else "FAIL",
            "Chatwoot compose file",
            str(compose_path),
        )
    )

    checks.append(DoctorCheck("OK" if _docker_available() else "FAIL", "Docker CLI", "docker"))
    checks.append(
        DoctorCheck(
            "OK" if _docker_compose_available() else "FAIL",
            "Docker Compose",
            "docker compose",
        )
    )

    validation = validate_compose_file(compose_path)
    checks.append(
        DoctorCheck(
            "OK" if validation.ok else "FAIL",
            "PostgreSQL pgvector image",
            validation.message,
        )
    )

    port_open = _is_port_open("127.0.0.1", 3000)
    checks.append(
        DoctorCheck(
            "OK" if port_open else "WARN",
            "Port 3000",
            "listening" if port_open else "not listening; Chatwoot may be stopped",
        )
    )

    url_result = check_url(local_base_url)
    checks.append(
        DoctorCheck(
            "OK" if url_result.ok else "WARN",
            "Chatwoot UI",
            f"{local_base_url} -> {url_result.status_code or url_result.error}",
        )
    )

    checks.append(
        DoctorCheck(
            "OK" if DEMO_ENV_PATH.exists() else "WARN",
            "taskbot .env.demo",
            "present"
            if DEMO_ENV_PATH.exists()
            else "missing; run make demo-copy-env or copy example",
        )
    )

    chatwoot_base_url = values.get("CHATWOOT_BASE_URL")
    checks.append(
        DoctorCheck(
            "OK" if chatwoot_base_url else "WARN",
            "CHATWOOT_BASE_URL",
            redact("CHATWOOT_BASE_URL", chatwoot_base_url),
        )
    )

    webhook_secret = values.get("CHATWOOT_WEBHOOK_SECRET")
    checks.append(
        DoctorCheck(
            "OK" if webhook_secret else "WARN",
            "CHATWOOT_WEBHOOK_SECRET",
            redact("CHATWOOT_WEBHOOK_SECRET", webhook_secret),
        )
    )

    key_status = read_env_keys_status(DEMO_ENV_PATH, CHATWOOT_ENV_KEYS)
    for key, status in key_status.items():
        checks.append(DoctorCheck("OK" if status == "yes" else "WARN", key, status))
    checks.append(check_inbox_account_consistency(values))

    for check in checks:
        _print_check(check)

    return 1 if any(check.level == "FAIL" for check in checks) else 0


def _run_compose(compose_args: Sequence[str]) -> int:
    values = load_demo_env()
    chatwoot_dir = resolve_chatwoot_dir(values)
    compose_file = resolve_compose_file_name(values)
    command = build_compose_cmd(chatwoot_dir, compose_file, compose_args)
    return subprocess.run(command, check=False).returncode  # noqa: S603


def command_ps() -> int:
    return _run_compose(["ps"])


def command_prepare() -> int:
    return _run_compose(
        ["run", "--rm", "chatwoot-rails", "bundle", "exec", "rails", "db:chatwoot_prepare"]
    )


def command_up() -> int:
    return _run_compose(["up", "-d"])


def command_stop() -> int:
    return _run_compose(["stop"])


def command_logs() -> int:
    return _run_compose(["logs", "-f", "chatwoot-rails", "chatwoot-worker"])


def command_open() -> int:
    values = load_demo_env()
    url = values.get("CHATWOOT_LOCAL_BASE_URL", DEFAULT_CHATWOOT_LOCAL_BASE_URL)
    opened = webbrowser.open(url)
    print(f"Opening {url}")
    return 0 if opened else 1


def command_webhook_info() -> int:
    values = load_demo_env()
    webhook_url = values.get("CHATWOOT_WEBHOOK_URL", DEFAULT_CHATWOOT_WEBHOOK_URL)
    print("Chatwoot UI:")
    print(values.get("CHATWOOT_LOCAL_BASE_URL", DEFAULT_CHATWOOT_LOCAL_BASE_URL))
    print()
    print("Taskbot Chatwoot webhook URL:")
    print(webhook_url)
    print()
    print("Put this URL into Chatwoot Bot/API Inbox webhook URL.")
    print()
    print("Copy Webhook Secret from Chatwoot UI into .env.demo:")
    print("CHATWOOT_WEBHOOK_SECRET=<secret from Chatwoot UI>")
    print()
    print("Set in .env.demo:")
    print("CHATWOOT_ENABLED=true")
    print("CHATWOOT_BASE_URL=http://host.docker.internal:3000")
    print("CHATWOOT_ACCOUNT_ID=<account_id>")
    print("CHATWOOT_INBOX_ID=<inbox_id>")
    print("CHATWOOT_API_TOKEN=<user access token>")
    print("CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS=true  # local/demo only")
    print()
    print("Do not commit .env.demo and do not paste secrets into logs or screenshots.")
    return 0


def command_reset(*, confirm: bool) -> int:
    try:
        require_confirm(confirm)
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        print("This removes local Chatwoot DB/Redis volumes.", file=sys.stderr)
        return 1
    return _run_compose(["down", "-v", "--remove-orphans"])


def command_stop_taskbot_polling() -> int:
    docker_path = shutil.which("docker")
    if docker_path is None:
        print("Docker CLI is not available.", file=sys.stderr)
        return 1
    list_result = subprocess.run(  # noqa: S603
        [docker_path, "ps", "-q", "--filter", "name=taskbot-demo-demo-app-run"],
        check=False,
        capture_output=True,
        text=True,
    )
    if list_result.returncode != 0:
        print("Could not list taskbot demo polling containers.", file=sys.stderr)
        return list_result.returncode
    container_ids = [line.strip() for line in list_result.stdout.splitlines() if line.strip()]
    if not container_ids:
        print("No taskbot demo polling containers found.")
        return 0
    stop_result = subprocess.run([docker_path, "stop", *container_ids], check=False)  # noqa: S603
    return stop_result.returncode


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Local self-host Chatwoot helper")
    subparsers = parser.add_subparsers(dest="command", required=True)

    for command in (
        "doctor",
        "ps",
        "prepare",
        "up",
        "stop",
        "logs",
        "open",
        "webhook-info",
        "stop-taskbot-polling",
    ):
        subparsers.add_parser(command)

    reset_parser = subparsers.add_parser("reset")
    reset_parser.add_argument("--confirm", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)

    if args.command == "doctor":
        return command_doctor()
    if args.command == "ps":
        return command_ps()
    if args.command == "prepare":
        return command_prepare()
    if args.command == "up":
        return command_up()
    if args.command == "stop":
        return command_stop()
    if args.command == "logs":
        return command_logs()
    if args.command == "open":
        return command_open()
    if args.command == "webhook-info":
        return command_webhook_info()
    if args.command == "reset":
        return command_reset(confirm=bool(args.confirm))
    if args.command == "stop-taskbot-polling":
        return command_stop_taskbot_polling()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
