#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ -z "${TASKBOT_APP_DIR:-}" ]]; then
  if [[ "$(basename "$ROOT_DIR")" == "current" && -d "$(dirname "$ROOT_DIR")/releases" ]]; then
    TASKBOT_APP_DIR="$(dirname "$ROOT_DIR")"
  else
    TASKBOT_APP_DIR="$ROOT_DIR"
  fi
fi

TASKBOT_SHARED_DIR="${TASKBOT_SHARED_DIR:-$TASKBOT_APP_DIR/shared}"
BACKUP_DIR="${BACKUP_DIR:-$TASKBOT_SHARED_DIR/backups}"
VPS_ENV_FILE="${VPS_ENV_FILE:-$TASKBOT_SHARED_DIR/.env.vps}"
CHATWOOT_ENV_FILE="${CHATWOOT_ENV_FILE:-$TASKBOT_SHARED_DIR/.env.chatwoot.production}"

export VPS_ENV_FILE CHATWOOT_ENV_FILE
COMPOSE_PROJECT_NAME="${COMPOSE_PROJECT_NAME:-taskbot}"
export COMPOSE_PROJECT_NAME
COMPOSE=(docker compose -p "$COMPOSE_PROJECT_NAME" --env-file "$VPS_ENV_FILE" -f docker-compose.vps.yml)
RESTORE_CHECK_DB=""
RESTORE_CHECK_USER=""

usage() {
  cat <<'EOF'
Usage: scripts/restore_check.sh [taskbot|chatwoot|all|/path/to/backup.dump.gz]

Restores backups into disposable PostgreSQL databases and drops them afterwards.
It never restores into production databases.
EOF
}

fail() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

env_value() {
  local file="$1"
  local key="$2"
  grep -E "^${key}=" "$file" | tail -n 1 | cut -d= -f2-
}

postgres_user() {
  local value
  value="$(env_value "$VPS_ENV_FILE" POSTGRES_USER || true)"
  printf '%s\n' "${value:-postgres}"
}

latest_backup() {
  local target="$1"
  [[ -d "$BACKUP_DIR" ]] || fail "No backup directory found: $BACKUP_DIR."
  find "$BACKUP_DIR" -maxdepth 1 -type f -name "${target}-*.dump.gz" -printf '%T@ %p\0' \
    | sort -z -nr \
    | head -z -n 1 \
    | tr -d '\0' \
    | cut -d' ' -f2-
}

drop_check_database() {
  local db_name="$1"
  local db_user="$2"
  "${COMPOSE[@]}" exec -T postgres dropdb -U "$db_user" --if-exists "$db_name" >/dev/null
}

cleanup_check_database() {
  if [[ -n "$RESTORE_CHECK_DB" && -n "$RESTORE_CHECK_USER" ]]; then
    drop_check_database "$RESTORE_CHECK_DB" "$RESTORE_CHECK_USER" || true
  fi
}

restore_check_file() {
  local backup_file="$1"
  local db_user
  local tmp_db

  [[ -f "$backup_file" ]] || fail "Backup file not found: $backup_file"

  db_user="$(postgres_user)"
  tmp_db="restore_check_$(date -u +%Y%m%d%H%M%S)_$$"

  printf 'Checking backup with disposable database: %s\n' "$tmp_db"
  "${COMPOSE[@]}" exec -T postgres createdb -U "$db_user" "$tmp_db"
  RESTORE_CHECK_DB="$tmp_db"
  RESTORE_CHECK_USER="$db_user"
  trap cleanup_check_database EXIT

  gzip -dc "$backup_file" \
    | "${COMPOSE[@]}" exec -T postgres pg_restore -U "$db_user" -d "$tmp_db" --no-owner --no-privileges

  drop_check_database "$tmp_db" "$db_user"
  RESTORE_CHECK_DB=""
  RESTORE_CHECK_USER=""
  trap - EXIT
  printf 'Restore check passed: %s\n' "$backup_file"
}

restore_check_target() {
  local target="$1"
  local backup_file
  backup_file="$(latest_backup "$target")"
  [[ -n "$backup_file" ]] || fail "No backup found for $target in $BACKUP_DIR."
  restore_check_file "$backup_file"
}

case "${1:-all}" in
  taskbot|chatwoot)
    restore_check_target "$1"
    ;;
  all)
    restore_check_target taskbot
    restore_check_target chatwoot
    ;;
  -h|--help|help)
    usage
    ;;
  *)
    restore_check_file "$1"
    ;;
esac
