#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ -z "${TASKBOT_APP_DIR:-}" ]]; then
  if [[ "$(basename "$ROOT_DIR")" == "current" && -d "$(dirname "$ROOT_DIR")/releases" ]]; then
    TASKBOT_APP_DIR="$(dirname "$ROOT_DIR")"
  else
    TASKBOT_APP_DIR="$ROOT_DIR"
  fi
fi

TASKBOT_SHARED_DIR="${TASKBOT_SHARED_DIR:-$TASKBOT_APP_DIR/shared}"
BACKUP_DIR="${BACKUP_DIR:-$TASKBOT_SHARED_DIR/backups}"
BACKUP_RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-14}"
VPS_ENV_FILE="${VPS_ENV_FILE:-$TASKBOT_SHARED_DIR/.env.vps}"
CHATWOOT_ENV_FILE="${CHATWOOT_ENV_FILE:-$TASKBOT_SHARED_DIR/.env.chatwoot.production}"

export VPS_ENV_FILE CHATWOOT_ENV_FILE
COMPOSE_PROJECT_NAME="${COMPOSE_PROJECT_NAME:-taskbot}"
export COMPOSE_PROJECT_NAME
COMPOSE=(docker compose -p "$COMPOSE_PROJECT_NAME" --env-file "$VPS_ENV_FILE" -f docker-compose.vps.yml)

usage() {
  cat <<'EOF'
Usage: scripts/backup.sh <taskbot|chatwoot|all|status>

Creates timestamped PostgreSQL custom-format backups under:
  /opt/taskbot/shared/backups

Set BACKUP_RETENTION_DAYS to prune older backups after a successful backup.
EOF
}

fail() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

env_value() {
  local file="$1"
  local key="$2"
  grep -E "^${key}=" "$file" | tail -n 1 | cut -d= -f2-
}

require_file() {
  [[ -f "$1" ]] || fail "Missing $1."
}

postgres_user() {
  env_value "$VPS_ENV_FILE" POSTGRES_USER || true
}

database_name() {
  local target="$1"
  case "$target" in
    taskbot) env_value "$VPS_ENV_FILE" TASKBOT_DB || true ;;
    chatwoot) env_value "$VPS_ENV_FILE" CHATWOOT_DB || true ;;
    *) fail "Unknown backup target: $target" ;;
  esac
}

backup_one() {
  local target="$1"
  local db_name
  local db_user
  local timestamp
  local output
  local tmp_output

  db_name="$(database_name "$target")"
  db_name="${db_name:-$target}"
  db_user="$(postgres_user)"
  db_user="${db_user:-postgres}"
  timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
  output="$BACKUP_DIR/${target}-${timestamp}.dump.gz"
  tmp_output="${output}.part"

  mkdir -p "$BACKUP_DIR"
  umask 077

  printf 'Creating %s backup: %s\n' "$target" "$output"
  if "${COMPOSE[@]}" exec -T postgres pg_dump -U "$db_user" -d "$db_name" -Fc \
    | gzip -9 > "$tmp_output"; then
    mv "$tmp_output" "$output"
  else
    rm -f "$tmp_output"
    fail "Backup failed for $target."
  fi
  printf 'Backup complete: %s\n' "$output"
}

prune_old_backups() {
  [[ "$BACKUP_RETENTION_DAYS" =~ ^[0-9]+$ ]] \
    || fail "BACKUP_RETENTION_DAYS must be a non-negative integer."
  find "$BACKUP_DIR" -type f -name '*.dump.gz' -mtime +"$BACKUP_RETENTION_DAYS" -print -delete
}

backup_status() {
  if [[ ! -d "$BACKUP_DIR" ]]; then
    printf 'No backup directory found: %s\n' "$BACKUP_DIR"
    return
  fi

  printf 'Backup directory: %s\n' "$BACKUP_DIR"
  find "$BACKUP_DIR" -maxdepth 1 -type f -name '*.dump.gz' -printf '%TY-%Tm-%Td %TH:%TM %s %p\n' \
    | sort -r \
    | head -n 20
}

run_backup() {
  local target="$1"

  case "$target" in
    taskbot|chatwoot)
      require_file "$VPS_ENV_FILE"
      backup_one "$target"
      prune_old_backups
      ;;
    all)
      require_file "$VPS_ENV_FILE"
      backup_one taskbot
      backup_one chatwoot
      prune_old_backups
      ;;
    status)
      backup_status
      ;;
    -h|--help|help|"")
      usage
      ;;
    *)
      usage
      fail "Unknown backup target: $target"
      ;;
  esac
}

run_backup "${1:-}"
