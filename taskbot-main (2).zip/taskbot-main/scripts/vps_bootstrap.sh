#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

TASKBOT_APP_DIR="${TASKBOT_APP_DIR:-/opt/taskbot}"
TASKBOT_SHARED_DIR="${TASKBOT_SHARED_DIR:-$TASKBOT_APP_DIR/shared}"
TASKBOT_DEPLOY_USER="${TASKBOT_DEPLOY_USER:-${SUDO_USER:-$USER}}"
BOT_DOMAIN="${BOT_DOMAIN:-}"
CHATWOOT_DOMAIN="${CHATWOOT_DOMAIN:-}"

usage() {
  cat <<'EOF'
Usage: scripts/vps_bootstrap.sh

First-time VPS bootstrap preflight. It checks Docker/Compose, creates the
/opt/taskbot release/shared directory layout, copies missing env files from
examples, checks DNS when domains are provided, checks local ports 80/443, and
prints the next deploy commands.

Optional environment:
  TASKBOT_APP_DIR=/opt/taskbot
  TASKBOT_DEPLOY_USER=taskbot
  BOT_DOMAIN=bot.example.com
  CHATWOOT_DOMAIN=chatwoot.example.com
EOF
}

fail() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

warn() {
  printf 'WARN: %s\n' "$*" >&2
}

info() {
  printf 'OK: %s\n' "$*"
}

need_file() {
  [[ -f "$1" ]] || fail "Missing required file: $1"
}

check_docker() {
  command -v docker >/dev/null 2>&1 || fail "Docker is not installed or not on PATH."
  docker version >/dev/null 2>&1 || fail "Docker daemon is not reachable for the current user."
  docker compose version >/dev/null || fail "Docker Compose v2 is required."
  info "Docker and Compose v2 are available."
}

create_layout() {
  mkdir -p \
    "$TASKBOT_APP_DIR/releases" \
    "$TASKBOT_SHARED_DIR" \
    "$TASKBOT_SHARED_DIR/backups"
  chown -R "$TASKBOT_DEPLOY_USER:$TASKBOT_DEPLOY_USER" "$TASKBOT_APP_DIR"
  chmod 700 "$TASKBOT_SHARED_DIR" "$TASKBOT_SHARED_DIR/backups"
  info "Created VPS directories under $TASKBOT_APP_DIR for $TASKBOT_DEPLOY_USER."
}

copy_env_if_missing() {
  local source="$1"
  local target="$2"

  need_file "$source"
  if [[ -f "$target" ]]; then
    info "Env file exists: $target"
    return
  fi

  cp "$source" "$target"
  chown "$TASKBOT_DEPLOY_USER:$TASKBOT_DEPLOY_USER" "$target"
  chmod 600 "$target"
  info "Created $target from $(basename "$source"). Fill real values before deploy."
}

load_env_value() {
  local file="$1"
  local key="$2"
  if [[ ! -f "$file" ]]; then
    return
  fi
  grep -E "^${key}=" "$file" | tail -n 1 | cut -d= -f2-
}

load_domains_from_env() {
  local env_file="$TASKBOT_SHARED_DIR/.env.vps"
  if [[ -z "$BOT_DOMAIN" ]]; then
    BOT_DOMAIN="$(load_env_value "$env_file" BOT_DOMAIN || true)"
  fi
  if [[ -z "$CHATWOOT_DOMAIN" ]]; then
    CHATWOOT_DOMAIN="$(load_env_value "$env_file" CHATWOOT_DOMAIN || true)"
  fi
}

check_dns_name() {
  local name="$1"
  local label="$2"

  if [[ -z "$name" ]]; then
    warn "$label is not set; skipping DNS check."
    return
  fi
  if [[ "$name" == *"<"* || "$name" == *">"* ]]; then
    warn "$label still looks like a placeholder; skipping DNS check."
    return
  fi

  if command -v getent >/dev/null 2>&1; then
    if getent ahosts "$name" >/dev/null; then
      info "$label resolves: $name"
      return
    fi
    warn "$label does not resolve via getent: $name"
    return
  fi

  if command -v nslookup >/dev/null 2>&1; then
    if nslookup "$name" >/dev/null 2>&1; then
      info "$label resolves: $name"
      return
    fi
    warn "$label does not resolve via nslookup: $name"
    return
  fi

  warn "No DNS lookup tool found; install dnsutils or use getent to verify $label."
}

check_dns() {
  load_domains_from_env
  check_dns_name "$BOT_DOMAIN" BOT_DOMAIN
  check_dns_name "$CHATWOOT_DOMAIN" CHATWOOT_DOMAIN
}

check_port() {
  local port="$1"
  if command -v ss >/dev/null 2>&1; then
    if ss -ltn "( sport = :$port )" | awk 'NR > 1 { found = 1 } END { exit found ? 0 : 1 }'; then
      warn "Port $port is already listening locally. Stop the conflicting service before Caddy."
    else
      info "Port $port is free locally."
    fi
    return
  fi

  warn "Cannot check port $port because ss is unavailable."
}

check_ports() {
  check_port 80
  check_port 443
}

print_firewall_guidance() {
  cat <<'EOF'

Firewall guidance:
- Allow 22/tcp for SSH, ideally restricted by source IP.
- Allow 80/tcp and 443/tcp for Caddy and Let's Encrypt.
- Do not expose PostgreSQL, Redis, app:8080, or Chatwoot:3000 publicly.
- If ufw is enabled, verify with: sudo ufw status verbose
EOF
}

print_next_commands() {
  cat <<EOF

Next commands:
1. Fill secrets on the VPS:
   sudoedit $TASKBOT_SHARED_DIR/.env.vps
   sudoedit $TASKBOT_SHARED_DIR/.env.chatwoot.production

2. Put a release bundle under:
   $TASKBOT_APP_DIR/releases/<sha>
   and update:
   ln -sfn $TASKBOT_APP_DIR/releases/<sha> $TASKBOT_APP_DIR/current

3. Validate and start:
   cd $TASKBOT_APP_DIR/current
   TASKBOT_APP_DIR=$TASKBOT_APP_DIR bash scripts/setup.sh doctor
   TASKBOT_APP_DIR=$TASKBOT_APP_DIR bash scripts/setup.sh deploy

4. Check:
   TASKBOT_APP_DIR=$TASKBOT_APP_DIR bash scripts/setup.sh status
EOF
}

main() {
  case "${1:-}" in
    -h|--help|help)
      usage
      return 0
      ;;
    "")
      ;;
    *)
      usage
      fail "Unknown argument: $1"
      ;;
  esac

  need_file .env.vps.example
  need_file .env.chatwoot.production.example
  check_docker
  create_layout
  copy_env_if_missing .env.vps.example "$TASKBOT_SHARED_DIR/.env.vps"
  copy_env_if_missing .env.chatwoot.production.example \
    "$TASKBOT_SHARED_DIR/.env.chatwoot.production"
  print_firewall_guidance
  check_dns
  check_ports
  print_next_commands
}

main "$@"
