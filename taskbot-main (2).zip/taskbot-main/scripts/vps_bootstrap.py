from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TASKBOT_ENV = ROOT / ".env.vps"
CHATWOOT_ENV = ROOT / ".env.chatwoot.production"
COMPOSE_FILE = ROOT / "docker-compose.vps.yml"
CADDYFILE = ROOT / "deploy" / "caddy" / "Caddyfile"


def main() -> int:
    parser = argparse.ArgumentParser(description="All-in-one VPS deployment helper")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("doctor", help="check local files and safe production posture")
    subparsers.add_parser("compose-config", help="run docker compose config")
    subparsers.add_parser("print-commands", help="print the manual deploy command sequence")
    args = parser.parse_args()

    if args.command == "doctor":
        return doctor()
    if args.command == "compose-config":
        return run(
            [
                "docker",
                "compose",
                "--env-file",
                ".env.vps",
                "-f",
                "docker-compose.vps.yml",
                "config",
            ]
        )
    if args.command == "print-commands":
        print_commands()
        return 0
    return 2


def doctor() -> int:
    failures: list[str] = []

    for binary in ("docker",):
        if shutil.which(binary) is None:
            failures.append(f"{binary} is not available on PATH")

    for path in (TASKBOT_ENV, CHATWOOT_ENV, COMPOSE_FILE, CADDYFILE):
        if not path.exists():
            failures.append(f"missing {path.relative_to(ROOT)}")

    values = read_env(TASKBOT_ENV) if TASKBOT_ENV.exists() else {}
    chatwoot_values = read_env(CHATWOOT_ENV) if CHATWOOT_ENV.exists() else {}

    if values.get("APP_ENV") != "production":
        failures.append("APP_ENV must be production")
    if values.get("CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS") != "false":
        failures.append("CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS must be false")

    for key in ("BOT_DOMAIN", "CHATWOOT_DOMAIN", "WEBHOOK_BASE_URL", "TELEGRAM_WEBHOOK_URL"):
        value = values.get(key, "")
        if not value or "<" in value or ">" in value:
            failures.append(f"{key} still looks like a placeholder")
        if "localhost" in value or "127.0.0.1" in value:
            failures.append(f"{key} must not use localhost in production")

    frontend_url = chatwoot_values.get("FRONTEND_URL", "")
    if not frontend_url or "<" in frontend_url or ">" in frontend_url:
        failures.append("FRONTEND_URL still looks like a placeholder")
    if "localhost" in frontend_url or "127.0.0.1" in frontend_url:
        failures.append("FRONTEND_URL must not use localhost in production")

    if failures:
        for failure in failures:
            print(f"FAIL: {failure}")
        return 1

    print("OK: all-in-one VPS files and production posture look valid")
    return 0


def read_env(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def print_commands() -> None:
    compose = "docker compose --env-file .env.vps -f docker-compose.vps.yml"
    print(
        "\n".join(
            (
                "cp .env.vps.example .env.vps",
                "cp .env.chatwoot.production.example .env.chatwoot.production",
                f"{compose} config",
                f"{compose} up -d postgres redis",
                f"{compose} run --rm chatwoot-rails bundle exec rails db:chatwoot_prepare",
                f"{compose} run --rm app python -m app.main db-upgrade",
                f"{compose} up -d",
            )
        )
    )


def run(command: list[str]) -> int:
    completed = subprocess.run(command, cwd=ROOT, check=False)  # noqa: S603
    return completed.returncode


if __name__ == "__main__":
    sys.exit(main())
