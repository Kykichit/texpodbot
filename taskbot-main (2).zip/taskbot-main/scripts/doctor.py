from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]

PLACEHOLDER_MARKERS = (
    "<",
    ">",
    "changeme",
    "change-me",
    "placeholder",
    "not_real",
    "dummy",
    "example.test",
)


@dataclass(frozen=True, slots=True)
class EnvIssue:
    key: str
    message: str


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate taskbot environment files")
    subparsers = parser.add_subparsers(dest="command", required=True)

    vps_parser = subparsers.add_parser("vps", help="validate all-in-one VPS env files")
    vps_parser.add_argument("--taskbot-env", default=".env.vps")
    vps_parser.add_argument("--chatwoot-env", default=".env.chatwoot.production")

    env_parser = subparsers.add_parser("env", help="validate one taskbot env file")
    env_parser.add_argument("path")
    env_parser.add_argument("--production", action="store_true")

    args = parser.parse_args()
    if args.command == "vps":
        return print_result(
            validate_vps_env(
                ROOT / args.taskbot_env,
                ROOT / args.chatwoot_env,
            )
        )
    if args.command == "env":
        return print_result(validate_taskbot_env(ROOT / args.path, production=args.production))
    return 2


def validate_vps_env(taskbot_path: Path, chatwoot_path: Path) -> list[EnvIssue]:
    issues: list[EnvIssue] = []
    taskbot = read_env_file(taskbot_path, issues)
    chatwoot = read_env_file(chatwoot_path, issues)
    if issues:
        return issues

    issues.extend(
        require_real_values(
            taskbot,
            [
                "APP_ENV",
                "BOT_MODE",
                "BOT_DOMAIN",
                "CHATWOOT_DOMAIN",
                "ACME_EMAIL",
                "POSTGRES_SUPER_PASSWORD",
                "TASKBOT_DB_PASSWORD",
                "CHATWOOT_DB_PASSWORD",
                "TELEGRAM_BOT_TOKEN",
                "TELEGRAM_WEBHOOK_SECRET",
                "CHATWOOT_API_TOKEN",
                "CHATWOOT_ACCOUNT_ID",
                "CHATWOOT_INBOX_ID",
                "CHATWOOT_WEBHOOK_SECRET",
            ],
        )
    )
    issues.extend(validate_chatwoot_values(chatwoot))
    issues.extend(require_exact(taskbot, "APP_ENV", "production"))
    issues.extend(require_exact(taskbot, "CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS", "false"))

    for key in ("BOT_DOMAIN", "CHATWOOT_DOMAIN"):
        issues.extend(require_public_hostname(taskbot, key))
    issues.extend(require_email(taskbot, "ACME_EMAIL"))
    for key in ("TELEGRAM_WEBHOOK_URL", "WEBHOOK_BASE_URL", "CHATWOOT_BASE_URL"):
        if taskbot.get(key):
            issues.extend(require_https_url(taskbot, key))
    if chatwoot.get("FRONTEND_URL"):
        issues.extend(require_https_url(chatwoot, "FRONTEND_URL"))
    return issues


def validate_taskbot_env(path: Path, *, production: bool) -> list[EnvIssue]:
    issues: list[EnvIssue] = []
    values = read_env_file(path, issues)
    if issues:
        return issues
    return validate_taskbot_values(values, production=production)


def validate_taskbot_values(values: dict[str, str], *, production: bool) -> list[EnvIssue]:
    required = [
        "APP_ENV",
        "BOT_MODE",
        "TELEGRAM_BOT_TOKEN",
        "DB_HOST",
        "DB_NAME",
        "DB_USER",
        "DB_PASSWORD",
        "REDIS_HOST",
    ]
    if values.get("DATABASE_URL"):
        required = [key for key in required if not key.startswith("DB_")]
    if values.get("REDIS_URL"):
        required = [key for key in required if key != "REDIS_HOST"]
    if truthy(values.get("CHATWOOT_ENABLED")):
        required.extend(
            [
                "CHATWOOT_BASE_URL",
                "CHATWOOT_API_TOKEN",
                "CHATWOOT_ACCOUNT_ID",
                "CHATWOOT_INBOX_ID",
                "CHATWOOT_WEBHOOK_SECRET",
            ]
        )
    if production:
        required.extend(["TELEGRAM_WEBHOOK_SECRET", "TELEGRAM_WEBHOOK_URL"])

    issues = require_real_values(values, required)
    if production:
        issues.extend(require_exact(values, "CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS", "false"))
    return issues


def validate_chatwoot_values(values: dict[str, str]) -> list[EnvIssue]:
    return require_real_values(
        values,
        [
            "SECRET_KEY_BASE",
        ],
    )


def read_env_file(path: Path, issues: list[EnvIssue]) -> dict[str, str]:
    if not path.exists():
        issues.append(EnvIssue(display_path(path), "file does not exist"))
        return {}
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def display_path(path: Path) -> str:
    try:
        return str(path.relative_to(ROOT))
    except ValueError:
        return str(path)


def require_real_values(values: dict[str, str], keys: list[str]) -> list[EnvIssue]:
    issues: list[EnvIssue] = []
    for key in keys:
        value = values.get(key, "")
        if looks_placeholder(value):
            issues.append(EnvIssue(key, "missing or still looks like a placeholder"))
    return issues


def require_exact(values: dict[str, str], key: str, expected: str) -> list[EnvIssue]:
    if values.get(key) == expected:
        return []
    return [EnvIssue(key, f"must be {expected}")]


def require_public_hostname(values: dict[str, str], key: str) -> list[EnvIssue]:
    value = values.get(key, "")
    if looks_placeholder(value):
        return [EnvIssue(key, "missing or still looks like a placeholder")]
    if "://" in value or "/" in value:
        return [EnvIssue(key, "must be a hostname, not a URL")]
    if value in {"localhost", "127.0.0.1"} or value.endswith(".local"):
        return [EnvIssue(key, "must be a public DNS hostname")]
    return []


def require_https_url(values: dict[str, str], key: str) -> list[EnvIssue]:
    value = values.get(key, "")
    if looks_placeholder(value):
        return [EnvIssue(key, "missing or still looks like a placeholder")]
    parsed = urlparse(value)
    if parsed.scheme != "https" or not parsed.netloc:
        return [EnvIssue(key, "must be an HTTPS URL")]
    return []


def require_email(values: dict[str, str], key: str) -> list[EnvIssue]:
    value = values.get(key, "")
    if looks_placeholder(value) or "@" not in value:
        return [EnvIssue(key, "must be a real email address")]
    return []


def looks_placeholder(value: str | None) -> bool:
    if value is None:
        return True
    normalized = value.strip().lower()
    if not normalized:
        return True
    return any(marker in normalized for marker in PLACEHOLDER_MARKERS)


def truthy(value: str | None) -> bool:
    return (value or "").strip().lower() in {"1", "true", "yes", "on"}


def print_result(issues: list[EnvIssue]) -> int:
    if not issues:
        print("OK: environment files look deployable")
        return 0
    for issue in issues:
        print(f"FAIL: {issue.key}: {issue.message}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
