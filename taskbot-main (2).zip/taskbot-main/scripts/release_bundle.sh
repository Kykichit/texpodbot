#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

IMAGE_REF="${IMAGE_REF:-${1:-}}"
VERSION="${VERSION:-${GITHUB_SHA:-}}"

if [[ -z "$IMAGE_REF" ]]; then
  printf 'ERROR: IMAGE_REF must be set or passed as the first argument.\n' >&2
  exit 1
fi

if [[ -z "$VERSION" ]]; then
  VERSION="$(git rev-parse HEAD)"
fi

BUNDLE_DIR="${BUNDLE_DIR:-dist/release-bundle}"
BUNDLE_NAME="${BUNDLE_NAME:-taskbot-release-${VERSION}.tar.gz}"
BUNDLE_PATH="${BUNDLE_PATH:-dist/${BUNDLE_NAME}}"

case "$BUNDLE_DIR" in
  ""|"."|".."|/*|../*|*/../*)
    printf 'ERROR: BUNDLE_DIR must be a safe relative path below the repository root.\n' >&2
    exit 1
    ;;
esac

required_files=(
  .env.vps.example
  .env.chatwoot.production.example
  docker-compose.vps.yml
  deploy/caddy/Caddyfile
  deploy/postgres/init/001-create-databases.sh
  scripts/setup.sh
  scripts/vps_bootstrap.sh
  scripts/backup.sh
  scripts/restore_check.sh
  scripts/doctor.py
)

for file in "${required_files[@]}"; do
  if [[ ! -f "$file" ]]; then
    printf 'ERROR: release bundle input is missing: %s\n' "$file" >&2
    exit 1
  fi
done

rm -rf "$BUNDLE_DIR"
mkdir -p \
  "$BUNDLE_DIR/deploy/caddy" \
  "$BUNDLE_DIR/deploy/postgres/init" \
  "$BUNDLE_DIR/scripts"

cp docker-compose.vps.yml "$BUNDLE_DIR/docker-compose.vps.yml"
cp .env.vps.example "$BUNDLE_DIR/.env.vps.example"
cp .env.chatwoot.production.example "$BUNDLE_DIR/.env.chatwoot.production.example"
cp deploy/caddy/Caddyfile "$BUNDLE_DIR/deploy/caddy/Caddyfile"
cp deploy/postgres/init/001-create-databases.sh \
  "$BUNDLE_DIR/deploy/postgres/init/001-create-databases.sh"
cp scripts/setup.sh "$BUNDLE_DIR/scripts/setup.sh"
cp scripts/vps_bootstrap.sh "$BUNDLE_DIR/scripts/vps_bootstrap.sh"
cp scripts/backup.sh "$BUNDLE_DIR/scripts/backup.sh"
cp scripts/restore_check.sh "$BUNDLE_DIR/scripts/restore_check.sh"
cp scripts/doctor.py "$BUNDLE_DIR/scripts/doctor.py"

printf '%s\n' "$VERSION" > "$BUNDLE_DIR/VERSION"
printf '%s\n' "$IMAGE_REF" > "$BUNDLE_DIR/IMAGE_REF"

chmod +x "$BUNDLE_DIR/scripts/setup.sh" \
  "$BUNDLE_DIR/scripts/vps_bootstrap.sh" \
  "$BUNDLE_DIR/scripts/backup.sh" \
  "$BUNDLE_DIR/scripts/restore_check.sh" \
  "$BUNDLE_DIR/scripts/doctor.py" \
  "$BUNDLE_DIR/deploy/postgres/init/001-create-databases.sh"

mkdir -p "$(dirname "$BUNDLE_PATH")"
tar -C "$BUNDLE_DIR" -czf "$BUNDLE_PATH" .

printf '%s\n' "$BUNDLE_PATH"
