#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ -z "${TASKBOT_APP_DIR:-}" ]]; then
  if [[ "$(basename "$ROOT_DIR")" == "current" && -d "$(dirname "$ROOT_DIR")/releases" ]]; then
    TASKBOT_APP_DIR="$(dirname "$ROOT_DIR")"
  else
    TASKBOT_APP_DIR="$ROOT_DIR"
  fi
fi

TASKBOT_SHARED_DIR="${TASKBOT_SHARED_DIR:-$TASKBOT_APP_DIR/shared}"

if [[ -z "${VPS_ENV_FILE:-}" ]]; then
  if [[ -f "$TASKBOT_SHARED_DIR/.env.vps" ]]; then
    VPS_ENV_FILE="$TASKBOT_SHARED_DIR/.env.vps"
  else
    VPS_ENV_FILE=".env.vps"
  fi
fi

if [[ -z "${CHATWOOT_ENV_FILE:-}" ]]; then
  if [[ -f "$TASKBOT_SHARED_DIR/.env.chatwoot.production" ]]; then
    CHATWOOT_ENV_FILE="$TASKBOT_SHARED_DIR/.env.chatwoot.production"
  else
    CHATWOOT_ENV_FILE=".env.chatwoot.production"
  fi
fi

export VPS_ENV_FILE CHATWOOT_ENV_FILE
COMPOSE_PROJECT_NAME="${COMPOSE_PROJECT_NAME:-taskbot}"
export COMPOSE_PROJECT_NAME
# Equivalent legacy shape: docker compose --env-file "$VPS_ENV_FILE" -f docker-compose.vps.yml ...
# Production shape adds -p "$COMPOSE_PROJECT_NAME" for stable container and volume names.
COMPOSE=(docker compose -p "$COMPOSE_PROJECT_NAME" --env-file "$VPS_ENV_FILE" -f docker-compose.vps.yml)

usage() {
  cat <<'EOF'
Usage: scripts/setup.sh <command>

Commands:
  doctor       Validate required files, binaries, and production env posture.
  pull         Pull configured production images.
  build-local  Build the taskbot app image locally for manual non-CI deploys.
  migrate      Run Chatwoot prepare and taskbot Alembic migrations.
  up           Start the full VPS stack.
  deploy       Run doctor, pull, migrate, and up.
  ps           Show service status.
  status       Show Compose status and the public /ready endpoint.
  releases     List installed VPS release bundles.
  current      Show the active release and taskbot image reference.
  rollback     Switch current to the previous release and restart services.
  backup       Back up both PostgreSQL databases.
  logs         Follow app, Chatwoot, and Caddy logs.
EOF
}

fail() {
  printf 'ERROR: %s\n' "$*" >&2
  exit 1
}

need_file() {
  [[ -f "$1" ]] || fail "Missing $1. Copy the matching .example file and fill it on the VPS."
}

ensure_env_file() {
  local target="$1"
  local example="$2"
  if [[ ! -f "$target" ]]; then
    if [[ -f "$example" ]]; then
      cp "$example" "$target"
      fail "Created $target from $example. Fill real values, then rerun scripts/setup.sh doctor."
    fi
    fail "Missing $target. Keep VPS secrets outside releases, for example in /opt/taskbot/shared."
  fi
}

need_bin() {
  command -v "$1" >/dev/null 2>&1 || fail "$1 is not installed or not on PATH."
}

env_value() {
  local file="$1"
  local key="$2"
  grep -E "^${key}=" "$file" | tail -n 1 | cut -d= -f2-
}

require_env() {
  local file="$1"
  local key="$2"
  local value
  value="$(env_value "$file" "$key" || true)"
  [[ -n "$value" ]] || fail "$key is missing in $file."
  [[ "$value" != *"<"* && "$value" != *">"* ]] || fail "$key still contains a placeholder in $file."
}

doctor() {
  need_bin docker
  docker compose version >/dev/null || fail "Docker Compose v2 is required."
  ensure_env_file "$VPS_ENV_FILE" .env.vps.example
  ensure_env_file "$CHATWOOT_ENV_FILE" .env.chatwoot.production.example
  need_file docker-compose.vps.yml
  need_file deploy/caddy/Caddyfile

  local required_taskbot=(
    APP_ENV BOT_DOMAIN CHATWOOT_DOMAIN ACME_EMAIL POSTGRES_SUPER_PASSWORD
    TASKBOT_DB_PASSWORD CHATWOOT_DB_PASSWORD
    TELEGRAM_BOT_TOKEN TELEGRAM_WEBHOOK_SECRET
    CHATWOOT_API_TOKEN CHATWOOT_ACCOUNT_ID CHATWOOT_INBOX_ID
    CHATWOOT_WEBHOOK_SECRET CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS
  )
  for key in "${required_taskbot[@]}"; do
    require_env "$VPS_ENV_FILE" "$key"
  done

  local required_chatwoot=(SECRET_KEY_BASE)
  for key in "${required_chatwoot[@]}"; do
    require_env "$CHATWOOT_ENV_FILE" "$key"
  done

  [[ "$(env_value "$VPS_ENV_FILE" APP_ENV)" == "production" ]] \
    || fail "APP_ENV must be production in $VPS_ENV_FILE."
  [[ "$(env_value "$VPS_ENV_FILE" CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS)" == "false" ]] \
    || fail "CHATWOOT_ALLOW_UNSIGNED_LOCAL_WEBHOOKS must be false in production."

  python scripts/doctor.py vps --taskbot-env "$VPS_ENV_FILE" --chatwoot-env "$CHATWOOT_ENV_FILE"
  "${COMPOSE[@]}" config >/dev/null
  printf 'OK: VPS environment and compose files are valid.\n'
}

pull_images() {
  "${COMPOSE[@]}" pull
}

build_local() {
  "${COMPOSE[@]}" build app
}

migrate() {
  "${COMPOSE[@]}" up -d postgres redis
  "${COMPOSE[@]}" run --rm chatwoot-rails bundle exec rails db:chatwoot_prepare
  "${COMPOSE[@]}" run --rm app python -m app.main db-upgrade
}

up() {
  "${COMPOSE[@]}" up -d
  "${COMPOSE[@]}" ps
}

release_dir() {
  printf '%s/releases\n' "$TASKBOT_APP_DIR"
}

current_release_path() {
  if [[ -L "$TASKBOT_APP_DIR/current" ]]; then
    readlink -f "$TASKBOT_APP_DIR/current"
    return
  fi
  printf '%s\n' "$ROOT_DIR"
}

release_image() {
  local release="$1"
  if [[ -f "$release/IMAGE_REF" ]]; then
    cat "$release/IMAGE_REF"
    return
  fi
  printf 'unknown\n'
}

public_ready_url() {
  local bot_public_url
  local bot_domain
  bot_public_url="$(env_value "$VPS_ENV_FILE" BOT_PUBLIC_URL || true)"
  bot_domain="$(env_value "$VPS_ENV_FILE" BOT_DOMAIN || true)"

  if [[ -n "$bot_public_url" ]]; then
    printf '%s/ready\n' "${bot_public_url%/}"
    return
  fi
  [[ -n "$bot_domain" ]] || fail "BOT_DOMAIN is missing in $VPS_ENV_FILE."
  printf 'https://%s/ready\n' "$bot_domain"
}

list_releases() {
  local releases_path
  releases_path="$(release_dir)"
  [[ -d "$releases_path" ]] || fail "No releases directory found at $releases_path."

  local current_path
  current_path="$(current_release_path)"

  local found=0
  local release
  while IFS= read -r release; do
    found=1
    if [[ "$(readlink -f "$release")" == "$current_path" ]]; then
      printf '* %s  %s\n' "$(basename "$release")" "$(release_image "$release")"
    else
      printf '  %s  %s\n' "$(basename "$release")" "$(release_image "$release")"
    fi
  done < <(find "$releases_path" -mindepth 1 -maxdepth 1 -type d | sort)

  [[ "$found" -eq 1 ]] || fail "No installed releases found in $releases_path."
}

show_current() {
  local current_path
  current_path="$(current_release_path)"

  printf 'release=%s\n' "$(basename "$current_path")"
  printf 'path=%s\n' "$current_path"
  printf 'image=%s\n' "$(release_image "$current_path")"
}

previous_release_path() {
  local releases_path
  releases_path="$(release_dir)"
  [[ -d "$releases_path" ]] || fail "No releases directory found at $releases_path."

  local current_path
  current_path="$(current_release_path)"

  local entry
  local release
  while IFS= read -r -d '' entry; do
    release="${entry#* }"
    [[ "$(readlink -f "$release")" != "$current_path" ]] || continue
    printf '%s\n' "$release"
    return
  done < <(find "$releases_path" -mindepth 1 -maxdepth 1 -type d -printf '%T@ %p\0' \
    | sort -z -nr)

  fail "No previous release found."
}

rollback() {
  local previous_path
  previous_path="$(previous_release_path)"

  ln -sfn "$previous_path" "$TASKBOT_APP_DIR/current"
  cd "$TASKBOT_APP_DIR/current"

  export TASKBOT_IMAGE
  TASKBOT_IMAGE="$(release_image "$previous_path")"
  [[ "$TASKBOT_IMAGE" != "unknown" ]] || fail "IMAGE_REF is missing in $previous_path."

  printf 'Rolled back current to %s\n' "$previous_path"
  printf 'Starting services with image %s\n' "$TASKBOT_IMAGE"
  "${COMPOSE[@]}" up -d
}

status() {
  "${COMPOSE[@]}" ps
  curl -fsS "$(public_ready_url)"
  printf '\n'
}

predeploy_backup() {
  local postgres_container
  postgres_container="$("${COMPOSE[@]}" ps -q postgres || true)"
  if [[ -z "$postgres_container" ]]; then
    printf 'WARN: No existing postgres container found; skipping predeploy backup for first deploy.\n' >&2
    return
  fi
  bash scripts/backup.sh all
}

case "${1:-}" in
  doctor) doctor ;;
  pull) pull_images ;;
  build-local) build_local ;;
  migrate) migrate ;;
  up) up ;;
  deploy) doctor; predeploy_backup; pull_images; migrate; up ;;
  ps) "${COMPOSE[@]}" ps ;;
  status) status ;;
  releases) list_releases ;;
  current) show_current ;;
  rollback) rollback ;;
  backup) predeploy_backup ;;
  logs) "${COMPOSE[@]}" logs -f app chatwoot-rails chatwoot-worker caddy ;;
  -h|--help|help|"") usage ;;
  *) usage; fail "Unknown command: $1" ;;
esac
