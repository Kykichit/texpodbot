from domain.models import BotButton, BotRequest, BotResponse, InteractionType

START_TEXT = (
    "Привет! Я единый бот-шаблон для Telegram и MAX. "
    "Бизнес-логика здесь общая, а мессенджеры подключены через adapters."
)
HELP_TEXT = (
    "Доступные команды: /start, /help. "
    "Кнопки открывают главное меню или справку, а обычный текст обрабатывается общим use case."
)
MENU_TEXT = "Главное меню"


class BotDialogUseCase:
    async def handle(self, request: BotRequest) -> BotResponse:
        if request.interaction_type == InteractionType.COMMAND:
            return self._handle_command(request.text)
        if request.interaction_type == InteractionType.CALLBACK:
            return self._handle_action(request.action)
        return self._handle_text(request.text)

    def _handle_command(self, text: str | None) -> BotResponse:
        command = (text or "").strip().split(maxsplit=1)[0].lower()
        if command == "/help":
            return BotResponse(text=HELP_TEXT, buttons=self._menu_buttons())
        return BotResponse(text=START_TEXT, buttons=self._menu_buttons())

    def _handle_action(self, action: str | None) -> BotResponse:
        if action == "help":
            return BotResponse(text=HELP_TEXT, buttons=self._menu_buttons())
        if action == "main_menu":
            return BotResponse(text=MENU_TEXT, buttons=self._menu_buttons())
        return BotResponse(
            text="Неизвестное действие. Возвращаю главное меню.",
            buttons=self._menu_buttons(),
        )

    def _handle_text(self, text: str | None) -> BotResponse:
        normalized = (text or "").strip()
        if not normalized:
            return BotResponse(
                text="Отправьте текст или выберите действие.",
                buttons=self._menu_buttons(),
            )
        return BotResponse(
            text=f"Получил сообщение: {normalized}",
            buttons=self._menu_buttons(),
        )

    @staticmethod
    def _menu_buttons() -> tuple[BotButton, ...]:
        return (
            BotButton(text="Главное меню", action="main_menu"),
            BotButton(text="Помощь", action="help"),
        )
