"""Platform-neutral domain package."""
