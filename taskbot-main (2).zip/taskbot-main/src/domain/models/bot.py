from dataclasses import dataclass, field
from enum import StrEnum


class Platform(StrEnum):
    TELEGRAM = "telegram"
    MAX = "max"


class InteractionType(StrEnum):
    COMMAND = "command"
    TEXT = "text"
    CALLBACK = "callback"


@dataclass(frozen=True, slots=True)
class BotButton:
    text: str
    action: str


@dataclass(frozen=True, slots=True)
class BotRequest:
    platform: Platform
    user_id: str
    chat_id: str
    interaction_type: InteractionType
    text: str | None = None
    action: str | None = None


@dataclass(frozen=True, slots=True)
class BotResponse:
    text: str
    buttons: tuple[BotButton, ...] = field(default_factory=tuple)
