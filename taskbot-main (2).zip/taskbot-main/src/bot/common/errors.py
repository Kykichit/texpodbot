class BotAdapterError(RuntimeError):
    """Raised when a platform adapter cannot process an update."""
