"""Common bot presentation helpers."""
