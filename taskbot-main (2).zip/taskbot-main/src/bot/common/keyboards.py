from domain.models import BotButton


def chunk_buttons(buttons: tuple[BotButton, ...], size: int = 2) -> list[list[BotButton]]:
    return [list(buttons[index : index + size]) for index in range(0, len(buttons), size)]
