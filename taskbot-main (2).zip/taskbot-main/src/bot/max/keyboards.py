from typing import Any

from bot.common.keyboards import chunk_buttons
from domain.models import BotButton


def build_inline_keyboard(buttons: tuple[BotButton, ...]) -> dict[str, Any] | None:
    if not buttons:
        return None
    return {
        "type": "inline_keyboard",
        "payload": {
            "buttons": [
                [
                    {
                        "type": "callback",
                        "text": button.text,
                        "payload": button.action,
                    }
                    for button in row
                ]
                for row in chunk_buttons(buttons)
            ]
        },
    }
