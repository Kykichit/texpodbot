from collections.abc import Mapping
from typing import Any

import httpx

JsonObject = dict[str, Any]


class MaxBotApiClient:
    def __init__(self, base_url: str, token: str, timeout: float = 10.0) -> None:
        self._base_url = base_url.rstrip("/")
        self._token = token
        self._timeout = timeout

    async def get_updates(
        self,
        marker: int | None = None,
        limit: int = 100,
        long_poll_timeout: int = 30,
    ) -> JsonObject:
        params: dict[str, int] = {"limit": limit, "timeout": long_poll_timeout}
        if marker is not None:
            params["marker"] = marker
        return await self._request("GET", "/updates", params=params)

    async def send_message(
        self,
        *,
        text: str,
        chat_id: str | None = None,
        user_id: str | None = None,
        keyboard: Mapping[str, Any] | None = None,
    ) -> JsonObject:
        if chat_id is None and user_id is None:
            msg = "Either chat_id or user_id is required"
            raise ValueError(msg)
        params = {"chat_id": chat_id} if chat_id is not None else {"user_id": user_id}
        payload: JsonObject = {"text": text}
        if keyboard is not None:
            payload["attachments"] = [keyboard]
        return await self._request("POST", "/messages", params=params, json=payload)

    async def answer_callback(
        self,
        callback_id: str,
        notification: str | None = None,
    ) -> JsonObject:
        payload: JsonObject = {}
        if notification is not None:
            payload["notification"] = notification
        return await self._request(
            "POST",
            "/answers",
            params={"callback_id": callback_id},
            json=payload,
        )

    async def _request(self, method: str, path: str, **kwargs: Any) -> JsonObject:
        headers = {"Authorization": self._token}
        async with httpx.AsyncClient(
            base_url=self._base_url,
            timeout=self._timeout,
            headers=headers,
        ) as client:
            response = await client.request(method, path, **kwargs)
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, dict):
                msg = "MAX API returned a non-object response"
                raise TypeError(msg)
            return data
