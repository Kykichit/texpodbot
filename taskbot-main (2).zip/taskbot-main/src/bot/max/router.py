import asyncio
import logging
from typing import Any

from bot.common.messages import GENERIC_ERROR_MESSAGE
from bot.max.adapter import MaxBotApiClient
from bot.max.handlers import get_callback_id, update_to_request
from bot.max.keyboards import build_inline_keyboard
from domain.use_cases import BotDialogUseCase

logger = logging.getLogger(__name__)


class MaxPollingRouter:
    def __init__(
        self,
        client: MaxBotApiClient,
        use_case: BotDialogUseCase,
        poll_interval_seconds: float = 1.0,
    ) -> None:
        self._client = client
        self._use_case = use_case
        self._poll_interval_seconds = poll_interval_seconds
        self._marker: int | None = None

    async def run(self) -> None:
        while True:
            await self.poll_once()
            await asyncio.sleep(self._poll_interval_seconds)

    async def poll_once(self) -> None:
        payload = await self._client.get_updates(marker=self._marker)
        self._marker = _extract_marker(payload, current=self._marker)
        updates = payload.get("updates", [])
        if not isinstance(updates, list):
            logger.warning("MAX updates payload is not a list", extra={"platform": "max"})
            return
        for update in updates:
            if isinstance(update, dict):
                await self.handle_update(update)

    async def handle_update(self, update: dict[str, Any]) -> None:
        request = update_to_request(update)
        if request is None:
            return
        try:
            response = await self._use_case.handle(request)
            await self._client.send_message(
                text=response.text,
                chat_id=None if request.chat_id == "unknown" else request.chat_id,
                user_id=request.user_id if request.chat_id == "unknown" else None,
                keyboard=build_inline_keyboard(response.buttons),
            )
            callback_id = get_callback_id(update)
            if callback_id is not None:
                await self._client.answer_callback(callback_id)
        except Exception:
            logger.exception("MAX update handling failed", extra={"platform": "max"})
            await self._client.send_message(
                text=GENERIC_ERROR_MESSAGE,
                chat_id=None if request.chat_id == "unknown" else request.chat_id,
                user_id=request.user_id if request.chat_id == "unknown" else None,
            )


def _extract_marker(payload: dict[str, Any], current: int | None) -> int | None:
    marker = payload.get("marker")
    if isinstance(marker, int):
        return marker
    if isinstance(marker, str) and marker.isdigit():
        return int(marker)
    return current
