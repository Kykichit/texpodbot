"""MAX adapter package."""
