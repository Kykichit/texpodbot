from typing import Any

from domain.models import BotRequest, InteractionType, Platform


def _chat_id_from(message: dict[str, Any], chat: dict[str, Any]) -> str:
    return str(chat.get("chat_id") or chat.get("id") or message.get("chat_id") or "unknown")


def update_to_request(update: dict[str, Any]) -> BotRequest | None:
    callback = _get_mapping(update, "callback")
    if callback is not None:
        callback_message = _get_mapping(callback, "message") or {}
        user = _get_mapping(callback, "user") or _get_mapping(update, "user") or {}
        chat = _get_mapping(callback_message, "chat") or _get_mapping(update, "chat") or {}
        return BotRequest(
            platform=Platform.MAX,
            user_id=str(user.get("user_id") or user.get("id") or "unknown"),
            chat_id=_chat_id_from(callback_message, chat),
            interaction_type=InteractionType.CALLBACK,
            action=str(callback.get("payload") or callback.get("data") or ""),
        )

    incoming_message = _get_mapping(update, "message")
    if incoming_message is None:
        return None

    body = str(incoming_message.get("text") or incoming_message.get("body") or "")
    sender = (
        _get_mapping(incoming_message, "sender") or _get_mapping(incoming_message, "user") or {}
    )
    recipient = (
        _get_mapping(incoming_message, "recipient") or _get_mapping(incoming_message, "chat") or {}
    )
    chat_id = _chat_id_from(incoming_message, recipient)
    interaction_type = InteractionType.COMMAND if body.startswith("/") else InteractionType.TEXT

    return BotRequest(
        platform=Platform.MAX,
        user_id=str(sender.get("user_id") or sender.get("id") or "unknown"),
        chat_id=chat_id,
        interaction_type=interaction_type,
        text=body,
    )


def get_callback_id(update: dict[str, Any]) -> str | None:
    callback = _get_mapping(update, "callback")
    if callback is None:
        return None
    callback_id = callback.get("callback_id") or callback.get("id")
    return str(callback_id) if callback_id else None


def _get_mapping(payload: dict[str, Any], key: str) -> dict[str, Any] | None:
    value = payload.get(key)
    return value if isinstance(value, dict) else None
