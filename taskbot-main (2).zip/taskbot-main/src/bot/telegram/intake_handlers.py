import logging
from enum import StrEnum

from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import Message
from texpod_bot.services.intake_prototype import IntakeContext, IntakePrototypeService
from texpod_bot.services.support_group_bridge import SupportGroupBridgeService

from bot.common.messages import GENERIC_ERROR_MESSAGE

logger = logging.getLogger(__name__)

UNSUPPORTED_GROUP_MESSAGE = (
    "Этот бот работает только в личном чате клиента и в группе техподдержки."
)
PRIVATE_CLOSE_MESSAGE = "Закрытие обращений доступно в группе техподдержки."


class TelegramChatRole(StrEnum):
    PRIVATE = "private"
    SUPPORT_GROUP = "support_group"
    OTHER_GROUP = "other_group"


def register_intake_handlers(
    router: Router,
    intake_service: IntakePrototypeService,
    *,
    support_bridge: SupportGroupBridgeService | None = None,
    support_group_id: str | None = None,
) -> None:
    @router.message(CommandStart())
    async def start_handler(message: Message) -> None:
        role = _message_role(message, support_group_id)
        if role == TelegramChatRole.SUPPORT_GROUP:
            if support_bridge is not None:
                bridge_response = await support_bridge.handle_support_group_start()
                if bridge_response.text:
                    await message.answer(bridge_response.text)
            return
        if role == TelegramChatRole.OTHER_GROUP:
            await message.answer(UNSUPPORTED_GROUP_MESSAGE)
            return
        context = _context_from_message(message)
        if context is None:
            return
        try:
            response = await intake_service.start(context)
            await _answer_intake_response(message, response)
        except Exception:
            logger.exception("Telegram intake start failed")
            await message.answer(GENERIC_ERROR_MESSAGE)

    @router.message(Command("help"))
    async def help_handler(message: Message) -> None:
        if _message_role(message, support_group_id) != TelegramChatRole.PRIVATE:
            await message.answer(UNSUPPORTED_GROUP_MESSAGE)
            return
        await message.answer(
            "Опишите проблему, бот создаст обращение и передаст его в техподдержку."
        )

    @router.message(Command("close"))
    async def close_handler(message: Message) -> None:
        role = _message_role(message, support_group_id)
        if role == TelegramChatRole.PRIVATE:
            await message.answer(PRIVATE_CLOSE_MESSAGE)
            return
        if role == TelegramChatRole.SUPPORT_GROUP and support_bridge is not None:
            response = await support_bridge.handle_close_command(
                command_text=message.text or "",
                replied_message_id=_routing_message_id_from_reply(message),
                support_thread_id=(
                    str(message.message_thread_id)
                    if message.message_thread_id is not None
                    else None
                ),
            )
            if response.text:
                await message.answer(response.text)
            return
        await message.answer(UNSUPPORTED_GROUP_MESSAGE)

    @router.message(Command("status"))
    async def status_handler(message: Message) -> None:
        role = _message_role(message, support_group_id)
        if role == TelegramChatRole.PRIVATE:
            await message.answer(PRIVATE_CLOSE_MESSAGE)
            return
        if role == TelegramChatRole.SUPPORT_GROUP and support_bridge is not None:
            response = await support_bridge.handle_status_command(command_text=message.text or "")
            if response.text:
                await message.answer(response.text)
            return
        await message.answer(UNSUPPORTED_GROUP_MESSAGE)

    @router.message(Command("stats"))
    async def stats_handler(message: Message) -> None:
        role = _message_role(message, support_group_id)
        if role == TelegramChatRole.PRIVATE:
            await message.answer(PRIVATE_CLOSE_MESSAGE)
            return
        if role == TelegramChatRole.SUPPORT_GROUP and support_bridge is not None:
            response = await support_bridge.handle_stats_command(command_text=message.text or "")
            if response.text:
                await message.answer(response.text)
            return
        await message.answer(UNSUPPORTED_GROUP_MESSAGE)

    @router.message(Command("cancel"))
    async def cancel_handler(message: Message) -> None:
        if _message_role(message, support_group_id) != TelegramChatRole.PRIVATE:
            await message.answer(UNSUPPORTED_GROUP_MESSAGE)
            return
        context = _context_from_message(message)
        if context is None:
            return
        try:
            response = await intake_service.cancel(context)
            await _answer_intake_response(message, response)
        except Exception:
            logger.exception("Telegram intake cancel failed")
            await message.answer(GENERIC_ERROR_MESSAGE)

    @router.message(F.reply_to_message)
    async def support_group_reply_handler(message: Message) -> None:
        role = _message_role(message, support_group_id)
        if role == TelegramChatRole.OTHER_GROUP:
            await message.answer(UNSUPPORTED_GROUP_MESSAGE)
            return
        if role != TelegramChatRole.SUPPORT_GROUP or support_bridge is None:
            await text_handler(message)
            return
        text = message.text or message.caption
        if text and text.startswith("/"):
            return
        if message.from_user is None or message.reply_to_message is None:
            return
        try:
            response = await support_bridge.handle_operator_reply(
                operator_telegram_user_id=str(message.from_user.id),
                replied_message_id=_routing_message_id_from_reply(message),
                support_thread_id=(
                    str(message.message_thread_id)
                    if message.message_thread_id is not None
                    else None
                ),
                text=text,
                telegram_message_id=str(message.message_id),
            )
            if response.text:
                await message.answer(response.text)
        except Exception:
            logger.exception("Telegram support group reply handling failed")
            await message.answer(GENERIC_ERROR_MESSAGE)

    @router.message()
    async def text_handler(message: Message) -> None:
        role = _message_role(message, support_group_id)
        if role == TelegramChatRole.SUPPORT_GROUP:
            return
        if role == TelegramChatRole.OTHER_GROUP:
            await message.answer(UNSUPPORTED_GROUP_MESSAGE)
            return
        context = _context_from_message(message)
        if context is None:
            return
        text = message.text or ""
        try:
            response = await intake_service.handle_text(context, text)
            await _answer_intake_response(message, response)
        except Exception:
            logger.exception("Telegram intake message handling failed")
            await message.answer(GENERIC_ERROR_MESSAGE)


async def _answer_intake_response(message: Message, response: object) -> None:
    should_reply = getattr(response, "should_reply", True)
    text = getattr(response, "text", None)
    if should_reply and text:
        await message.answer(text)


def classify_telegram_chat(
    *,
    chat_type: str,
    chat_id: str,
    support_group_id: str | None,
) -> TelegramChatRole:
    if chat_type == "private":
        return TelegramChatRole.PRIVATE
    if chat_type in {"group", "supergroup"} and support_group_id and chat_id == support_group_id:
        return TelegramChatRole.SUPPORT_GROUP
    return TelegramChatRole.OTHER_GROUP


def _message_role(message: Message, support_group_id: str | None) -> TelegramChatRole:
    return classify_telegram_chat(
        chat_type=str(message.chat.type),
        chat_id=str(message.chat.id),
        support_group_id=support_group_id,
    )


def _routing_message_id_from_reply(message: Message) -> str | None:
    if message.reply_to_message is None:
        return None
    if message.reply_to_message.reply_to_message is not None:
        return str(message.reply_to_message.reply_to_message.message_id)
    return str(message.reply_to_message.message_id)


def _context_from_message(message: Message) -> IntakeContext | None:
    if message.from_user is None:
        return None
    display_name = message.from_user.full_name or message.from_user.username
    return IntakeContext(
        telegram_user_id=str(message.from_user.id),
        telegram_chat_id=str(message.chat.id),
        display_name=display_name,
    )
