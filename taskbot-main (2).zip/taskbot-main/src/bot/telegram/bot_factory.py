from aiogram import Bot
from aiogram.client.session.aiohttp import AiohttpSession


def create_telegram_bot(token: str, proxy_url: str | None = None) -> Bot:
    if proxy_url:
        session = AiohttpSession(proxy=proxy_url)
        return Bot(token=token, session=session)
    return Bot(token=token)
