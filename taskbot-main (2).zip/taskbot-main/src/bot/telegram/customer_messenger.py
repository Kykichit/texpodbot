from aiogram import Bot


class TelegramCustomerMessenger:
    def __init__(self, bot: Bot) -> None:
        self._bot = bot

    async def send_text(self, *, chat_id: str, text: str) -> None:
        await self._bot.send_message(chat_id=chat_id, text=text)

    async def close(self) -> None:
        await self._bot.session.close()
