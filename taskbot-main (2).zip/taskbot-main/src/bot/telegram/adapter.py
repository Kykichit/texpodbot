from typing import Any

from aiogram import Bot, Dispatcher
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker
from texpod_bot.services.intake_prototype import IntakePrototypeService
from texpod_bot.services.support_desk import SupportDeskAdapter
from texpod_bot.services.support_group_bridge import SupportGroupBridgeService

from bot.telegram.bot_factory import create_telegram_bot
from bot.telegram.intake_notifier import AiogramSupportNotifier
from bot.telegram.intake_router import build_telegram_intake_router
from bot.telegram.proxy import resolve_telegram_proxy_url
from bot.telegram.router import build_telegram_router
from bot.telegram.support_group_adapter import AiogramTelegramSupportApi
from domain.use_cases import BotDialogUseCase


class TelegramWebhookUpdateHandler:
    def __init__(
        self,
        token: str,
        use_case: BotDialogUseCase,
        proxy_url: str | None = None,
    ) -> None:
        resolved_proxy_url = resolve_telegram_proxy_url(proxy_url)
        self._bot = create_telegram_bot(token=token, proxy_url=resolved_proxy_url)
        self._dispatcher = Dispatcher()
        self._dispatcher.include_router(build_telegram_router(use_case))

    async def __call__(self, update: dict[str, Any]) -> None:
        await self._dispatcher.feed_raw_update(self._bot, update)

    async def close(self) -> None:
        await self._bot.session.close()


class TelegramIntakeWebhookUpdateHandler:
    def __init__(
        self,
        *,
        token: str,
        sessionmaker: async_sessionmaker[AsyncSession],
        support_group_id: str | None,
        proxy_url: str | None = None,
        support_desk: SupportDeskAdapter | None = None,
        bot: Bot | None = None,
    ) -> None:
        self._bot = bot or create_telegram_bot(
            token=token,
            proxy_url=resolve_telegram_proxy_url(proxy_url),
        )
        self._dispatcher = build_telegram_intake_dispatcher(
            bot=self._bot,
            sessionmaker=sessionmaker,
            support_group_id=support_group_id,
            support_desk=support_desk,
        )

    async def __call__(self, update: dict[str, Any]) -> None:
        await self._dispatcher.feed_raw_update(self._bot, update)

    async def close(self) -> None:
        await self._bot.session.close()


async def run_telegram_bot(
    token: str,
    use_case: BotDialogUseCase,
    proxy_url: str | None = None,
) -> None:
    bot = create_telegram_bot(token=token, proxy_url=resolve_telegram_proxy_url(proxy_url))
    dispatcher = Dispatcher()
    dispatcher.include_router(build_telegram_router(use_case))
    await dispatcher.start_polling(bot)


async def run_telegram_intake_bot(
    *,
    token: str,
    sessionmaker: async_sessionmaker[AsyncSession],
    support_group_id: str | None,
    proxy_url: str | None = None,
    support_desk: SupportDeskAdapter | None = None,
) -> None:
    bot = create_telegram_bot(token=token, proxy_url=resolve_telegram_proxy_url(proxy_url))
    dispatcher = build_telegram_intake_dispatcher(
        bot=bot,
        sessionmaker=sessionmaker,
        support_group_id=support_group_id,
        support_desk=support_desk,
    )
    try:
        await dispatcher.start_polling(bot)
    finally:
        await bot.session.close()


def build_telegram_intake_dispatcher(
    *,
    bot: Bot,
    sessionmaker: async_sessionmaker[AsyncSession],
    support_group_id: str | None,
    support_desk: SupportDeskAdapter | None = None,
) -> Dispatcher:
    notifier = AiogramSupportNotifier(bot, support_group_id) if support_group_id else None
    support_bridge = (
        SupportGroupBridgeService(
            sessionmaker=sessionmaker,
            telegram_api=AiogramTelegramSupportApi(bot),
            support_group_id=support_group_id,
        )
        if support_group_id
        else None
    )
    intake_service = IntakePrototypeService(
        sessionmaker=sessionmaker,
        notifier=notifier,
        support_desk=support_desk,
    )
    dispatcher = Dispatcher()
    dispatcher.include_router(
        build_telegram_intake_router(
            intake_service,
            support_bridge=support_bridge,
            support_group_id=support_group_id,
        )
    )
    return dispatcher
