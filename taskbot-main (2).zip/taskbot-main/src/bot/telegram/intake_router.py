from aiogram import Router
from texpod_bot.services.intake_prototype import IntakePrototypeService
from texpod_bot.services.support_group_bridge import SupportGroupBridgeService

from bot.telegram.intake_handlers import register_intake_handlers


def build_telegram_intake_router(
    intake_service: IntakePrototypeService,
    *,
    support_bridge: SupportGroupBridgeService | None = None,
    support_group_id: str | None = None,
) -> Router:
    router = Router(name="telegram-intake")
    register_intake_handlers(
        router,
        intake_service,
        support_bridge=support_bridge,
        support_group_id=support_group_id,
    )
    return router
