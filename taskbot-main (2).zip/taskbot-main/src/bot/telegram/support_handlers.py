from aiogram import F, Router
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message
from texpod_bot.services.runbook_service import RunbookService
from texpod_bot.services.telegram_support import (
    IncomingClientMessage,
    TelegramSupportHandlers,
    TelegramSupportResponse,
    TelegramUserContext,
)

from bot.telegram.support_keyboards import (
    build_helped_keyboard,
    build_issue_type_menu,
    build_main_menu_keyboard,
    build_operator_keyboard,
    build_runbook_option_labels,
)


def register_support_handlers(
    router: Router,
    *,
    handlers: TelegramSupportHandlers,
    runbook_service: RunbookService,
    support_group_id: str | None = None,
) -> None:
    @router.message(CommandStart())
    async def start_handler(message: Message) -> None:
        response = await handlers.handle_start(_message_context(message))
        await _answer_message(message, response, runbook_service)

    @router.message(Command("help"))
    async def help_handler(message: Message) -> None:
        response = await handlers.handle_help(_message_context(message))
        await _answer_message(message, response, runbook_service)

    @router.message(Command("cancel"))
    async def cancel_handler(message: Message) -> None:
        response = await handlers.handle_cancel(_message_context(message))
        await _answer_message(message, response, runbook_service)

    @router.callback_query(F.data == "support:main_menu")
    async def main_menu_handler(callback_query: CallbackQuery) -> None:
        response = await handlers.handle_main_menu(_callback_context(callback_query))
        await _answer_callback(callback_query, response, runbook_service)

    @router.callback_query(F.data.startswith("support:issue:"))
    async def issue_type_handler(callback_query: CallbackQuery) -> None:
        runbook_code = str(callback_query.data).removeprefix("support:issue:")
        response = await handlers.handle_issue_type(_callback_context(callback_query), runbook_code)
        await _answer_callback(callback_query, response, runbook_service)

    @router.callback_query(F.data.startswith("support:option:"))
    async def runbook_option_handler(callback_query: CallbackQuery) -> None:
        selected_option = str(callback_query.data).removeprefix("support:option:")
        response = await handlers.handle_runbook_option(
            _callback_context(callback_query),
            selected_option,
        )
        await _answer_callback(callback_query, response, runbook_service)

    @router.callback_query(F.data == "support:operator")
    async def operator_handler(callback_query: CallbackQuery) -> None:
        response = await handlers.handle_call_operator(_callback_context(callback_query))
        await _answer_callback(callback_query, response, runbook_service)

    @router.callback_query(F.data == "support:cancel")
    async def callback_cancel_handler(callback_query: CallbackQuery) -> None:
        response = await handlers.handle_cancel(_callback_context(callback_query))
        await _answer_callback(callback_query, response, runbook_service)

    @router.message(F.reply_to_message)
    async def support_group_reply_handler(message: Message) -> None:
        if support_group_id is None or str(message.chat.id) != support_group_id:
            response = await handlers.handle_client_message(
                _message_context(message),
                IncomingClientMessage(
                    text=message.text or message.caption,
                    attachment_url=_attachment_reference(message),
                    attachment_metadata=_attachment_metadata(message),
                    telegram_message_id=str(message.message_id),
                ),
            )
            await _answer_message(message, response, runbook_service)
            return
        if message.from_user is None or message.reply_to_message is None:
            return
        response = await handlers.handle_support_group_reply(
            operator_telegram_user_id=str(message.from_user.id),
            support_group_message_id=str(message.reply_to_message.message_id),
            support_thread_id=(
                str(message.message_thread_id) if message.message_thread_id is not None else None
            ),
            text=message.text or message.caption,
            telegram_message_id=str(message.message_id),
        )
        if response.text != "Ответ отправлен клиенту.":
            await message.answer(response.text)

    @router.message()
    async def client_message_handler(message: Message) -> None:
        response = await handlers.handle_client_message(
            _message_context(message),
            IncomingClientMessage(
                text=message.text or message.caption,
                attachment_url=_attachment_reference(message),
                attachment_metadata=_attachment_metadata(message),
                telegram_message_id=str(message.message_id),
            ),
        )
        await _answer_message(message, response, runbook_service)


async def _answer_message(
    message: Message,
    response: TelegramSupportResponse,
    runbook_service: RunbookService,
) -> None:
    if response.should_reply and response.text:
        await message.answer(response.text, reply_markup=_keyboard(response, runbook_service))


async def _answer_callback(
    callback_query: CallbackQuery,
    response: TelegramSupportResponse,
    runbook_service: RunbookService,
) -> None:
    if response.should_reply and response.text and isinstance(callback_query.message, Message):
        await callback_query.message.answer(
            response.text,
            reply_markup=_keyboard(response, runbook_service),
        )
    await callback_query.answer()


def _keyboard(
    response: TelegramSupportResponse,
    runbook_service: RunbookService,
) -> InlineKeyboardMarkup | None:
    if response.keyboard == "issue_type_menu":
        return build_issue_type_menu(runbook_service)
    if response.keyboard == "runbook_options":
        return build_runbook_option_labels(response.options)
    if response.keyboard == "helped":
        return build_helped_keyboard()
    if response.keyboard == "operator":
        return build_operator_keyboard()
    return build_main_menu_keyboard()


def _message_context(message: Message) -> TelegramUserContext:
    if message.from_user is None:
        return TelegramUserContext(
            telegram_user_id="unknown",
            telegram_chat_id=str(message.chat.id),
        )
    return TelegramUserContext(
        telegram_user_id=str(message.from_user.id),
        telegram_chat_id=str(message.chat.id),
        display_name=message.from_user.full_name,
    )


def _callback_context(callback_query: CallbackQuery) -> TelegramUserContext:
    chat_id = "unknown"
    if callback_query.message is not None:
        chat_id = str(callback_query.message.chat.id)
    return TelegramUserContext(
        telegram_user_id=str(callback_query.from_user.id),
        telegram_chat_id=chat_id,
        display_name=callback_query.from_user.full_name,
    )


def _attachment_reference(message: Message) -> str | None:
    if message.photo:
        return message.photo[-1].file_id
    if message.video:
        return message.video.file_id
    if message.document:
        return message.document.file_id
    return None


def _attachment_metadata(message: Message) -> dict[str, str] | None:
    if message.photo:
        photo = message.photo[-1]
        return {
            "type": "photo",
            "file_unique_id": photo.file_unique_id,
            "width": str(photo.width),
            "height": str(photo.height),
        }
    if message.video:
        return {
            "type": "video",
            "file_unique_id": message.video.file_unique_id,
            "duration": str(message.video.duration),
        }
    if message.document:
        return {
            "type": "document",
            "file_unique_id": message.document.file_unique_id,
            "file_name": message.document.file_name or "",
        }
    return None
