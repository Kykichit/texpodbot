import os
import urllib.parse
import urllib.request


def resolve_telegram_proxy_url(explicit_proxy_url: str | None = None) -> str | None:
    for value in (
        explicit_proxy_url,
        os.environ.get("TELEGRAM_PROXY_URL"),
        os.environ.get("HTTPS_PROXY"),
        os.environ.get("HTTP_PROXY"),
        os.environ.get("ALL_PROXY"),
    ):
        normalized = _normalize_proxy_url(value)
        if normalized is not None:
            return normalized

    proxies = urllib.request.getproxies()
    for key in ("https", "http", "all"):
        normalized = _normalize_proxy_url(proxies.get(key))
        if normalized is not None:
            return normalized
    return None


def mask_proxy_url(proxy_url: str | None) -> str:
    if not proxy_url:
        return "missing"

    parsed = urllib.parse.urlsplit(proxy_url)
    if parsed.password is None:
        return proxy_url

    username = parsed.username or ""
    hostname = parsed.hostname or ""
    netloc = f"{username}:***@{hostname}"
    if parsed.port is not None:
        netloc = f"{netloc}:{parsed.port}"
    return urllib.parse.urlunsplit(
        (parsed.scheme, netloc, parsed.path, parsed.query, parsed.fragment)
    )


def _normalize_proxy_url(value: str | None) -> str | None:
    if value is None:
        return None
    stripped = value.strip()
    return stripped or None
