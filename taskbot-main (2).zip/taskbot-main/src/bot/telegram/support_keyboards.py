from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from texpod_bot.domain.runbooks import RunbookStep
from texpod_bot.services.runbook_service import RunbookService


def build_issue_type_menu(runbook_service: RunbookService) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=runbook.title,
                    callback_data=f"support:issue:{runbook.code}",
                )
            ]
            for runbook in runbook_service.issue_types()
        ]
        + [[InlineKeyboardButton(text="Отмена", callback_data="support:cancel")]]
    )


def build_runbook_options(step: RunbookStep) -> InlineKeyboardMarkup | None:
    return build_runbook_option_labels(tuple(option.label for option in step.options))


def build_runbook_option_labels(options: tuple[str, ...]) -> InlineKeyboardMarkup | None:
    if not options:
        return None
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text=option,
                    callback_data=f"support:option:{option}",
                )
            ]
            for option in options
        ]
        + [[InlineKeyboardButton(text="Позвать оператора", callback_data="support:operator")]]
    )


def build_helped_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="Помогло", callback_data="support:option:Да"),
                InlineKeyboardButton(text="Не помогло", callback_data="support:option:Нет"),
            ],
            [InlineKeyboardButton(text="Позвать оператора", callback_data="support:operator")],
        ]
    )


def build_operator_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Позвать оператора", callback_data="support:operator")],
            [InlineKeyboardButton(text="Отмена", callback_data="support:cancel")],
        ]
    )


def build_main_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Выбрать проблему", callback_data="support:main_menu")],
            [InlineKeyboardButton(text="Отмена", callback_data="support:cancel")],
        ]
    )
