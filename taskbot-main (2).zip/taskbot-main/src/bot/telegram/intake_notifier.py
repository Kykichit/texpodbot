from aiogram import Bot
from texpod_bot.services.intake_prototype import SupportNotifier
from texpod_bot.services.telegram_escalation import SentTelegramMessage


class AiogramSupportNotifier(SupportNotifier):
    def __init__(self, bot: Bot, support_group_id: str | None) -> None:
        self._bot = bot
        self._support_group_id = support_group_id

    async def notify_ticket_created(
        self,
        ticket_id: str,
        summary: str,
    ) -> SentTelegramMessage | None:
        if not self._support_group_id:
            return None
        message = await self._bot.send_message(chat_id=self._support_group_id, text=summary)
        return SentTelegramMessage(
            message_id=str(message.message_id),
            message_thread_id=(
                str(message.message_thread_id) if message.message_thread_id is not None else None
            ),
        )

    async def notify_client_reply(
        self,
        *,
        public_id: str,
        text: str,
        reply_to_message_id: str,
        message_thread_id: str | None = None,
    ) -> SentTelegramMessage | None:
        if not self._support_group_id:
            return None
        message = await self._bot.send_message(
            chat_id=self._support_group_id,
            text=f"💬 Новое сообщение от клиента по {public_id}:\n{text}",
            reply_to_message_id=int(reply_to_message_id),
            message_thread_id=int(message_thread_id) if message_thread_id else None,
        )
        return SentTelegramMessage(
            message_id=str(message.message_id),
            message_thread_id=(
                str(message.message_thread_id) if message.message_thread_id is not None else None
            ),
        )
