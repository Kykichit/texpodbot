import logging

from aiogram import Router
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, Message

from bot.common.messages import GENERIC_ERROR_MESSAGE
from bot.telegram.keyboards import build_inline_keyboard
from domain.models import BotRequest, InteractionType, Platform
from domain.use_cases import BotDialogUseCase

logger = logging.getLogger(__name__)


def register_handlers(router: Router, use_case: BotDialogUseCase) -> None:
    @router.message(CommandStart())
    async def start_handler(message: Message) -> None:
        await _handle_message(message, use_case, InteractionType.COMMAND)

    @router.message(Command("help"))
    async def help_handler(message: Message) -> None:
        await _handle_message(message, use_case, InteractionType.COMMAND)

    @router.message()
    async def text_handler(message: Message) -> None:
        await _handle_message(message, use_case, InteractionType.TEXT)

    @router.callback_query()
    async def callback_handler(callback_query: CallbackQuery) -> None:
        message = callback_query.message
        if message is None:
            await callback_query.answer()
            return
        try:
            response = await use_case.handle(
                BotRequest(
                    platform=Platform.TELEGRAM,
                    user_id=str(callback_query.from_user.id),
                    chat_id=str(message.chat.id),
                    interaction_type=InteractionType.CALLBACK,
                    action=callback_query.data,
                )
            )
            await message.answer(
                response.text,
                reply_markup=build_inline_keyboard(response.buttons),
            )
            await callback_query.answer()
        except Exception:
            logger.exception(
                "Telegram callback handling failed",
                extra={"platform": Platform.TELEGRAM},
            )
            await callback_query.answer(GENERIC_ERROR_MESSAGE, show_alert=True)


async def _handle_message(
    message: Message,
    use_case: BotDialogUseCase,
    interaction_type: InteractionType,
) -> None:
    if message.from_user is None:
        return
    try:
        response = await use_case.handle(
            BotRequest(
                platform=Platform.TELEGRAM,
                user_id=str(message.from_user.id),
                chat_id=str(message.chat.id),
                interaction_type=interaction_type,
                text=message.text,
            )
        )
        await message.answer(response.text, reply_markup=build_inline_keyboard(response.buttons))
    except Exception:
        logger.exception("Telegram message handling failed", extra={"platform": Platform.TELEGRAM})
        await message.answer(GENERIC_ERROR_MESSAGE)
