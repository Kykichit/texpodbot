from aiogram import Bot
from texpod_bot.services.telegram_escalation import SentTelegramMessage


class AiogramTelegramSupportApi:
    def __init__(self, bot: Bot) -> None:
        self._bot = bot

    async def send_message(
        self,
        *,
        chat_id: str,
        text: str,
        reply_to_message_id: str | None = None,
        message_thread_id: str | None = None,
    ) -> SentTelegramMessage:
        message = await self._bot.send_message(
            chat_id=chat_id,
            text=text,
            reply_to_message_id=int(reply_to_message_id) if reply_to_message_id else None,
            message_thread_id=int(message_thread_id) if message_thread_id else None,
        )
        return SentTelegramMessage(
            message_id=str(message.message_id),
            message_thread_id=(
                str(message.message_thread_id) if message.message_thread_id is not None else None
            ),
        )
