from aiogram import Router

from bot.telegram.handlers import register_handlers
from domain.use_cases import BotDialogUseCase


def build_telegram_router(use_case: BotDialogUseCase) -> Router:
    router = Router(name="telegram")
    register_handlers(router, use_case)
    return router
