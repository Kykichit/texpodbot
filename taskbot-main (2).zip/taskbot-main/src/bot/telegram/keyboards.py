from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from bot.common.keyboards import chunk_buttons
from domain.models import BotButton


def build_inline_keyboard(buttons: tuple[BotButton, ...]) -> InlineKeyboardMarkup | None:
    if not buttons:
        return None
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=button.text, callback_data=button.action) for button in row]
            for row in chunk_buttons(buttons)
        ]
    )
