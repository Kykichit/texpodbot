"""Bot platform adapters."""
