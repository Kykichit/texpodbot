from enum import StrEnum
from functools import lru_cache
from typing import Any
from urllib.parse import quote

from pydantic import PositiveFloat, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class AppEnv(StrEnum):
    LOCAL = "local"
    DEMO = "demo"
    TEST = "test"
    STAGING = "staging"
    PRODUCTION = "production"


class BotMode(StrEnum):
    TELEGRAM = "telegram"
    MAX = "max"
    BOTH = "both"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    app_env: AppEnv = AppEnv.LOCAL
    log_level: str = "INFO"
    bot_mode: BotMode = BotMode.TELEGRAM
    app_version: str = "unknown"
    app_commit: str = "unknown"

    telegram_bot_token: str | None = None
    telegram_proxy_url: str | None = None
    telegram_webhook_secret: str | None = None
    telegram_webhook_url: str | None = None
    telegram_support_group_id: str | None = None
    web_host: str = "127.0.0.1"
    web_port: int = 8080

    max_bot_token: str | None = None
    max_api_base_url: str = "https://platform-api.max.ru"
    webhook_base_url: str | None = None

    database_url: str | None = None
    db_scheme: str = "postgresql+asyncpg"
    db_host: str | None = None
    db_port: int = 5432
    db_name: str | None = None
    db_user: str | None = None
    db_password: str | None = None
    redis_url: str | None = None
    redis_scheme: str = "redis"
    redis_host: str | None = None
    redis_port: int = 6379
    redis_db: int = 0
    redis_password: str | None = None
    external_api_timeout_seconds: PositiveFloat = 10
    sentry_dsn: str | None = None
    github_token: str | None = None
    github_repo: str | None = None
    chatwoot_enabled: bool = False
    chatwoot_base_url: str | None = None
    chatwoot_api_token: str | None = None
    chatwoot_account_id: int | None = None
    chatwoot_inbox_id: int | None = None
    chatwoot_webhook_secret: str | None = None
    chatwoot_allow_unsigned_local_webhooks: bool = False

    @field_validator("log_level")
    @classmethod
    def normalize_log_level(cls, value: str) -> str:
        return value.upper()

    @model_validator(mode="after")
    def derive_connection_urls(self) -> "Settings":
        if not self.database_url and self._has_database_parts():
            self.database_url = build_database_url(
                scheme=self.db_scheme,
                host=self.db_host,
                port=self.db_port,
                name=self.db_name,
                user=self.db_user,
                password=self.db_password,
            )
        if not self.redis_url and self.redis_host:
            self.redis_url = build_redis_url(
                scheme=self.redis_scheme,
                host=self.redis_host,
                port=self.redis_port,
                db=self.redis_db,
                password=self.redis_password,
            )
        return self

    def validate_runtime(self) -> None:
        missing = self.missing_required_variables()
        if missing:
            names = ", ".join(missing)
            msg = f"Missing required environment variables: {names}"
            raise RuntimeError(msg)

    def missing_required_variables(self) -> list[str]:
        missing: list[str] = []

        required_values = {"REDIS_URL or REDIS_HOST": self.redis_url}
        if not self.database_url:
            required_values["DATABASE_URL or DB_HOST/DB_NAME/DB_USER/DB_PASSWORD"] = None
        if self.bot_mode in {BotMode.TELEGRAM, BotMode.BOTH}:
            required_values["TELEGRAM_BOT_TOKEN"] = self.telegram_bot_token
        missing.extend(name for name, value in required_values.items() if not value)

        if self.bot_mode in {BotMode.MAX, BotMode.BOTH} and not self.max_bot_token:
            missing.append("MAX_BOT_TOKEN")
        if self.chatwoot_enabled:
            chatwoot_required_values = {
                "CHATWOOT_BASE_URL": self.chatwoot_base_url,
                "CHATWOOT_API_TOKEN": self.chatwoot_api_token,
                "CHATWOOT_ACCOUNT_ID": self.chatwoot_account_id,
                "CHATWOOT_INBOX_ID": self.chatwoot_inbox_id,
            }
            missing.extend(
                name for name, value in chatwoot_required_values.items() if value in {None, ""}
            )
        return missing

    def config_summary(self) -> dict[str, Any]:
        return {
            "app_env": self.app_env,
            "log_level": self.log_level,
            "bot_mode": self.bot_mode,
            "database_url": mask_secret(self.database_url),
            "redis_url": mask_secret(self.redis_url),
            "telegram_bot_token": mask_secret(self.telegram_bot_token),
            "telegram_proxy_url": mask_secret(self.telegram_proxy_url),
            "telegram_webhook_secret": mask_secret(self.telegram_webhook_secret),
            "telegram_webhook_url": mask_secret(self.telegram_webhook_url),
            "telegram_support_group_id": mask_identifier(self.telegram_support_group_id),
            "optional_integrations": {
                "sentry": "enabled" if self.sentry_dsn else "disabled",
                "github": "enabled" if self.github_token and self.github_repo else "disabled",
                "chatwoot": "enabled" if self.chatwoot_configured else "disabled",
                "chatwoot_unsigned_local_webhooks": (
                    "enabled" if self.chatwoot_allow_unsigned_local_webhooks else "disabled"
                ),
            },
        }

    @property
    def chatwoot_configured(self) -> bool:
        return bool(
            self.chatwoot_enabled
            and self.chatwoot_base_url
            and self.chatwoot_api_token
            and self.chatwoot_account_id is not None
            and self.chatwoot_inbox_id is not None
        )

    def _has_database_parts(self) -> bool:
        return all((self.db_host, self.db_name, self.db_user, self.db_password))


def mask_secret(value: str | None) -> str:
    if not value:
        return "missing"
    if len(value) <= 8:
        return "***"
    return f"{value[:2]}***{value[-2:]}"


def mask_identifier(value: str | None) -> str:
    if not value:
        return "missing"
    if len(value) <= 4:
        return "***"
    return f"***{value[-4:]}"


def build_database_url(
    *,
    scheme: str,
    host: str | None,
    port: int,
    name: str | None,
    user: str | None,
    password: str | None,
) -> str:
    if not all((host, name, user, password)):
        msg = "DB_HOST, DB_NAME, DB_USER, and DB_PASSWORD are required to build DATABASE_URL"
        raise RuntimeError(msg)
    return (
        f"{scheme}://{quote(user or '', safe='')}:{quote(password or '', safe='')}"
        f"@{host}:{port}/{quote(name or '', safe='')}"
    )


def build_redis_url(
    *,
    scheme: str,
    host: str,
    port: int,
    db: int,
    password: str | None = None,
) -> str:
    credentials = f":{quote(password, safe='')}@" if password else ""
    return f"{scheme}://{credentials}{host}:{port}/{db}"


@lru_cache
def get_settings() -> Settings:
    return Settings()
