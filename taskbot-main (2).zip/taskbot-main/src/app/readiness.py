from typing import Protocol, cast

import redis.asyncio as redis
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine


class ReadinessChecker(Protocol):
    async def check(self) -> dict[str, str]:
        """Return dependency statuses or raise when the app is not ready."""


class DependencyUnavailableError(RuntimeError):
    """Raised when a readiness dependency is unavailable."""

    def __init__(self, message: str, *, dependency: str = "unknown") -> None:
        super().__init__(message)
        self.dependency = dependency


class DatabaseRedisReadinessChecker:
    def __init__(self, database_url: str, redis_url: str) -> None:
        self._database_url = database_url
        self._redis_url = redis_url

    async def check(self) -> dict[str, str]:
        await self._check_database()
        await self._check_redis()
        return {"database": "ok", "redis": "ok"}

    async def _check_database(self) -> None:
        engine = create_async_engine(self._database_url)
        try:
            async with engine.connect() as connection:
                await connection.execute(text("SELECT 1"))
        except Exception as exc:
            msg = "Database readiness check failed"
            raise DependencyUnavailableError(msg, dependency="database") from exc
        finally:
            await engine.dispose()

    async def _check_redis(self) -> None:
        client = cast(redis.Redis, redis.from_url(self._redis_url))  # type: ignore[no-untyped-call]
        try:
            await client.ping()
        except Exception as exc:
            msg = "Redis readiness check failed"
            raise DependencyUnavailableError(msg, dependency="redis") from exc
        finally:
            await client.aclose()
