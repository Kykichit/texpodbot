import hashlib
import hmac
import ipaddress
import json
import logging
from collections.abc import Awaitable, Callable
from http import HTTPStatus
from typing import Any, cast
from urllib.parse import urlsplit

from aiohttp import web

from app.config import AppEnv, Settings
from app.metrics import METRICS_KEY, create_metrics, metrics_handler, metrics_middleware
from app.readiness import (
    DatabaseRedisReadinessChecker,
    DependencyUnavailableError,
    ReadinessChecker,
)

logger = logging.getLogger(__name__)

TELEGRAM_SECRET_HEADER = "X-Telegram-Bot-Api-Secret-Token"  # noqa: S105
CHATWOOT_SECRET_HEADER = "X-Chatwoot-Webhook-Secret"  # noqa: S105
CHATWOOT_SIGNATURE_HEADER = "X-Chatwoot-Signature"
CHATWOOT_TIMESTAMP_HEADER = "X-Chatwoot-Timestamp"

READINESS_KEY = web.AppKey("readiness_checker", ReadinessChecker)
SETTINGS_KEY = web.AppKey("settings", Settings)
TELEGRAM_UPDATE_HANDLER_KEY: web.AppKey[object] = web.AppKey("telegram_update_handler", object)
CHATWOOT_WEBHOOK_HANDLER_KEY: web.AppKey[object] = web.AppKey("chatwoot_webhook_handler", object)

_LOCALHOST_NAMES = {"localhost"}
_LOCAL_LOOPBACK_HOSTS = {
    ipaddress.ip_network("127.0.0.1/32"),
    ipaddress.ip_network("::1/128"),
}
_LOCAL_PRIVATE_NETWORKS = (
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
)


async def noop_telegram_update_handler(update: dict[str, Any]) -> None:
    return None


async def noop_chatwoot_webhook_handler(payload: dict[str, Any]) -> dict[str, Any]:
    return {"ok": True, "status": "ignored", "reason": "handler_not_configured"}


def create_web_app(
    settings: Settings,
    *,
    readiness_checker: ReadinessChecker | None = None,
    telegram_update_handler: Callable[[dict[str, Any]], Awaitable[None]] | None = None,
    chatwoot_webhook_handler: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]] | None = None,
) -> web.Application:
    app = web.Application(middlewares=[metrics_middleware])
    app[SETTINGS_KEY] = settings
    app[METRICS_KEY] = create_metrics(settings)
    app[READINESS_KEY] = readiness_checker or DatabaseRedisReadinessChecker(
        database_url=_required(settings.database_url, "DATABASE_URL"),
        redis_url=_required(settings.redis_url, "REDIS_URL"),
    )
    app[TELEGRAM_UPDATE_HANDLER_KEY] = telegram_update_handler or noop_telegram_update_handler
    app[CHATWOOT_WEBHOOK_HANDLER_KEY] = chatwoot_webhook_handler or noop_chatwoot_webhook_handler
    app.router.add_get("/health", health)
    app.router.add_get("/ready", ready)
    app.router.add_get("/metrics", metrics_handler)
    app.router.add_post("/telegram/webhook", telegram_webhook)
    app.router.add_post("/chatwoot/webhook", chatwoot_webhook)
    return app


async def health(request: web.Request) -> web.Response:
    return web.json_response({"status": "ok"})


async def ready(request: web.Request) -> web.Response:
    checker = request.app[READINESS_KEY]
    try:
        dependencies = await checker.check()
    except DependencyUnavailableError as exc:
        logger.warning("Readiness check failed")
        request.app[METRICS_KEY].observe_readiness_failure(dependency=exc.dependency)
        return web.json_response(
            {"status": "unavailable"},
            status=HTTPStatus.SERVICE_UNAVAILABLE,
        )
    return web.json_response({"status": "ok", "dependencies": dependencies})


async def telegram_webhook(request: web.Request) -> web.Response:
    settings = request.app[SETTINGS_KEY]
    expected_secret = settings.telegram_webhook_secret
    if not expected_secret:
        logger.error("Telegram webhook secret is not configured")
        return web.json_response(
            {"ok": False, "error": "webhook_not_configured"},
            status=HTTPStatus.INTERNAL_SERVER_ERROR,
        )

    provided_secret = request.headers.get(TELEGRAM_SECRET_HEADER)
    if provided_secret is None:
        return web.json_response(
            {"ok": False, "error": "missing_secret"},
            status=HTTPStatus.UNAUTHORIZED,
        )
    if provided_secret != expected_secret:
        return web.json_response(
            {"ok": False, "error": "invalid_secret"},
            status=HTTPStatus.FORBIDDEN,
        )

    try:
        payload = await request.json()
    except Exception:
        return web.json_response(
            {"ok": False, "error": "invalid_json"},
            status=HTTPStatus.BAD_REQUEST,
        )
    if not isinstance(payload, dict):
        return web.json_response(
            {"ok": False, "error": "invalid_payload"},
            status=HTTPStatus.BAD_REQUEST,
        )

    handler = cast(
        Callable[[dict[str, Any]], Awaitable[None]],
        request.app[TELEGRAM_UPDATE_HANDLER_KEY],
    )
    await handler(payload)
    return web.json_response({"ok": True})


async def chatwoot_webhook(request: web.Request) -> web.Response:
    settings = request.app[SETTINGS_KEY]
    expected_secret = settings.chatwoot_webhook_secret
    if not expected_secret:
        logger.error("Chatwoot webhook secret is not configured")
        return web.json_response(
            {"ok": False, "error": "webhook_not_configured"},
            status=HTTPStatus.SERVICE_UNAVAILABLE,
        )

    if settings.app_env in {AppEnv.LOCAL, AppEnv.DEMO}:
        logger.info(
            "Chatwoot webhook header names: %s",
            ", ".join(sorted(request.headers.keys())),
        )

    raw_body = await request.read()
    auth_result = _authenticate_chatwoot_webhook(
        request,
        raw_body=raw_body,
        expected_secret=expected_secret,
        settings=settings,
    )
    if auth_result is not None:
        return auth_result

    try:
        payload = json.loads(raw_body.decode("utf-8"))
    except Exception:
        return web.json_response(
            {"ok": False, "error": "invalid_json"},
            status=HTTPStatus.BAD_REQUEST,
        )
    if not isinstance(payload, dict):
        return web.json_response(
            {"ok": False, "error": "invalid_payload"},
            status=HTTPStatus.BAD_REQUEST,
        )

    handler = cast(
        Callable[[dict[str, Any]], Awaitable[dict[str, Any]]],
        request.app[CHATWOOT_WEBHOOK_HANDLER_KEY],
    )
    result = await handler(payload)
    status = HTTPStatus.BAD_GATEWAY if result.get("status") == "send_failed" else HTTPStatus.OK
    return web.json_response(result, status=status)


def _authenticate_chatwoot_webhook(
    request: web.Request,
    *,
    raw_body: bytes,
    expected_secret: str,
    settings: Settings,
) -> web.Response | None:
    provided_secret = request.headers.get(CHATWOOT_SECRET_HEADER)
    if provided_secret is not None:
        if provided_secret == expected_secret:
            return None
        return web.json_response(
            {"ok": False, "error": "invalid_secret"},
            status=HTTPStatus.FORBIDDEN,
        )

    signature = request.headers.get(CHATWOOT_SIGNATURE_HEADER)
    timestamp = request.headers.get(CHATWOOT_TIMESTAMP_HEADER)
    if signature or timestamp:
        if (
            signature
            and timestamp
            and _verify_chatwoot_signature(
                raw_body=raw_body,
                timestamp=timestamp,
                signature=signature,
                secret=expected_secret,
            )
        ):
            return None
        return web.json_response(
            {"ok": False, "error": "invalid_secret"},
            status=HTTPStatus.FORBIDDEN,
        )

    if _allow_unsigned_local_chatwoot_webhooks(settings, request):
        logger.warning(
            "Accepting unsigned Chatwoot webhook in local/demo mode",
            extra={"host": request.host, "remote": request.remote},
        )
        return None

    return web.json_response(
        {"ok": False, "error": "missing_secret"},
        status=HTTPStatus.UNAUTHORIZED,
    )


def _verify_chatwoot_signature(
    *,
    raw_body: bytes,
    timestamp: str,
    signature: str,
    secret: str,
) -> bool:
    message = b".".join([timestamp.encode("utf-8"), raw_body])
    expected = hmac.new(secret.encode("utf-8"), message, hashlib.sha256).hexdigest()
    expected_signature = f"sha256={expected}"
    return hmac.compare_digest(expected_signature, signature)


def _allow_unsigned_local_chatwoot_webhooks(settings: Settings, request: web.Request) -> bool:
    if not settings.chatwoot_allow_unsigned_local_webhooks:
        return False
    if settings.app_env not in {AppEnv.LOCAL, AppEnv.DEMO}:
        return False
    return _request_looks_local(request)


def _request_looks_local(request: web.Request) -> bool:
    candidates = (
        request.remote,
        request.host,
        request.headers.get("Host"),
    )
    for candidate in candidates:
        if candidate and _looks_like_local_host(candidate):
            return True
    return False


def _looks_like_local_host(value: str) -> bool:
    host = _normalize_host(value)
    if host in _LOCALHOST_NAMES:
        return True
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        return False
    return any(address in network for network in (*_LOCAL_LOOPBACK_HOSTS, *_LOCAL_PRIVATE_NETWORKS))


def _normalize_host(value: str) -> str:
    parsed = urlsplit(f"//{value}")
    if parsed.hostname:
        return parsed.hostname.lower()
    return value.lower()


async def run_webhook_server(
    settings: Settings,
    *,
    telegram_update_handler: Callable[[dict[str, Any]], Awaitable[None]] | None = None,
    chatwoot_webhook_handler: Callable[[dict[str, Any]], Awaitable[dict[str, Any]]] | None = None,
) -> None:
    app = create_web_app(
        settings,
        telegram_update_handler=telegram_update_handler,
        chatwoot_webhook_handler=chatwoot_webhook_handler,
    )
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, settings.web_host, settings.web_port)
    logger.info("Webhook server started")
    await site.start()
    await _wait_forever()


async def _wait_forever() -> None:
    import asyncio

    await asyncio.Event().wait()


def _required(value: str | None, name: str) -> str:
    if not value:
        msg = f"{name} is required"
        raise RuntimeError(msg)
    return value
