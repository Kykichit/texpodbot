import json
from dataclasses import dataclass
from typing import Any

from app.config import BotMode, Settings, mask_identifier
from bot.telegram.proxy import resolve_telegram_proxy_url


@dataclass(frozen=True, slots=True)
class ConfigCheckResult:
    exit_code: int
    output: str


def build_config_check_result(
    settings: Settings,
    *,
    strict: bool = False,
    json_output: bool = False,
) -> ConfigCheckResult:
    missing = settings.missing_required_variables() if strict else []
    exit_code = 1 if missing else 0
    payload = _safe_payload(settings, strict=strict, missing=missing)
    if json_output:
        return ConfigCheckResult(
            exit_code=exit_code,
            output=json.dumps(payload, ensure_ascii=False, sort_keys=True),
        )
    return ConfigCheckResult(exit_code=exit_code, output=_format_human(payload))


def _safe_payload(settings: Settings, *, strict: bool, missing: list[str]) -> dict[str, Any]:
    bot_mode_supports_max = settings.bot_mode in {BotMode.MAX, BotMode.BOTH}
    telegram_proxy_url = resolve_telegram_proxy_url(settings.telegram_proxy_url)
    return {
        "ok": not missing,
        "strict": strict,
        "app_env": settings.app_env.value,
        "log_level": settings.log_level,
        "bot_mode": settings.bot_mode.value,
        "database_url_configured": bool(settings.database_url),
        "redis_url_configured": bool(settings.redis_url),
        "telegram_bot_token_configured": bool(settings.telegram_bot_token),
        "telegram_webhook_secret_configured": bool(settings.telegram_webhook_secret),
        "telegram_webhook_url_configured": bool(settings.telegram_webhook_url),
        "telegram_proxy_configured": bool(telegram_proxy_url),
        "telegram_support_group_id": mask_identifier(settings.telegram_support_group_id),
        "sentry": "enabled" if settings.sentry_dsn else "disabled",
        "github": "enabled" if settings.github_token and settings.github_repo else "disabled",
        "chatwoot": "enabled" if settings.chatwoot_configured else "disabled",
        "chatwoot_enabled": settings.chatwoot_enabled,
        "chatwoot_base_url_configured": bool(settings.chatwoot_base_url),
        "chatwoot_api_token_configured": bool(settings.chatwoot_api_token),
        "chatwoot_account_id_configured": settings.chatwoot_account_id is not None,
        "chatwoot_inbox_id_configured": settings.chatwoot_inbox_id is not None,
        "chatwoot_webhook_secret_configured": bool(settings.chatwoot_webhook_secret),
        "max": "enabled" if bot_mode_supports_max and settings.max_bot_token else "disabled",
        "missing_required_variables": missing,
    }


def _format_human(payload: dict[str, Any]) -> str:
    lines = [
        f"Configuration check: {'ok' if payload['ok'] else 'failed'}",
        f"strict: {_yes_no(bool(payload['strict']))}",
        f"APP_ENV: {payload['app_env']}",
        f"LOG_LEVEL: {payload['log_level']}",
        f"BOT_MODE: {payload['bot_mode']}",
        f"DATABASE_URL configured: {_yes_no(bool(payload['database_url_configured']))}",
        f"REDIS_URL configured: {_yes_no(bool(payload['redis_url_configured']))}",
        (
            "TELEGRAM_BOT_TOKEN configured: "
            f"{_yes_no(bool(payload['telegram_bot_token_configured']))}"
        ),
        (
            "TELEGRAM_WEBHOOK_SECRET configured: "
            f"{_yes_no(bool(payload['telegram_webhook_secret_configured']))}"
        ),
        (
            "TELEGRAM_WEBHOOK_URL configured: "
            f"{_yes_no(bool(payload['telegram_webhook_url_configured']))}"
        ),
        f"TELEGRAM_PROXY configured: {_yes_no(bool(payload['telegram_proxy_configured']))}",
        f"TELEGRAM_SUPPORT_GROUP_ID: {payload['telegram_support_group_id']}",
        f"SENTRY: {payload['sentry']}",
        f"GitHub integration: {payload['github']}",
        f"Chatwoot integration: {payload['chatwoot']}",
        f"CHATWOOT_ENABLED: {_yes_no(bool(payload['chatwoot_enabled']))}",
        f"CHATWOOT_BASE_URL configured: {_yes_no(bool(payload['chatwoot_base_url_configured']))}",
        f"CHATWOOT_API_TOKEN configured: {_yes_no(bool(payload['chatwoot_api_token_configured']))}",
        (
            "CHATWOOT_ACCOUNT_ID configured: "
            f"{_yes_no(bool(payload['chatwoot_account_id_configured']))}"
        ),
        f"CHATWOOT_INBOX_ID configured: {_yes_no(bool(payload['chatwoot_inbox_id_configured']))}",
        (
            "CHATWOOT_WEBHOOK_SECRET configured: "
            f"{_yes_no(bool(payload['chatwoot_webhook_secret_configured']))}"
        ),
        f"MAX integration: {payload['max']}",
    ]
    missing = payload["missing_required_variables"]
    if missing:
        lines.append(f"Missing required variables: {', '.join(missing)}")
    return "\n".join(lines)


def _yes_no(value: bool) -> str:
    return "yes" if value else "no"
