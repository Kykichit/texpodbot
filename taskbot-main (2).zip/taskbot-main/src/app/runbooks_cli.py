from dataclasses import dataclass
from pathlib import Path

import yaml
from texpod_bot.domain.runbooks import (
    RunbookAction,
    RunbookDefinition,
    RunbookError,
    load_runbooks_from_dir,
)


@dataclass(frozen=True, slots=True)
class RunbookCliResult:
    exit_code: int
    output: str


def validate_runbooks(path: Path) -> RunbookCliResult:
    try:
        runbooks = _load_runbooks(path)
    except RunbookError as exc:
        return RunbookCliResult(exit_code=1, output=f"Runbook validation failed: {exc}")
    except yaml.YAMLError as exc:
        return RunbookCliResult(exit_code=1, output=f"Runbook YAML error: {exc}")
    except OSError as exc:
        return RunbookCliResult(exit_code=1, output=f"Runbook directory error: {exc}")

    return RunbookCliResult(
        exit_code=0,
        output=f"Runbooks valid: {len(runbooks)} loaded from {path}",
    )


def list_runbooks(path: Path) -> RunbookCliResult:
    try:
        runbooks = _load_runbooks(path)
    except RunbookError as exc:
        return RunbookCliResult(exit_code=1, output=f"Runbook validation failed: {exc}")
    except yaml.YAMLError as exc:
        return RunbookCliResult(exit_code=1, output=f"Runbook YAML error: {exc}")
    except OSError as exc:
        return RunbookCliResult(exit_code=1, output=f"Runbook directory error: {exc}")

    lines = [f"Runbooks: {len(runbooks)}"]
    for runbook in sorted(runbooks.values(), key=lambda item: item.code):
        actions = _actions_for_runbook(runbook)
        action_text = ", ".join(action.value for action in actions) if actions else "none"
        lines.append(
            f"- {runbook.code}: {runbook.title} (steps={len(runbook.steps)}, actions={action_text})"
        )
    return RunbookCliResult(exit_code=0, output="\n".join(lines))


def _load_runbooks(path: Path) -> dict[str, RunbookDefinition]:
    if not path.exists():
        msg = f"Runbook directory does not exist: {path}"
        raise OSError(msg)
    if not path.is_dir():
        msg = f"Runbook path is not a directory: {path}"
        raise OSError(msg)
    return load_runbooks_from_dir(path)


def _actions_for_runbook(runbook: RunbookDefinition) -> tuple[RunbookAction, ...]:
    return tuple(
        sorted(
            {step.action for step in runbook.steps.values() if step.action is not None},
            key=lambda action: action.value,
        )
    )
