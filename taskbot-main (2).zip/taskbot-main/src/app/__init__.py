"""Application entrypoints and configuration."""
