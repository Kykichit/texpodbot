import time
from collections import defaultdict
from collections.abc import Awaitable, Callable, Iterable, Mapping
from dataclasses import dataclass, field

from aiohttp import web

from app.config import Settings

HTTP_DURATION_BUCKETS = (0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0)
WEBHOOK_LATENCY_BUCKETS = (0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0)


@dataclass
class HistogramSample:
    buckets: dict[float, int] = field(default_factory=lambda: defaultdict(int))
    count: int = 0
    total: float = 0.0


class PrometheusMetrics:
    def __init__(self, *, settings: Settings) -> None:
        self._settings = settings
        self._http_requests: dict[tuple[str, str, str], int] = defaultdict(int)
        self._http_durations: dict[tuple[str, str], HistogramSample] = defaultdict(HistogramSample)
        self._webhook_updates: dict[tuple[str, str], int] = defaultdict(int)
        self._webhook_latencies: dict[str, HistogramSample] = defaultdict(HistogramSample)
        self._readiness_failures: dict[str, int] = defaultdict(int)

    def observe_http_request(
        self,
        *,
        method: str,
        route: str,
        status: int,
        duration_seconds: float,
    ) -> None:
        self._http_requests[(route, method, str(status))] += 1
        _observe_histogram(
            self._http_durations[(route, method)],
            HTTP_DURATION_BUCKETS,
            duration_seconds,
        )

    def observe_webhook(
        self,
        *,
        channel: str,
        result: str,
        latency_seconds: float,
    ) -> None:
        self._webhook_updates[(channel, result)] += 1
        _observe_histogram(
            self._webhook_latencies[channel],
            WEBHOOK_LATENCY_BUCKETS,
            latency_seconds,
        )

    def observe_readiness_failure(self, *, dependency: str) -> None:
        self._readiness_failures[dependency] += 1

    def render(self) -> str:
        lines: list[str] = []
        lines.extend(
            [
                "# HELP taskbot_http_requests_total HTTP requests handled by taskbot.",
                "# TYPE taskbot_http_requests_total counter",
            ]
        )
        for (route, method, status), value in sorted(self._http_requests.items()):
            labels = _labels(route=route, method=method, status=status)
            lines.append(f"taskbot_http_requests_total{labels} {value}")

        lines.extend(
            _render_histogram(
                name="taskbot_http_request_duration_seconds",
                help_text="HTTP request duration in seconds.",
                buckets=HTTP_DURATION_BUCKETS,
                samples={
                    (route, method): sample
                    for (route, method), sample in self._http_durations.items()
                },
                label_names=("route", "method"),
            )
        )

        lines.extend(
            [
                "# HELP taskbot_webhook_updates_total Webhook updates handled by channel.",
                "# TYPE taskbot_webhook_updates_total counter",
            ]
        )
        for (channel, result), value in sorted(self._webhook_updates.items()):
            labels = _labels(channel=channel, result=result)
            lines.append(f"taskbot_webhook_updates_total{labels} {value}")

        lines.extend(
            _render_histogram(
                name="taskbot_webhook_latency_seconds",
                help_text="Webhook handler latency in seconds.",
                buckets=WEBHOOK_LATENCY_BUCKETS,
                samples={(channel,): sample for channel, sample in self._webhook_latencies.items()},
                label_names=("channel",),
            )
        )

        lines.extend(
            [
                "# HELP taskbot_readiness_failures_total Readiness failures by dependency.",
                "# TYPE taskbot_readiness_failures_total counter",
            ]
        )
        for dependency, value in sorted(self._readiness_failures.items()):
            labels = _labels(dependency=dependency)
            lines.append(f"taskbot_readiness_failures_total{labels} {value}")

        build_labels = _labels(
            version=self._settings.app_version,
            commit=self._settings.app_commit,
        )
        lines.extend(
            [
                "# HELP taskbot_build_info Build metadata for the running taskbot process.",
                "# TYPE taskbot_build_info gauge",
                f"taskbot_build_info{build_labels} 1",
            ]
        )
        return "\n".join(lines) + "\n"


@web.middleware
async def metrics_middleware(
    request: web.Request,
    handler: Callable[[web.Request], Awaitable[web.StreamResponse]],
) -> web.StreamResponse:
    metrics = request.app[METRICS_KEY]
    start = time.monotonic()
    status = 500
    try:
        response: web.StreamResponse = await handler(request)
        status = response.status
        return response
    except web.HTTPException as exc:
        status = exc.status
        raise
    finally:
        duration = time.monotonic() - start
        route = _route_name(request)
        metrics.observe_http_request(
            method=request.method,
            route=route,
            status=status,
            duration_seconds=duration,
        )
        channel = _webhook_channel(request)
        if channel is not None:
            metrics.observe_webhook(
                channel=channel,
                result="success" if status < 400 else "error",
                latency_seconds=duration,
            )


METRICS_KEY = web.AppKey("prometheus_metrics", PrometheusMetrics)


def create_metrics(settings: Settings) -> PrometheusMetrics:
    return PrometheusMetrics(settings=settings)


async def metrics_handler(request: web.Request) -> web.Response:
    return web.Response(
        text=request.app[METRICS_KEY].render(),
        content_type="text/plain",
    )


def _observe_histogram(sample: HistogramSample, buckets: Iterable[float], value: float) -> None:
    sample.count += 1
    sample.total += value
    for bucket in buckets:
        if value <= bucket:
            sample.buckets[bucket] += 1


def _render_histogram(
    *,
    name: str,
    help_text: str,
    buckets: tuple[float, ...],
    samples: Mapping[tuple[str, ...], HistogramSample],
    label_names: tuple[str, ...],
) -> list[str]:
    lines = [
        f"# HELP {name} {help_text}",
        f"# TYPE {name} histogram",
    ]
    for label_values, sample in sorted(samples.items()):
        base_labels = dict(zip(label_names, label_values, strict=True))
        for bucket in buckets:
            bucket_labels = {**base_labels, "le": _format_bucket(bucket)}
            lines.append(f"{name}_bucket{_labels(**bucket_labels)} {sample.buckets.get(bucket, 0)}")
        lines.append(f"{name}_bucket{_labels(**base_labels, le='+Inf')} {sample.count}")
        lines.append(f"{name}_count{_labels(**base_labels)} {sample.count}")
        lines.append(f"{name}_sum{_labels(**base_labels)} {sample.total:.9f}")
    return lines


def _route_name(request: web.Request) -> str:
    route = request.match_info.route
    resource = route.resource
    if resource is not None:
        canonical = resource.canonical
        if canonical:
            return canonical
    return request.path


def _webhook_channel(request: web.Request) -> str | None:
    if request.path == "/telegram/webhook":
        return "telegram"
    if request.path == "/chatwoot/webhook":
        return "chatwoot"
    return None


def _labels(**values: str) -> str:
    if not values:
        return ""
    rendered = ",".join(f'{name}="{_escape_label(value)}"' for name, value in values.items())
    return f"{{{rendered}}}"


def _escape_label(value: str) -> str:
    return value.replace("\\", "\\\\").replace("\n", "\\n").replace('"', '\\"')


def _format_bucket(value: float) -> str:
    return f"{value:g}"
