import os
from collections.abc import Callable
from pathlib import Path

from alembic import command
from alembic.config import Config


class DatabaseMigrationError(RuntimeError):
    pass


def run_alembic_upgrade(
    database_url: str | None,
    *,
    config_path: str | Path = "alembic.ini",
    upgrade: Callable[[Config, str], None] = command.upgrade,
) -> None:
    if not database_url:
        msg = "DATABASE_URL is required"
        raise DatabaseMigrationError(msg)

    previous_database_url = os.environ.get("DATABASE_URL")
    os.environ["DATABASE_URL"] = database_url
    try:
        alembic_config = Config(str(config_path))
        upgrade(alembic_config, "head")
    except Exception as exc:
        msg = "alembic upgrade head failed"
        raise DatabaseMigrationError(msg) from exc
    finally:
        if previous_database_url is None:
            os.environ.pop("DATABASE_URL", None)
        else:
            os.environ["DATABASE_URL"] = previous_database_url
