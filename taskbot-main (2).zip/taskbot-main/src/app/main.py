import argparse
import asyncio
import logging
import sys
from collections.abc import Awaitable, Callable
from datetime import date
from pathlib import Path
from typing import Any

from texpod_bot.infrastructure.chatwoot import (
    ChatwootClient,
    ChatwootSettings,
    ChatwootSupportDeskAdapter,
)
from texpod_bot.infrastructure.database.session import build_sessionmaker
from texpod_bot.infrastructure.repositories import SupportUnitOfWork
from texpod_bot.services.analytics import AnalyticsService
from texpod_bot.services.chatwoot_webhook import (
    ChatwootWebhookService,
    WebhookHandleResult,
)
from texpod_bot.services.support_desk import SupportDeskAdapter

from app.config import BotMode, Settings, get_settings
from app.config_check import build_config_check_result
from app.logging import configure_logging
from app.migrations import DatabaseMigrationError, run_alembic_upgrade
from app.runbooks_cli import list_runbooks, validate_runbooks
from app.web import run_webhook_server
from bot.max.adapter import MaxBotApiClient
from bot.max.router import MaxPollingRouter
from bot.telegram.adapter import TelegramIntakeWebhookUpdateHandler, run_telegram_intake_bot
from bot.telegram.bot_factory import create_telegram_bot
from bot.telegram.customer_messenger import TelegramCustomerMessenger
from bot.telegram.proxy import resolve_telegram_proxy_url
from bot.telegram.support_group_adapter import AiogramTelegramSupportApi
from domain.use_cases.bot_dialog import BotDialogUseCase

logger = logging.getLogger(__name__)


async def run(settings: Settings) -> None:
    settings.validate_runtime()
    use_case = BotDialogUseCase()
    tasks: list[asyncio.Task[None]] = []
    if settings.database_url is None:
        raise RuntimeError("DATABASE_URL is required")
    sessionmaker = build_sessionmaker(settings.database_url)

    if settings.bot_mode in {BotMode.TELEGRAM, BotMode.BOTH}:
        if settings.telegram_bot_token is None:
            raise RuntimeError("TELEGRAM_BOT_TOKEN is required")
        support_desk = build_chatwoot_support_desk(settings)
        tasks.append(
            asyncio.create_task(
                run_telegram_intake_bot(
                    token=settings.telegram_bot_token,
                    sessionmaker=sessionmaker,
                    support_group_id=settings.telegram_support_group_id,
                    proxy_url=settings.telegram_proxy_url,
                    support_desk=support_desk,
                ),
                name="telegram-bot",
            )
        )

    if settings.bot_mode in {BotMode.MAX, BotMode.BOTH}:
        if settings.max_bot_token is None:
            raise RuntimeError("MAX_BOT_TOKEN is required")
        client = MaxBotApiClient(
            base_url=str(settings.max_api_base_url),
            token=settings.max_bot_token,
            timeout=settings.external_api_timeout_seconds,
        )
        tasks.append(
            asyncio.create_task(
                MaxPollingRouter(client=client, use_case=use_case).run(),
                name="max-bot",
            )
        )

    logger.info("Bot runtime started", extra={"platform": settings.bot_mode})
    await asyncio.gather(*tasks)


def build_chatwoot_support_desk(settings: Settings) -> SupportDeskAdapter | None:
    if not settings.chatwoot_configured:
        return None
    chatwoot_settings = ChatwootSettings(
        base_url=settings.chatwoot_base_url,
        api_token=settings.chatwoot_api_token,
        account_id=settings.chatwoot_account_id,
        inbox_id=settings.chatwoot_inbox_id,
        webhook_secret=settings.chatwoot_webhook_secret,
    )
    client = ChatwootClient(
        settings=chatwoot_settings,
        timeout_seconds=float(settings.external_api_timeout_seconds),
    )
    return ChatwootSupportDeskAdapter(
        client,
        base_url=settings.chatwoot_base_url,
        account_id=settings.chatwoot_account_id,
    )


def config_check(settings: Settings, *, strict: bool = False, json_output: bool = False) -> int:
    result = build_config_check_result(settings, strict=strict, json_output=json_output)
    print(result.output)
    return result.exit_code


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Telegram/MAX bot application")
    subparsers = parser.add_subparsers(dest="command")

    for command in ("run", "serve-webhook", "healthcheck", "db-upgrade"):
        subparsers.add_parser(command)
    config_check_parser = subparsers.add_parser("config-check")
    config_check_parser.add_argument("--strict", action="store_true")
    config_check_parser.add_argument("--json", action="store_true", dest="json_output")

    report_parser = subparsers.add_parser("report")
    report_subparsers = report_parser.add_subparsers(dest="report_command")
    daily_parser = report_subparsers.add_parser("daily")
    daily_parser.add_argument("--date", required=True, dest="report_date")
    daily_parser.add_argument("--send-to-support-group", action="store_true")

    runbooks_parser = subparsers.add_parser("runbooks")
    runbooks_subparsers = runbooks_parser.add_subparsers(dest="runbooks_command")
    validate_parser = runbooks_subparsers.add_parser("validate")
    validate_parser.add_argument("--path", default="runbooks", dest="runbooks_path")
    list_parser = runbooks_subparsers.add_parser("list")
    list_parser.add_argument("--path", default="runbooks", dest="runbooks_path")

    parser.set_defaults(command="run")
    return parser


async def run_daily_report(
    settings: Settings,
    *,
    report_date: date,
    send_to_support_group: bool,
) -> None:
    if not settings.database_url:
        raise RuntimeError("DATABASE_URL is required")
    sessionmaker = build_sessionmaker(settings.database_url)
    async with sessionmaker() as session:
        uow = SupportUnitOfWork(session)
        analytics = AnalyticsService(uow)
        report = await analytics.build_daily_report(report_date)
        text = analytics.format_daily_report(report)
        print(text)

        if send_to_support_group:
            if settings.telegram_bot_token is None:
                raise RuntimeError("TELEGRAM_BOT_TOKEN is required")
            if settings.telegram_support_group_id is None:
                raise RuntimeError("TELEGRAM_SUPPORT_GROUP_ID is required")
            bot = create_telegram_bot(
                token=settings.telegram_bot_token,
                proxy_url=resolve_telegram_proxy_url(settings.telegram_proxy_url),
            )
            try:
                telegram_api = AiogramTelegramSupportApi(bot)
                await telegram_api.send_message(
                    chat_id=settings.telegram_support_group_id,
                    text=text,
                )
            finally:
                await bot.session.close()


def _parse_report_date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        msg = "--date must use YYYY-MM-DD format"
        raise RuntimeError(msg) from exc


def run_db_upgrade(settings: Settings) -> int:
    try:
        run_alembic_upgrade(settings.database_url)
    except DatabaseMigrationError as exc:
        print(f"Database migration failed: {exc}", file=sys.stderr)
        return 1
    print("Database migrations applied successfully.")
    return 0


async def async_main() -> None:
    settings = get_settings()
    configure_logging(settings.log_level)
    args = build_parser().parse_args()

    if args.command == "run":
        await run(settings)
    elif args.command == "serve-webhook":
        settings.validate_runtime()
        if settings.telegram_bot_token is None:
            raise RuntimeError("TELEGRAM_BOT_TOKEN is required")
        if settings.database_url is None:
            raise RuntimeError("DATABASE_URL is required")
        sessionmaker = build_sessionmaker(settings.database_url)
        support_desk = build_chatwoot_support_desk(settings)
        telegram_handler = TelegramIntakeWebhookUpdateHandler(
            token=settings.telegram_bot_token,
            sessionmaker=sessionmaker,
            support_group_id=settings.telegram_support_group_id,
            proxy_url=settings.telegram_proxy_url,
            support_desk=support_desk,
        )
        customer_bot = create_telegram_bot(
            token=settings.telegram_bot_token,
            proxy_url=resolve_telegram_proxy_url(settings.telegram_proxy_url),
        )
        telegram_messenger = TelegramCustomerMessenger(customer_bot)
        chatwoot_webhook_service = ChatwootWebhookService(
            sessionmaker=sessionmaker,
            messenger=telegram_messenger,
        )
        try:
            await run_webhook_server(
                settings,
                telegram_update_handler=telegram_handler,
                chatwoot_webhook_handler=_chatwoot_webhook_handler(chatwoot_webhook_service),
            )
        finally:
            await telegram_handler.close()
            await telegram_messenger.close()
    elif args.command == "config-check":
        raise SystemExit(
            config_check(
                settings,
                strict=bool(args.strict),
                json_output=bool(args.json_output),
            )
        )
    elif args.command == "healthcheck":
        raise SystemExit(config_check(settings))
    elif args.command == "db-upgrade":
        raise SystemExit(run_db_upgrade(settings))
    elif args.command == "report" and args.report_command == "daily":
        await run_daily_report(
            settings,
            report_date=_parse_report_date(args.report_date),
            send_to_support_group=bool(args.send_to_support_group),
        )
    elif args.command == "runbooks":
        if args.runbooks_command == "validate":
            result = validate_runbooks(Path(args.runbooks_path))
        elif args.runbooks_command == "list":
            result = list_runbooks(Path(args.runbooks_path))
        else:
            result = validate_runbooks(Path("runbooks"))
        print(result.output)
        raise SystemExit(result.exit_code)


def cli() -> None:
    asyncio.run(async_main())


def _chatwoot_webhook_handler(
    service: ChatwootWebhookService,
) -> Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]:
    async def handler(payload: dict[str, Any]) -> dict[str, Any]:
        result = await service.handle_webhook(payload)
        return _chatwoot_result_payload(result)

    return handler


def _chatwoot_result_payload(result: WebhookHandleResult) -> dict[str, Any]:
    payload: dict[str, Any] = {"ok": result.status != "send_failed", "status": result.status}
    if result.reason:
        payload["reason"] = result.reason
    if result.ticket_id:
        payload["ticket_id"] = result.ticket_id
    return payload


if __name__ == "__main__":
    cli()
