"""Storage implementations."""
