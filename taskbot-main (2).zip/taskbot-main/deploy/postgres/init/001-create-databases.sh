#!/bin/sh
set -eu

require_env() {
  name="$1"
  eval "value=\${$name:-}"
  if [ -z "$value" ]; then
    echo "Missing required environment variable: $name" >&2
    exit 1
  fi
}

require_env TASKBOT_DB
require_env TASKBOT_DB_USER
require_env TASKBOT_DB_PASSWORD
require_env CHATWOOT_DB
require_env CHATWOOT_DB_USER
require_env CHATWOOT_DB_PASSWORD

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname postgres \
  -v taskbot_db="$TASKBOT_DB" \
  -v taskbot_user="$TASKBOT_DB_USER" \
  -v taskbot_password="$TASKBOT_DB_PASSWORD" \
  -v chatwoot_db="$CHATWOOT_DB" \
  -v chatwoot_user="$CHATWOOT_DB_USER" \
  -v chatwoot_password="$CHATWOOT_DB_PASSWORD" <<'SQL'
CREATE USER :"taskbot_user" WITH PASSWORD :'taskbot_password';
CREATE DATABASE :"taskbot_db" OWNER :"taskbot_user";
CREATE USER :"chatwoot_user" WITH PASSWORD :'chatwoot_password';
CREATE DATABASE :"chatwoot_db" OWNER :"chatwoot_user";
SQL

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$CHATWOOT_DB" <<'SQL'
CREATE EXTENSION IF NOT EXISTS vector;
SQL
